-- =====================================================================
-- NinjaX - skema database Supabase (jalankan SEKALI di SQL Editor)
-- Aman dijalankan ulang (idempotent). Tidak memakai service-role key di frontend.
-- PRASYARAT: Authentication > Providers > "Allow anonymous sign-ins" = ON
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------- PROFILES ----------
create table if not exists public.profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  username     text not null unique check (username ~ '^[a-z0-9_]{3,20}$'),
  display_name text not null check (char_length(display_name) between 2 and 24),
  avatar_url   text,
  online       boolean not null default false,
  last_seen    timestamptz not null default now(),
  created_at   timestamptz not null default now()
);

-- ---------- MESSAGES (global chat) ----------
create table if not exists public.messages (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  username   text not null,
  content    text not null check (char_length(content) between 1 and 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists messages_created_idx on public.messages (created_at desc);
create index if not exists messages_user_idx on public.messages (user_id, created_at desc);

-- ---------- GLOBAL SENDERS (profil internal aplikasi, BUKAN akun eksternal) ----------
create table if not exists public.senders_global (
  id            uuid primary key default gen_random_uuid(),
  owner_id      uuid not null references auth.users(id) on delete cascade,
  name          text not null check (char_length(name) between 2 and 32),
  sender_code   text not null check (sender_code ~ '^[A-Za-z0-9_-]{3,24}$'),
  avatar_url    text,
  status        text not null default 'active' check (status in ('active','inactive','disabled')),
  note          text check (note is null or char_length(note) <= 120),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  last_activity timestamptz not null default now()
);
create unique index if not exists senders_global_code_uidx on public.senders_global (lower(sender_code));

-- ---------- NOTIFICATIONS (milik masing-masing user) ----------
create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       text not null check (kind in ('chat','system','security','sender')),
  title      text not null check (char_length(title) <= 80),
  body       text check (body is null or char_length(body) <= 240),
  read       boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

-- ---------- ACTIVITY / HISTORY (milik masing-masing user) ----------
create table if not exists public.activity (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       text not null check (char_length(kind) between 2 and 32),
  detail     text not null check (char_length(detail) <= 240),
  meta       jsonb,
  created_at timestamptz not null default now()
);
create index if not exists activity_user_idx on public.activity (user_id, created_at desc);

-- =====================================================================
-- TRIGGER: keamanan sisi server
-- =====================================================================

-- messages: paksa username dari profil (anti-spoof), bersihkan konten, rate limit 6 pesan / 10 detik
create or replace function public.messages_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare uname text; recent int;
begin
  select username into uname from public.profiles where id = new.user_id;
  if uname is null then raise exception 'PROFILE_REQUIRED'; end if;
  new.username := uname;
  new.content  := btrim(regexp_replace(new.content, '[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]', '', 'g'));
  if char_length(new.content) = 0 then raise exception 'EMPTY_MESSAGE'; end if;
  if tg_op = 'INSERT' then
    select count(*) into recent from public.messages
      where user_id = new.user_id and created_at > now() - interval '10 seconds';
    if recent >= 6 then raise exception 'RATE_LIMITED'; end if;
    new.created_at := now();
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_messages_guard on public.messages;
create trigger trg_messages_guard before insert or update on public.messages
  for each row execute function public.messages_guard();

-- senders_global: owner tidak bisa diganti, timestamp otomatis
create or replace function public.senders_touch() returns trigger
language plpgsql as $$
begin
  if tg_op = 'UPDATE' then new.owner_id := old.owner_id; new.created_at := old.created_at; end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_senders_touch on public.senders_global;
create trigger trg_senders_touch before insert or update on public.senders_global
  for each row execute function public.senders_touch();

-- =====================================================================
-- ROW LEVEL SECURITY
-- =====================================================================
alter table public.profiles       enable row level security;
alter table public.messages       enable row level security;
alter table public.senders_global enable row level security;
alter table public.notifications  enable row level security;
alter table public.activity       enable row level security;

-- profiles: semua user login boleh membaca; hanya pemilik yang menulis
drop policy if exists profiles_select on public.profiles;
drop policy if exists profiles_insert on public.profiles;
drop policy if exists profiles_update on public.profiles;
create policy profiles_select on public.profiles for select to authenticated using (true);
create policy profiles_insert on public.profiles for insert to authenticated with check (id = auth.uid());
create policy profiles_update on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- messages: baca semua (chat global); tulis/ubah/hapus hanya milik sendiri
drop policy if exists messages_select on public.messages;
drop policy if exists messages_insert on public.messages;
drop policy if exists messages_update on public.messages;
drop policy if exists messages_delete on public.messages;
create policy messages_select on public.messages for select to authenticated using (true);
create policy messages_insert on public.messages for insert to authenticated with check (user_id = auth.uid());
create policy messages_update on public.messages for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy messages_delete on public.messages for delete to authenticated using (user_id = auth.uid());

-- senders_global: semua user login boleh melihat; pemilik yang mengubah/menghapus
drop policy if exists senders_select on public.senders_global;
drop policy if exists senders_insert on public.senders_global;
drop policy if exists senders_update on public.senders_global;
drop policy if exists senders_delete on public.senders_global;
create policy senders_select on public.senders_global for select to authenticated using (true);
create policy senders_insert on public.senders_global for insert to authenticated with check (owner_id = auth.uid());
create policy senders_update on public.senders_global for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy senders_delete on public.senders_global for delete to authenticated using (owner_id = auth.uid());

-- notifications & activity: privat, hanya milik sendiri
drop policy if exists notif_select on public.notifications;
drop policy if exists notif_insert on public.notifications;
drop policy if exists notif_update on public.notifications;
drop policy if exists notif_delete on public.notifications;
create policy notif_select on public.notifications for select to authenticated using (user_id = auth.uid());
create policy notif_insert on public.notifications for insert to authenticated with check (user_id = auth.uid());
create policy notif_update on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy notif_delete on public.notifications for delete to authenticated using (user_id = auth.uid());

drop policy if exists activity_select on public.activity;
drop policy if exists activity_insert on public.activity;
drop policy if exists activity_delete on public.activity;
create policy activity_select on public.activity for select to authenticated using (user_id = auth.uid());
create policy activity_insert on public.activity for insert to authenticated with check (user_id = auth.uid());
create policy activity_delete on public.activity for delete to authenticated using (user_id = auth.uid());

-- Cabut akses role anon (belum login) dari semua tabel
revoke all on public.profiles, public.messages, public.senders_global, public.notifications, public.activity from anon;
grant select, insert, update, delete on public.profiles, public.messages, public.senders_global, public.notifications, public.activity to authenticated;

-- =====================================================================
-- REALTIME
-- =====================================================================
do $$
declare t text;
begin
  foreach t in array array['messages','senders_global','notifications','profiles'] loop
    if not exists (
      select 1 from pg_publication_tables
      where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t
    ) then
      execute format('alter publication supabase_realtime add table public.%I', t);
    end if;
  end loop;
end $$;

alter table public.messages       replica identity full;
alter table public.senders_global replica identity full;
alter table public.notifications  replica identity full;
