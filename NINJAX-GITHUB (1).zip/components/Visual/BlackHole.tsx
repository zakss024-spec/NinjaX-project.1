import type { ReactNode } from 'react';
import { SafeImage } from '@/components/UI/SafeImage';

/** Black hole: gambar WebP berputar + cincin accretion neon + inti gelap. */
export function BlackHole({ size = 260, children, pulse }: { size?: number; children?: ReactNode; pulse?: boolean }) {
  return (
    <div className={`nx-bh${pulse ? ' is-pulse' : ''}`} style={{ width: size, height: size }} aria-hidden="true">
      <i className="nx-bh__ring" /><i className="nx-bh__ring nx-bh__ring--2" />
      <SafeImage src="/assets/images/blackhole.webp" className="nx-bh__img" width={size} height={size} eager />
      <i className="nx-bh__core" />
      {children ? <div className="nx-bh__center">{children}</div> : null}
    </div>
  );
}

/** Siluet ninja orisinal (SVG inline, tanpa aset eksternal). */
export function NinjaSilhouette({ size = 96, glow = true }: { size?: number; glow?: boolean }) {
  return (
    <svg className={`nx-ninja${glow ? ' has-glow' : ''}`} width={size} height={size} viewBox="0 0 120 120" aria-hidden="true">
      <defs><linearGradient id="nxscarf" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#22d3ee" /><stop offset="1" stopColor="#4ade80" /></linearGradient></defs>
      <path d="M22 112C24 88 40 80 60 80s36 8 38 32z" fill="#120a2a" stroke="#a855f7" strokeWidth="2" strokeLinejoin="round" />
      <path d="M48 82l12 16 12-16z" fill="#22d3ee" fillOpacity=".85" stroke="#4ade80" strokeWidth="1.2" strokeLinejoin="round" />
      <path d="M60 14C41 14 31 28 31 46c0 20 11 34 29 34s29-14 29-34c0-18-10-32-29-32z" fill="#0b0618" stroke="#a855f7" strokeWidth="2.4" strokeLinejoin="round" />
      <rect x="38" y="38" width="44" height="20" rx="10" fill="#050310" stroke="#22d3ee" strokeWidth="2" />
      <g className="nx-ninja__eyes"><path d="M46 48l8-4v8z" fill="#22d3ee" /><path d="M74 48l-8-4v8z" fill="#22d3ee" /></g>
      <path d="M33 33c13-6 41-6 54 0" fill="none" stroke="url(#nxscarf)" strokeWidth="3" strokeLinecap="round" />
      <g className="nx-ninja__tail"><path d="M86 33c10-3 18 1 24 11-8-2-14 0-18 6 2-6 0-12-6-17z" fill="url(#nxscarf)" /></g>
    </svg>
  );
}
