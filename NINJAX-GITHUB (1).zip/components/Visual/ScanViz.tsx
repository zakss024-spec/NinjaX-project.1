'use client';
/** Radar/scan visual untuk lab. Animasi hanya berjalan saat `active`. */
export function ScanViz({ active, pct, label }: { active: boolean; pct: number; label: string }) {
  return (
    <div className={`nx-scanviz${active ? ' is-active' : ''}`} aria-hidden="true">
      <svg viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="54" className="nx-scanviz__r" /><circle cx="60" cy="60" r="38" className="nx-scanviz__r" /><circle cx="60" cy="60" r="22" className="nx-scanviz__r" />
        <path d="M60 6v108M6 60h108" className="nx-scanviz__r" />
        <circle cx="60" cy="60" r="54" className="nx-scanviz__prog" strokeDasharray={`${(pct / 100) * 339} 339`} transform="rotate(-90 60 60)" />
        <g className="nx-scanviz__sweep"><path d="M60 60L60 6A54 54 0 0 1 98 22z" /></g>
        <circle cx="84" cy="40" r="2.2" className="nx-scanviz__blip" /><circle cx="42" cy="78" r="2.2" className="nx-scanviz__blip b2" /><circle cx="70" cy="86" r="2" className="nx-scanviz__blip b3" />
      </svg>
      <b>{active ? `${pct}%` : label}</b>
    </div>
  );
}
