'use client';
import { useEffect, useRef } from 'react';
import { settingsStore } from '@/lib/settings';

/** Partikel neon ringan: ~30fps, berhenti saat tab tersembunyi / setting off, dibersihkan saat unmount. */
export function Particles({ force }: { force?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = cv.getContext('2d'); if (!ctx) return;
    let raf = 0, last = 0, w = 0, h = 0, running = false;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    type P = { x: number; y: number; vx: number; vy: number; r: number; c: string };
    let ps: P[] = [];
    const cols = ['168,85,247', '34,211,238', '74,222,128'];
    const want = () => { const s = settingsStore.get(); return (force || s.particles) && s.animations !== false; };
    const count = () => { const q = settingsStore.get().quality; const base = q === 'low' ? 16 : q === 'high' ? 56 : 32; return Math.round(base * Math.min(1, (w * h) / (390 * 800)) + 10); };

    const resize = () => {
      w = cv.clientWidth; h = cv.clientHeight;
      cv.width = Math.floor(w * dpr); cv.height = Math.floor(h * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ps = Array.from({ length: count() }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 0.3, vy: -0.1 - Math.random() * 0.35, r: 0.6 + Math.random() * 1.8, c: cols[Math.floor(Math.random() * 3)] }));
    };
    const frame = (t: number) => {
      raf = requestAnimationFrame(frame);
      if (t - last < 33) return; last = t;
      ctx.clearRect(0, 0, w, h);
      for (const p of ps) {
        p.x += p.vx; p.y += p.vy;
        if (p.y < -4) { p.y = h + 4; p.x = Math.random() * w; }
        if (p.x < -4) p.x = w + 4; else if (p.x > w + 4) p.x = -4;
        ctx.beginPath(); ctx.fillStyle = `rgba(${p.c},.75)`; ctx.arc(p.x, p.y, p.r, 0, 6.283); ctx.fill();
      }
    };
    const go = () => { if (running || document.hidden || !want()) return; running = true; raf = requestAnimationFrame(frame); };
    const halt = () => { running = false; cancelAnimationFrame(raf); ctx.clearRect(0, 0, w, h); };
    const sync = () => { if (document.hidden || !want()) halt(); else go(); };
    resize(); sync();
    const unsub = settingsStore.subscribe(() => { sync(); });
    window.addEventListener('resize', resize);
    document.addEventListener('visibilitychange', sync);
    return () => { halt(); unsub(); window.removeEventListener('resize', resize); document.removeEventListener('visibilitychange', sync); };
  }, [force]);
  return <canvas ref={ref} className="nx-particles" aria-hidden="true" />;
}

export function Backdrop() {
  return (
    <div className="nx-backdrop" aria-hidden="true">
      <div className="nx-backdrop__glow" /><div className="nx-backdrop__grid" /><div className="nx-backdrop__noise" />
    </div>
  );
}
