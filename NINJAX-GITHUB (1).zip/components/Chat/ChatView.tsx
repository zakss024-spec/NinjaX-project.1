'use client';
import { useCallback, useEffect, useLayoutEffect, useRef, useState, type KeyboardEvent } from 'react';
import { useChat, type PresenceUser } from '@/components/Providers/ChatProvider';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useUI } from '@/components/Providers/UIProvider';
import { Avatar } from '@/components/UI/Avatar';
import { Button } from '@/components/UI/Button';
import { Chip, EmptyState, ErrorState, Skeleton } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { MAX_MESSAGE } from '@/lib/moderation';
import { cx, fmtTime } from '@/lib/utils';
import type { ChatMessage } from '@/lib/types';

function OnlineStrip({ users, meId }: { users: PresenceUser[]; meId: string | null }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="nx-online">
      <button type="button" className="nx-online__bar" onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        <Chip tone="ok" dot>ONLINE: {users.length}</Chip>
        <span className="nx-online__avs">
          {users.slice(0, 6).map((u) => <Avatar key={u.user_id} name={u.display_name} src={u.avatar_url} size={24} />)}
          {users.length > 6 ? <em>+{users.length - 6}</em> : null}
        </span>
        <Icon name={open ? 'close' : 'group'} size={18} />
      </button>
      {open ? (
        <ul className="nx-online__list">
          {users.length === 0 ? <li className="nx-dim">Tidak ada user online.</li> : users.map((u) => (
            <li key={u.user_id}><Avatar name={u.display_name} src={u.avatar_url} size={28} online /><b>{u.display_name}</b><small>@{u.username}{u.user_id === meId ? ' · you' : ''}</small></li>
          ))}
        </ul>
      ) : null}
    </div>
  );
}

function Bubble({ m, mine }: { m: ChatMessage; mine: boolean }) {
  const { edit, remove, retry, discard, errors, online } = useChat();
  const { confirm, toast } = useUI();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(m.content);
  const [busy, setBusy] = useState(false);
  const isOn = online.some((u) => u.user_id === m.user_id);
  const edited = new Date(m.updated_at).getTime() - new Date(m.created_at).getTime() > 1500;
  const display = online.find((u) => u.user_id === m.user_id);

  const save = async () => {
    if (draft.trim() === m.content) { setEditing(false); return; }
    setBusy(true);
    const r = await edit(m.id, draft);
    setBusy(false);
    if (r.ok) setEditing(false); else toast(r.error ?? 'Gagal mengedit', 'error');
  };
  const del = async () => { if (await confirm({ title: 'DELETE MESSAGE', text: 'Hapus pesan ini untuk semua orang?', confirm: 'DELETE', danger: true })) await remove(m.id); };

  return (
    <li className={cx('nx-msg', mine && 'is-mine', m._state && `is-${m._state}`)}>
      {!mine ? <Avatar name={display?.display_name ?? m.username} src={display?.avatar_url} size={34} online={isOn} /> : null}
      <div className="nx-msg__body">
        <div className="nx-msg__meta"><b>{mine ? 'YOU' : (display?.display_name ?? m.username)}</b>{!mine ? <small>@{m.username}</small> : null}<time dateTime={m.created_at}>{fmtTime(m.created_at)}</time>{edited ? <em>edited</em> : null}</div>
        {editing ? (
          <div className="nx-msg__edit">
            <textarea value={draft} onChange={(e) => setDraft(e.target.value)} maxLength={MAX_MESSAGE} rows={2} autoFocus onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void save(); } if (e.key === 'Escape') setEditing(false); }} />
            <div className="nx-row"><Button size="sm" loading={busy} onClick={() => void save()}>SAVE</Button><Button size="sm" variant="ghost" onClick={() => { setEditing(false); setDraft(m.content); }}>CANCEL</Button></div>
          </div>
        ) : (
          <p className="nx-msg__text">{m.content}</p>
        )}
        {m._state === 'sending' ? <small className="nx-msg__st">sending…</small> : null}
        {m._state === 'failed' ? (
          <small className="nx-msg__st is-bad">{errors[m.id] ?? 'Failed to send'} · <button type="button" onClick={() => void retry(m.id)}>RETRY</button> · <button type="button" onClick={() => discard(m.id)}>DISCARD</button></small>
        ) : null}
        {mine && !m._state && !editing ? (
          <div className="nx-msg__acts"><button type="button" onClick={() => setEditing(true)} aria-label="Edit message"><Icon name="edit" size={14} /></button><button type="button" onClick={() => void del()} aria-label="Delete message"><Icon name="trash" size={14} /></button></div>
        ) : null}
      </div>
    </li>
  );
}

export function ChatView() {
  const { messages, status, loading, error, online, unread, send, reload, reconnect, setActive } = useChat();
  const { userId, cloud, cloudError, connect } = useAuth();
  const { toast } = useUI();
  const [text, setText] = useState('');
  const [err, setErr] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const list = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const stick = useRef(true);
  const [away, setAway] = useState(0);
  const lastCount = useRef(0);

  useEffect(() => { setActive(true); return () => setActive(false); }, [setActive]);

  const toBottom = useCallback((smooth = false) => {
    const el = list.current; if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    stick.current = true; setAway(0);
  }, []);

  const onScroll = () => {
    const el = list.current; if (!el) return;
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    if (stick.current) setAway(0);
  };

  useLayoutEffect(() => {
    const added = messages.length - lastCount.current;
    lastCount.current = messages.length;
    if (stick.current) toBottom(added === 1);
    else if (added > 0) setAway((a) => a + added);
  }, [messages, toBottom]);

  useEffect(() => { if (!loading) toBottom(); }, [loading, toBottom]);

  // autosize textarea
  useEffect(() => { const t = input.current; if (!t) return; t.style.height = 'auto'; t.style.height = Math.min(120, t.scrollHeight) + 'px'; }, [text]);

  const submit = async () => {
    if (sending) return;
    setSending(true); setErr(null);
    const r = await send(text);
    setSending(false);
    if (r.ok) { setText(''); stick.current = true; input.current?.focus(); }
    else { setErr(r.error ?? 'Gagal mengirim'); if (r.error && /cepat/.test(r.error)) toast(r.error, 'warn'); }
  };
  const onKey = (e: KeyboardEvent<HTMLTextAreaElement>) => { if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); void submit(); } };

  const offline = cloud !== 'ready';
  const left = MAX_MESSAGE - text.length;

  return (
    <div className="nx-chat">
      <div className="nx-chat__head">
        <div><small>REALTIME</small><h1>GLOBAL CHAT</h1></div>
        <div className="nx-chat__state">
          <Chip tone={status === 'connected' ? 'ok' : status === 'connecting' ? 'warn' : 'bad'} dot>{status === 'connected' ? 'CONNECTED' : status === 'connecting' ? 'CONNECTING' : 'DISCONNECTED'}</Chip>
          {unread > 0 ? <Chip tone="cy">{unread} UNREAD</Chip> : null}
        </div>
      </div>
      <OnlineStrip users={online} meId={userId} />
      {!offline && status === 'disconnected' ? (
        <div className="nx-banner is-bad" role="alert"><span>REALTIME DISCONNECTED</span><small>Mencoba menyambung ulang otomatis…</small><Button size="sm" variant="ghost" onClick={reconnect}>RECONNECT</Button></div>
      ) : null}

      <div className="nx-chat__list" ref={list} onScroll={onScroll} role="log" aria-live="polite" aria-label="Chat messages">
        {offline ? (
          <ErrorState title={cloud === 'connecting' ? 'CONNECTING…' : cloud === 'unconfigured' ? 'SUPABASE NOT CONFIGURED' : 'CHAT OFFLINE'} text={cloudError ?? 'Menghubungkan ke Supabase…'} onRetry={cloud === 'error' ? () => void connect() : undefined} />
        ) : loading ? (
          <Skeleton lines={6} />
        ) : error ? (
          <ErrorState title="FAILED TO LOAD CHAT" text={error} onRetry={reload} />
        ) : messages.length === 0 ? (
          <EmptyState icon="chat" title="NO MESSAGES YET" text="Jadilah yang pertama menyapa komunitas NinjaX." />
        ) : (
          <ul className="nx-msgs">{messages.map((m) => <Bubble key={m.id} m={m} mine={m.user_id === userId} />)}</ul>
        )}
      </div>
      {away > 0 ? <button type="button" className="nx-chat__away" onClick={() => toBottom(true)}>↓ {away} new</button> : null}

      <form className="nx-chat__compose" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <div className="nx-chat__input">
          <textarea ref={input} value={text} onChange={(e) => { setText(e.target.value); if (err) setErr(null); }} onKeyDown={onKey} rows={1} placeholder="Type a message..." maxLength={MAX_MESSAGE + 50} disabled={offline} aria-label="Message" enterKeyHint="send" autoComplete="off" />
          <button type="submit" className="nx-chat__send" disabled={offline || sending || !text.trim()} aria-label="Send message"><Icon name="send" size={20} /><span>SEND</span></button>
        </div>
        <div className="nx-chat__foot"><small className={cx(err && 'is-bad')} role={err ? 'alert' : undefined}>{err ?? 'Enter = kirim · Shift+Enter = baris baru'}</small><small className={cx(left < 40 && 'is-warn')}>{left}</small></div>
      </form>
    </div>
  );
}
