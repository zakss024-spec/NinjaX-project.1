'use client';
import { useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useGlobalSenders } from '@/components/Providers/SendersProvider';
import { useUI } from '@/components/Providers/UIProvider';
import { Avatar } from '@/components/UI/Avatar';
import { Button } from '@/components/UI/Button';
import { Chip, EmptyState, ErrorState, Field, PageHeader, Seg, Skeleton, Tabs } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { Modal } from '@/components/UI/Modal';
import { Panel } from '@/components/UI/Panel';
import { useStore } from '@/hooks/useStore';
import { AVATARS } from '@/lib/images';
import type { Sender, SenderStatus } from '@/lib/types';
import { cx, errMsg, fmtAgo, fmtDateTime } from '@/lib/utils';
import { activityLog, logActivity } from '@/services/activity';
import { pushNotification } from '@/services/notifications';
import { addPrivate, loadPrivate, normalizeInput, onPrivateCorrupt, privateCodeTaken, privateStore, removePrivate, updatePrivate, validateSender, type SenderInput } from '@/services/senders';

type Scope = 'private' | 'global';
const EMPTY: SenderInput = { name: '', sender_code: '', avatar_url: AVATARS[0], status: 'active', note: null };
const STATUS_TONE: Record<SenderStatus, 'ok' | 'warn' | 'off'> = { active: 'ok', inactive: 'warn', disabled: 'off' };

function SenderForm({ initial, title, onClose, onSubmit }: { initial: SenderInput; title: string; onClose: () => void; onSubmit: (v: SenderInput) => Promise<string | null> }) {
  const [v, setV] = useState<SenderInput>(initial);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    const e = validateSender(v);
    if (e) { setErr(e); return; }
    setBusy(true);
    const r = await onSubmit(v);
    setBusy(false);
    if (r) setErr(r); else onClose();
  };
  return (
    <Modal open title={title} onClose={onClose}>
      <form className="nx-form" onSubmit={(e) => { e.preventDefault(); void submit(); }} noValidate>
        <Field label="SENDER NAME"><input className="nx-input" value={v.name} maxLength={32} onChange={(e) => setV({ ...v, name: e.target.value })} placeholder="mis. Ninja Alpha" autoComplete="off" autoFocus /></Field>
        <Field label="SENDER ID" hint="3–24 karakter: huruf, angka, _ atau -. Hanya identitas internal aplikasi."><input className="nx-input" value={v.sender_code} maxLength={24} onChange={(e) => setV({ ...v, sender_code: e.target.value.replace(/\s/g, '') })} placeholder="NINJA-ALPHA" autoComplete="off" autoCapitalize="none" spellCheck={false} /></Field>
        <div className="nx-field"><span className="nx-field__label">AVATAR</span>
          <div className="nx-avpick">{AVATARS.map((a) => <button key={a} type="button" className={cx(v.avatar_url === a && 'is-on')} onClick={() => setV({ ...v, avatar_url: a })} aria-label={`Avatar ${a.slice(-6, -4)}`} aria-pressed={v.avatar_url === a}><Avatar name="x" src={a} size={40} /></button>)}</div>
        </div>
        <div className="nx-field"><span className="nx-field__label">STATUS</span>
          <Seg<SenderStatus> label="Status" value={v.status} onChange={(s) => setV({ ...v, status: s })} options={[{ id: 'active', label: 'ACTIVE' }, { id: 'inactive', label: 'INACTIVE' }, { id: 'disabled', label: 'DISABLED' }]} />
        </div>
        <Field label="NOTE (OPSIONAL)"><input className="nx-input" value={v.note ?? ''} maxLength={120} onChange={(e) => setV({ ...v, note: e.target.value || null })} placeholder="catatan singkat" autoComplete="off" /></Field>
        {err ? <p className="nx-field__err" role="alert">{err}</p> : null}
        <p className="nx-note">Sender hanyalah profil internal NinjaX. Tidak terhubung ke WhatsApp/SMS/email atau akun eksternal.</p>
        <div className="nx-modal__actions"><Button variant="ghost" onClick={onClose}>CANCEL</Button><Button type="submit" loading={busy}>SAVE</Button></div>
      </form>
    </Modal>
  );
}

function Detail({ s, scope, onClose }: { s: Sender; scope: Scope; onClose: () => void }) {
  const acts = useStore(activityLog.store).filter((a) => a.meta && (a.meta as { senderId?: string }).senderId === s.id).slice(0, 12);
  return (
    <Modal open title="SENDER PROFILE" onClose={onClose}>
      <div className="nx-prof">
        <Avatar name={s.name} src={s.avatar_url} size={64} />
        <div><h4>{s.name}</h4><code>{s.sender_code}</code><div className="nx-chips"><Chip tone={STATUS_TONE[s.status]} dot>{s.status.toUpperCase()}</Chip><Chip tone="cy">{scope.toUpperCase()}</Chip></div></div>
      </div>
      <ul className="nx-kv">
        <li><span>Created</span><b>{fmtDateTime(s.created_at)}</b></li>
        <li><span>Updated</span><b>{fmtDateTime(s.updated_at)}</b></li>
        <li><span>Last activity</span><b>{fmtAgo(s.last_activity)}</b></li>
        <li><span>Note</span><b>{s.note || '-'}</b></li>
      </ul>
      <h5 className="nx-sub-h">ACTIVITY HISTORY</h5>
      {acts.length === 0 ? <p className="nx-dim">Belum ada aktivitas tercatat di perangkat ini.</p> : <ul className="nx-feed">{acts.map((a) => <li key={a.id}><time>{fmtDateTime(a.created_at)}</time><span>{a.detail}</span></li>)}</ul>}
    </Modal>
  );
}

type Row = { s: Sender; mine: boolean };

function List({ rows, scope, loading, error, onRetry, onEdit, onDelete, onToggle, onOpen, onPublish, empty }: {
  rows: Row[]; scope: Scope; loading?: boolean; error?: string | null; onRetry?: () => void;
  onEdit: (s: Sender) => void; onDelete: (s: Sender) => void; onToggle: (s: Sender) => void; onOpen: (s: Sender) => void; onPublish?: (s: Sender) => void; empty: React.ReactNode;
}) {
  const [q, setQ] = useState('');
  const [f, setF] = useState<'all' | SenderStatus>('all');
  const [sort, setSort] = useState<'new' | 'name' | 'activity'>('new');
  const shown = useMemo(() => {
    const t = q.trim().toLowerCase();
    const r = rows.filter(({ s }) => (f === 'all' || s.status === f) && (!t || s.name.toLowerCase().includes(t) || s.sender_code.toLowerCase().includes(t)));
    r.sort((a, b) => sort === 'name' ? a.s.name.localeCompare(b.s.name) : sort === 'activity' ? (a.s.last_activity < b.s.last_activity ? 1 : -1) : (a.s.created_at < b.s.created_at ? 1 : -1));
    return r;
  }, [rows, q, f, sort]);

  return (
    <>
      <div className="nx-toolbar">
        <label className="nx-search"><Icon name="search" size={18} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or ID…" aria-label="Search senders" maxLength={40} /></label>
        <select className="nx-input nx-input--sm" value={f} onChange={(e) => setF(e.target.value as typeof f)} aria-label="Filter status"><option value="all">ALL</option><option value="active">ACTIVE</option><option value="inactive">INACTIVE</option><option value="disabled">DISABLED</option></select>
        <select className="nx-input nx-input--sm" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} aria-label="Sort"><option value="new">NEWEST</option><option value="name">NAME</option><option value="activity">ACTIVITY</option></select>
      </div>
      {loading ? <Skeleton lines={5} /> : error ? <ErrorState title="FAILED TO LOAD" text={error} onRetry={onRetry} /> : rows.length === 0 ? empty : shown.length === 0 ? <EmptyState icon="search" title="NO MATCH" text="Tidak ada sender yang cocok dengan filter." /> : (
        <ul className="nx-senders">
          {shown.map(({ s, mine }) => (
            <li key={s.id} className={cx('nx-sender', s.status !== 'active' && 'is-dim')}>
              <button type="button" className="nx-sender__main" onClick={() => onOpen(s)} aria-label={`Open ${s.name}`}>
                <Avatar name={s.name} src={s.avatar_url} size={44} />
                <div><b>{s.name}</b><code>{s.sender_code}</code><small>{fmtAgo(s.last_activity)}{scope === 'global' ? (mine ? ' · yours' : ' · shared') : ''}</small></div>
                <Chip tone={STATUS_TONE[s.status]} dot>{s.status.toUpperCase()}</Chip>
              </button>
              {mine ? (
                <div className="nx-sender__acts">
                  <Button size="sm" variant="ghost" onClick={() => onToggle(s)}>{s.status === 'disabled' ? 'ENABLE' : 'DISABLE'}</Button>
                  <Button size="sm" variant="ghost" onClick={() => onEdit(s)}>EDIT</Button>
                  {onPublish ? <Button size="sm" variant="ghost" onClick={() => onPublish(s)}>PUBLISH</Button> : null}
                  <Button size="sm" variant="danger" onClick={() => onDelete(s)}>DELETE</Button>
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      )}
    </>
  );
}

export function SenderManager({ initialTab }: { initialTab?: Scope }) {
  const [tab, setTab] = useState<Scope>(initialTab ?? 'private');
  const { userId, cloud } = useAuth();
  const { toast, confirm } = useUI();
  const priv = useStore(privateStore);
  const g = useGlobalSenders();
  const [form, setForm] = useState<{ scope: Scope; edit: Sender | null } | null>(null);
  const [detail, setDetail] = useState<{ s: Sender; scope: Scope } | null>(null);

  useEffect(() => { onPrivateCorrupt(() => toast('Data sender private rusak dan telah dipulihkan.', 'warn')); loadPrivate(); }, [toast]);

  const record = (verb: string, s: { id: string; name: string }, scope: Scope) => {
    logActivity('sender', `Sender ${verb}: ${s.name} (${scope})`, { senderId: s.id, scope });
    pushNotification('sender', `Sender ${verb}`, `${s.name} · ${scope}`);
  };

  const saveForm = async (scope: Scope, edit: Sender | null, v: SenderInput): Promise<string | null> => {
    const n = normalizeInput(v);
    try {
      if (scope === 'private') {
        if (privateCodeTaken(n.sender_code, edit?.id)) return 'Sender ID sudah dipakai di daftar private.';
        if (edit) { updatePrivate(edit.id, n); record('edited', edit, scope); }
        else { const s = addPrivate(n); record('created', s, scope); }
      } else {
        if (edit) { const s = await g.update(edit.id, n); record('edited', s, scope); }
        else { const s = await g.add(n); record('created', s, scope); }
      }
      toast(edit ? 'Sender diperbarui' : 'Sender dibuat', 'success');
      return null;
    } catch (e) { return errMsg(e); }
  };

  const del = async (s: Sender, scope: Scope) => {
    if (!(await confirm({ title: 'DELETE SENDER', text: `Hapus sender "${s.name}"? Tindakan ini tidak bisa dibatalkan.`, confirm: 'DELETE', danger: true }))) return;
    try { if (scope === 'private') removePrivate(s.id); else await g.remove(s.id); record('deleted', s, scope); toast('Sender dihapus', 'success'); }
    catch (e) { toast(errMsg(e), 'error'); }
  };
  const toggle = async (s: Sender, scope: Scope) => {
    const next: SenderStatus = s.status === 'disabled' ? 'active' : 'disabled';
    try { if (scope === 'private') updatePrivate(s.id, { status: next }); else await g.update(s.id, { status: next }); record(next === 'active' ? 'enabled' : 'disabled', s, scope); }
    catch (e) { toast(errMsg(e), 'error'); }
  };
  const publish = async (s: Sender) => {
    if (cloud !== 'ready') { toast('Cloud belum terhubung.', 'error'); return; }
    try { await g.add({ name: s.name, sender_code: s.sender_code, avatar_url: s.avatar_url, status: s.status, note: s.note }); record('published', s, 'global'); toast('Dipublikasikan ke Sender Global', 'success'); setTab('global'); }
    catch (e) { toast(errMsg(e), 'error'); }
  };

  const privRows: Row[] = priv.map((s) => ({ s, mine: true }));
  const globRows: Row[] = g.list.map((s) => ({ s, mine: s.owner_id === userId }));

  return (
    <div className="nx-page">
      <PageHeader code="MANAGE" title="MANAGE SENDER" desc="Sender adalah profil internal aplikasi. Tidak dipakai mengirim pesan ke platform luar."
        aside={<Button size="sm" onClick={() => setForm({ scope: tab, edit: null })} disabled={tab === 'global' && cloud !== 'ready'}><Icon name="plus" size={16} /> ADD SENDER</Button>} />
      <Tabs<Scope> label="Sender scope" value={tab} onChange={setTab} tabs={[{ id: 'private', label: 'SENDER PRIVATE', badge: priv.length }, { id: 'global', label: 'SENDER GLOBAL', badge: g.list.length }]} />
      {tab === 'private' ? (
        <Panel title="PRIVATE · THIS DEVICE" aside={<Chip tone="cy">LOCAL</Chip>}>
          <List rows={privRows} scope="private" onEdit={(s) => setForm({ scope: 'private', edit: s })} onDelete={(s) => void del(s, 'private')} onToggle={(s) => void toggle(s, 'private')} onOpen={(s) => setDetail({ s, scope: 'private' })} onPublish={(s) => void publish(s)}
            empty={<EmptyState icon="sender" title="NO PRIVATE SENDERS" text="Sender private hanya tersimpan di perangkat ini." action={<Button size="sm" onClick={() => setForm({ scope: 'private', edit: null })}>CREATE SENDER</Button>} />} />
        </Panel>
      ) : (
        <Panel title="GLOBAL · ALL NINJAX USERS" aside={<Chip tone={g.status === 'connected' ? 'ok' : g.status === 'connecting' ? 'warn' : 'bad'} dot>{g.status === 'connected' ? 'LIVE' : g.status === 'connecting' ? 'SYNC' : 'OFFLINE'}</Chip>}>
          {cloud !== 'ready' ? <ErrorState title={cloud === 'connecting' ? 'CONNECTING…' : 'CLOUD OFFLINE'} text="Sender global membutuhkan koneksi Supabase." /> : (
            <List rows={globRows} scope="global" loading={g.loading} error={g.error} onRetry={g.reload} onEdit={(s) => setForm({ scope: 'global', edit: s })} onDelete={(s) => void del(s, 'global')} onToggle={(s) => void toggle(s, 'global')} onOpen={(s) => setDetail({ s, scope: 'global' })}
              empty={<EmptyState icon="globe" title="NO GLOBAL SENDERS YET" text="Buat sender global — langsung terlihat oleh semua pengguna NinjaX." action={<Button size="sm" onClick={() => setForm({ scope: 'global', edit: null })}>CREATE GLOBAL SENDER</Button>} />} />
          )}
        </Panel>
      )}
      {form ? <SenderForm key={form.edit?.id ?? 'new'} title={`${form.edit ? 'EDIT' : 'ADD'} ${form.scope.toUpperCase()} SENDER`} initial={form.edit ? { name: form.edit.name, sender_code: form.edit.sender_code, avatar_url: form.edit.avatar_url, status: form.edit.status, note: form.edit.note } : EMPTY} onClose={() => setForm(null)} onSubmit={(v) => saveForm(form.scope, form.edit, v)} /> : null}
      {detail ? <Detail s={detail.s} scope={detail.scope} onClose={() => setDetail(null)} /> : null}
    </div>
  );
}
