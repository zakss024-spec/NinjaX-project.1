'use client';
import type { ButtonHTMLAttributes, ReactNode } from 'react';
import { cx } from '@/lib/utils';

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'ghost' | 'danger' | 'success';
  size?: 'md' | 'sm';
  block?: boolean;
  loading?: boolean;
  children?: ReactNode;
};

export function Button({ variant = 'primary', size = 'md', block, loading, className, children, disabled, type = 'button', ...rest }: Props) {
  return (
    <button type={type} className={cx('nx-btn', `nx-btn--${variant}`, size === 'sm' && 'nx-btn--sm', block && 'nx-btn--block', loading && 'is-loading', className)} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading ? <span className="nx-spin" aria-hidden="true" /> : null}
      <span className="nx-btn__label">{children}</span>
    </button>
  );
}
