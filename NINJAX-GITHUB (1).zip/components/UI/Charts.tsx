import { cx } from '@/lib/utils';

export function Gauge({ value, size = 96, label, tone }: { value: number; size?: number; label?: string; tone?: 'ok' | 'warn' | 'bad' }) {
  const v = Math.max(0, Math.min(100, value));
  const t = tone ?? (v >= 85 ? 'ok' : v >= 60 ? 'warn' : 'bad');
  return (
    <div className={cx('nx-gauge', `nx-gauge--${t}`)} style={{ width: size, height: size, ['--v' as string]: v }} role="img" aria-label={`${label ?? 'score'} ${Math.round(v)} percent`}>
      <b style={{ fontSize: size * 0.24 }}>{Math.round(v)}%</b>
    </div>
  );
}

export function BarChart({ data, height = 120 }: { data: Array<{ label: string; value: number }>; height?: number }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="nx-bars" style={{ height }} role="img" aria-label="bar chart">
      {data.map((d) => (
        <div key={d.label} className="nx-bars__col">
          <span>{d.value}</span>
          <i style={{ height: `${Math.max(4, (d.value / max) * 100)}%` }} />
          <small>{d.label}</small>
        </div>
      ))}
    </div>
  );
}

export function HBars({ data }: { data: Array<{ label: string; value: number; tone?: string }> }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <div className="nx-hbars">
      {data.map((d) => (
        <div key={d.label} className="nx-hbars__row">
          <span>{d.label}</span>
          <div><i className={d.tone} style={{ width: `${(d.value / max) * 100}%` }} /></div>
          <b>{d.value}</b>
        </div>
      ))}
    </div>
  );
}

export function Donut({ parts, size = 120, center }: { parts: Array<{ label: string; value: number; color: string }>; size?: number; center?: string }) {
  const total = parts.reduce((a, p) => a + p.value, 0);
  const r = 42, c = 2 * Math.PI * r;
  let off = 0;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="donut chart" className="nx-donut">
      <circle cx="50" cy="50" r={r} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="12" />
      {total > 0 && parts.map((p) => {
        const len = (p.value / total) * c;
        const el = <circle key={p.label} cx="50" cy="50" r={r} fill="none" stroke={p.color} strokeWidth="12" strokeDasharray={`${len} ${c - len}`} strokeDashoffset={-off} transform="rotate(-90 50 50)" />;
        off += len;
        return el;
      })}
      <text x="50" y="55" textAnchor="middle" fontSize="16" fontWeight="700" fill="currentColor">{center ?? total}</text>
    </svg>
  );
}

export function Sparkline({ values, height = 46, color = 'var(--c)' }: { values: number[]; height?: number; color?: string }) {
  const w = 200;
  const max = Math.max(1, ...values), min = Math.min(...values, 0);
  const pts = values.map((v, i) => `${(i / Math.max(1, values.length - 1)) * w},${height - 4 - ((v - min) / (max - min || 1)) * (height - 8)}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${height}`} width="100%" height={height} preserveAspectRatio="none" aria-hidden="true">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      <polyline points={`0,${height} ${pts} ${w},${height}`} fill={color} opacity=".12" stroke="none" />
    </svg>
  );
}
