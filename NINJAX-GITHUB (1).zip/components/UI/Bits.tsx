'use client';
import type { ReactNode } from 'react';
import { cx } from '@/lib/utils';
import { Button } from './Button';
import { Icon } from './Icon';

export function Chip({ tone = 'default', dot, children, className }: { tone?: 'default' | 'ok' | 'warn' | 'bad' | 'cy' | 'off'; dot?: boolean; children: ReactNode; className?: string }) {
  return <span className={cx('nx-chip', `nx-chip--${tone}`, className)}>{dot ? <i className="nx-dot" aria-hidden="true" /> : null}{children}</span>;
}

export function Progress({ value, label, tone = 'default' }: { value: number; label?: string; tone?: 'default' | 'ok' | 'bad' }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className={cx('nx-progress', tone !== 'default' && `nx-progress--${tone}`)} role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={v} aria-label={label ?? 'progress'}>
      <i style={{ width: `${v}%` }} />
    </div>
  );
}

export function Skeleton({ lines = 3, className }: { lines?: number; className?: string }) {
  return (
    <div className={cx('nx-skel', className)} aria-hidden="true">
      {Array.from({ length: lines }).map((_, i) => <i key={i} style={{ width: `${95 - ((i * 17) % 40)}%` }} />)}
    </div>
  );
}

export function EmptyState({ icon = 'info', title, text, action }: { icon?: string; title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="nx-empty">
      <div className="nx-empty__art"><Icon name={icon} size={30} /></div>
      <b>{title}</b>
      {text ? <p>{text}</p> : null}
      {action}
    </div>
  );
}

export function ErrorState({ title = 'SOMETHING WENT WRONG', text, onRetry }: { title?: string; text?: string; onRetry?: () => void }) {
  return (
    <div className="nx-empty nx-empty--bad" role="alert">
      <div className="nx-empty__art"><Icon name="close" size={30} /></div>
      <b>{title}</b>
      {text ? <p>{text}</p> : null}
      {onRetry ? <Button size="sm" variant="ghost" onClick={onRetry}>RETRY</Button> : null}
    </div>
  );
}

export function Tabs<T extends string>({ tabs, value, onChange, label }: { tabs: Array<{ id: T; label: string; badge?: number }>; value: T; onChange: (t: T) => void; label?: string }) {
  return (
    <div className="nx-tabs" role="tablist" aria-label={label}>
      {tabs.map((t) => (
        <button key={t.id} type="button" role="tab" aria-selected={value === t.id} className={cx('nx-tab', value === t.id && 'is-on')} onClick={() => onChange(t.id)}>
          {t.label}{t.badge ? <em>{t.badge}</em> : null}
        </button>
      ))}
    </div>
  );
}

export function Seg<T extends string>({ options, value, onChange, label }: { options: Array<{ id: T; label: string }>; value: T; onChange: (v: T) => void; label?: string }) {
  return (
    <div className="nx-seg" role="group" aria-label={label}>
      {options.map((o) => (
        <button key={o.id} type="button" aria-pressed={value === o.id} className={cx(value === o.id && 'is-on')} onClick={() => onChange(o.id)}>{o.label}</button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={cx('nx-switch', checked && 'is-on')} onClick={() => onChange(!checked)}><i /></button>;
}

export function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string | null; children: ReactNode }) {
  return (
    <label className="nx-field">
      <span className="nx-field__label">{label}</span>
      {children}
      {hint && !error ? <small className="nx-field__hint">{hint}</small> : null}
      {error ? <small className="nx-field__err" role="alert">{error}</small> : null}
    </label>
  );
}

export function PageHeader({ code, title, desc, aside }: { code: string; title: string; desc?: string; aside?: ReactNode }) {
  return (
    <header className="nx-pagehead">
      <div>
        <small>{code}</small>
        <h1>{title}</h1>
        {desc ? <p>{desc}</p> : null}
      </div>
      {aside ? <div className="nx-pagehead__aside">{aside}</div> : null}
    </header>
  );
}

export function SimTag() { return <span className="nx-simtag">SIMULATED · LOCAL ONLY</span>; }
