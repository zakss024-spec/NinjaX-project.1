import type { HTMLAttributes, ReactNode } from 'react';
import { cx } from '@/lib/utils';

type Props = HTMLAttributes<HTMLElement> & { title?: ReactNode; aside?: ReactNode; tone?: 'default' | 'holo' | 'ok' | 'warn' | 'bad'; flush?: boolean };

/** Panel kaca dengan corner bracket neon. */
export function Panel({ title, aside, tone = 'default', flush, className, children, ...rest }: Props) {
  return (
    <section className={cx('nx-panel', tone !== 'default' && `nx-panel--${tone}`, flush && 'nx-panel--flush', className)} {...rest}>
      <i className="nx-br nx-br--tl" aria-hidden="true" /><i className="nx-br nx-br--br" aria-hidden="true" />
      {(title || aside) && (
        <header className="nx-panel__head">
          <h3>{title}</h3>
          {aside ? <div className="nx-panel__aside">{aside}</div> : null}
        </header>
      )}
      {children}
    </section>
  );
}
