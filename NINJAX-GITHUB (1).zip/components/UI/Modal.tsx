'use client';
import { useEffect, useRef, type ReactNode } from 'react';
import { Icon } from './Icon';

type Props = { open: boolean; title: string; onClose: () => void; children: ReactNode; size?: 'sm' | 'md' | 'lg' };

export function Modal({ open, title, onClose, children, size = 'md' }: Props) {
  const box = useRef<HTMLDivElement>(null);
  const prev = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return;
    prev.current = document.activeElement as HTMLElement | null;
    document.body.classList.add('nx-lock');
    const focusables = () => Array.from(box.current?.querySelectorAll<HTMLElement>('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])') ?? []).filter((e) => !e.hasAttribute('disabled'));
    const t = setTimeout(() => { const f = box.current?.querySelector<HTMLElement>('[autofocus],input,select,textarea,button:not(.nx-modal__x)') ?? focusables()[0]; f?.focus(); }, 30);
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.stopPropagation(); onClose(); return; }
      if (e.key !== 'Tab') return;
      const f = focusables(); if (!f.length) return;
      const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    document.addEventListener('keydown', key);
    return () => {
      clearTimeout(t);
      document.removeEventListener('keydown', key);
      document.body.classList.remove('nx-lock');
      prev.current?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="nx-modal" role="presentation">
      <div className="nx-modal__bg" onClick={onClose} />
      <div ref={box} className={`nx-modal__box nx-modal__box--${size}`} role="dialog" aria-modal="true" aria-label={title}>
        <i className="nx-br nx-br--tl" aria-hidden="true" /><i className="nx-br nx-br--br" aria-hidden="true" />
        <div className="nx-modal__head">
          <h3>{title}</h3>
          <button type="button" className="nx-iconbtn nx-modal__x" onClick={onClose} aria-label="Close"><Icon name="close" size={18} /></button>
        </div>
        <div className="nx-modal__body">{children}</div>
      </div>
    </div>
  );
}
