'use client';
import { useState } from 'react';
import { FALLBACK_IMG } from '@/lib/images';
import { cx } from '@/lib/utils';

type Props = { src: string; alt?: string; width?: number; height?: number; className?: string; eager?: boolean; round?: boolean };

/**
 * Gambar yang tidak pernah rusak/blank: src -> fallback.webp -> placeholder CSS.
 * Path yang gagal dicatat lewat console.warn (dipakai juga halaman IMAGE TEST).
 */
export function SafeImage({ src, alt = '', width, height, className, eager, round }: Props) {
  const [stage, setStage] = useState<0 | 1 | 2>(0);
  const cur = stage === 0 ? src : FALLBACK_IMG;
  if (stage === 2) return <span className={cx('nx-img-ph', round && 'is-round', className)} style={{ width, height }} role="img" aria-label={alt || 'image placeholder'} />;
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      key={cur}
      src={cur}
      alt={alt}
      width={width}
      height={height}
      className={className}
      loading={eager ? 'eager' : 'lazy'}
      decoding="async"
      draggable={false}
      onError={() => {
        console.warn('[NinjaX] image failed:', cur);
        setStage((s) => (s === 0 && src !== FALLBACK_IMG ? 1 : 2));
      }}
    />
  );
}
