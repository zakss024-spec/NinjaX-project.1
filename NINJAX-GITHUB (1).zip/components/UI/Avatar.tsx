'use client';
import { cx, hash32 } from '@/lib/utils';
import { SafeImage } from './SafeImage';

const GRAD = ['#a855f7,#22d3ee', '#22d3ee,#4ade80', '#ff4d8d,#a855f7', '#4ade80,#22d3ee', '#fbbf24,#ff4d8d', '#7c3aed,#22d3ee'];

export function Avatar({ name, src, size = 36, online, className }: { name: string; src?: string | null; size?: number; online?: boolean; className?: string }) {
  const g = GRAD[hash32(name || '?') % GRAD.length];
  const initials = (name || '?').replace(/[^A-Za-z0-9 ]/g, '').trim().split(/\s+/).map((s) => s[0]).join('').slice(0, 2).toUpperCase() || '?';
  return (
    <span className={cx('nx-avatar', className)} style={{ width: size, height: size, ['--g' as string]: `linear-gradient(135deg, ${g})` }} aria-hidden="true">
      {src ? <SafeImage src={src} width={size} height={size} round /> : <b style={{ fontSize: size * 0.38 }}>{initials}</b>}
      {online !== undefined ? <i className={cx('nx-avatar__dot', online && 'is-on')} /> : null}
    </span>
  );
}
