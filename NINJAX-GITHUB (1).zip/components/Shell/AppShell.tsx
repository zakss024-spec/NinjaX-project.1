'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { gateRoute } from '@/lib/auth';
import { MAIN_NAV, MORE_NAV, labelFor, type NavItem } from '@/lib/nav';
import { cx } from '@/lib/utils';
import { notifLog } from '@/services/notifications';
import { logActivity } from '@/services/activity';
import { useStore } from '@/hooks/useStore';
import { useSettings } from '@/hooks/useSettings';
import { useAuth } from '@/components/Providers/AuthProvider';
import { ChatProvider, useChat } from '@/components/Providers/ChatProvider';
import { SendersProvider } from '@/components/Providers/SendersProvider';
import { NotifSync } from '@/components/Providers/NotifSync';
import { useUI } from '@/components/Providers/UIProvider';
import { Icon } from '@/components/UI/Icon';
import { Button } from '@/components/UI/Button';
import { Avatar } from '@/components/UI/Avatar';
import { Particles, Backdrop } from '@/components/Visual/Particles';
import { SafeImage } from '@/components/UI/SafeImage';

function isActive(item: NavItem, path: string) {
  const bases = item.match ?? [item.href];
  return bases.some((b) => path === b || path.startsWith(b + '/'));
}

function CloudBanner() {
  const { cloud, cloudError, connect } = useAuth();
  if (cloud === 'ready' || cloud === 'idle') return null;
  const bad = cloud === 'error' || cloud === 'unconfigured';
  return (
    <div className={cx('nx-banner', bad ? 'is-bad' : 'is-info')} role={bad ? 'alert' : 'status'}>
      <span>{cloud === 'connecting' ? 'CONNECTING TO SUPABASE…' : cloud === 'unconfigured' ? 'SUPABASE NOT CONFIGURED' : 'CLOUD OFFLINE'}</span>
      {cloudError ? <small>{cloudError}</small> : null}
      {bad && cloud === 'error' ? <Button size="sm" variant="ghost" onClick={() => void connect()}>RETRY</Button> : null}
    </div>
  );
}

function RtPill() {
  const { status } = useChat();
  const { cloud } = useAuth();
  const ok = cloud === 'ready' && status === 'connected';
  return (
    <span className={cx('nx-rt', ok ? 'is-ok' : status === 'connecting' && cloud === 'ready' ? 'is-wait' : 'is-bad')} title="Realtime status">
      <i />{ok ? 'REALTIME CONNECTED' : cloud === 'ready' && status === 'connecting' ? 'CONNECTING…' : 'REALTIME DISCONNECTED'}
    </span>
  );
}

function Shell({ children }: { children: ReactNode }) {
  const path = usePathname() || '/';
  const { profile, logout } = useAuth();
  const { unread } = useChat();
  const { confirm } = useUI();
  const router = useRouter();
  const notifs = useStore(notifLog.store);
  const unreadN = notifs.filter((n) => !n.read).length;
  const [drawer, setDrawer] = useState(false);
  const [kb, setKb] = useState(false);
  const lastPath = useRef('');
  const main = useRef<HTMLElement>(null);

  // log modul yang dibuka + reset scroll
  useEffect(() => {
    setDrawer(false);
    main.current?.scrollTo?.(0, 0); window.scrollTo(0, 0);
    if (lastPath.current !== path) { lastPath.current = path; logActivity('module', `Opened ${labelFor(path)}`); }
  }, [path]);

  // sembunyikan bottom-nav saat keyboard virtual terbuka (Android)
  useEffect(() => {
    const vv = window.visualViewport; if (!vv) return;
    const base = () => Math.max(window.innerHeight, vv.height);
    const f = () => {
      const el = document.activeElement as HTMLElement | null;
      const typing = !!el && /INPUT|TEXTAREA|SELECT/.test(el.tagName);
      const open = typing && vv.height < base() * 0.78;
      setKb(open);
      document.documentElement.style.setProperty('--vvh', `${vv.height}px`);
    };
    f();
    vv.addEventListener('resize', f); document.addEventListener('focusin', f); document.addEventListener('focusout', () => setTimeout(f, 60));
    return () => { vv.removeEventListener('resize', f); document.removeEventListener('focusin', f); };
  }, []);

  useEffect(() => { document.body.classList.toggle('nx-lock', drawer); return () => document.body.classList.remove('nx-lock'); }, [drawer]);
  useEffect(() => {
    if (!drawer) return;
    const k = (e: KeyboardEvent) => { if (e.key === 'Escape') setDrawer(false); };
    document.addEventListener('keydown', k); return () => document.removeEventListener('keydown', k);
  }, [drawer]);

  const doLogout = async () => {
    const ok = await confirm({ title: 'LOGOUT', text: 'Keluar dari sesi NinjaX? Anda perlu login dan fingerprint lagi.', confirm: 'LOGOUT', danger: true });
    if (!ok) return;
    await logout(); router.replace('/login');
  };

  const links = useMemo(() => [...MAIN_NAV, ...MORE_NAV], []);
  const badgeFor = (href: string) => (href === '/chat' ? unread : href === '/notifications' ? unreadN : 0);

  return (
    <div className="nx-app" data-kb={kb ? 'open' : 'closed'}>
      <Backdrop /><Particles />
      <aside className="nx-side" aria-label="Sidebar">
        <Link href="/dashboard" className="nx-brand"><SafeImage src="/assets/images/ninja.webp" width={36} height={36} eager /><div><b>NINJAX</b><small>CYBER OPERATIONS</small></div></Link>
        <nav>
          {links.map((n) => (
            <Link key={n.href} href={n.href} className={cx('nx-side__link', isActive(n, path) && 'is-on')} aria-current={isActive(n, path) ? 'page' : undefined}>
              <Icon name={n.icon} size={20} /><span>{n.label}</span>{badgeFor(n.href) ? <em>{badgeFor(n.href)}</em> : null}
            </Link>
          ))}
        </nav>
        <div className="nx-side__foot">
          <div className="nx-me"><Avatar name={profile?.display_name ?? 'Ninja'} src={profile?.avatar_url} size={34} online /><div><b>{profile?.display_name ?? 'NINJA'}</b><small>@{profile?.username ?? '...'}</small></div></div>
          <Button size="sm" variant="ghost" block onClick={doLogout}>LOGOUT</Button>
        </div>
      </aside>

      <div className="nx-col">
        <header className="nx-top">
          <button type="button" className="nx-iconbtn nx-top__menu" onClick={() => setDrawer(true)} aria-label="Menu" aria-expanded={drawer}><Icon name="menu" /></button>
          <div className="nx-top__title"><b>NINJAX</b><small>{labelFor(path)}</small></div>
          <RtPill />
          <Link href="/notifications" className="nx-iconbtn nx-bell" aria-label={`Notifications${unreadN ? `, ${unreadN} unread` : ''}`}><Icon name="bell" />{unreadN ? <em>{unreadN > 9 ? '9+' : unreadN}</em> : null}</Link>
        </header>
        <CloudBanner />
        <main ref={main} className="nx-main" id="main">{children}</main>
      </div>

      <nav className="nx-bnav" aria-label="Main navigation">
        {MAIN_NAV.map((n) => (
          <Link key={n.href} href={n.href} className={cx('nx-bnav__item', isActive(n, path) && 'is-on')} aria-current={isActive(n, path) ? 'page' : undefined}>
            <span className="nx-bnav__ico"><Icon name={n.icon} size={22} />{badgeFor(n.href) ? <em>{badgeFor(n.href) > 9 ? '9+' : badgeFor(n.href)}</em> : null}</span>
            <span>{n.label}</span>
          </Link>
        ))}
      </nav>

      <div className={cx('nx-drawer__bg', drawer && 'is-open')} onClick={() => setDrawer(false)} />
      <aside className={cx('nx-drawer', drawer && 'is-open')} aria-hidden={!drawer} aria-label="Menu">
        <div className="nx-drawer__head">
          <div className="nx-me"><Avatar name={profile?.display_name ?? 'Ninja'} src={profile?.avatar_url} size={40} online /><div><b>{profile?.display_name ?? 'NINJA'}</b><small>@{profile?.username ?? '...'}</small></div></div>
          <button type="button" className="nx-iconbtn" onClick={() => setDrawer(false)} aria-label="Close menu"><Icon name="close" /></button>
        </div>
        <div className="nx-drawer__list">
          {links.map((n) => (
            <Link key={n.href} href={n.href} tabIndex={drawer ? 0 : -1} className={cx('nx-drawer__item', isActive(n, path) && 'is-on')}>
              <Icon name={n.icon} size={20} /><span>{n.label}</span>{badgeFor(n.href) ? <em>{badgeFor(n.href)}</em> : null}
            </Link>
          ))}
        </div>
        <Button variant="danger" block onClick={doLogout} tabIndex={drawer ? 0 : -1}>LOGOUT</Button>
      </aside>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { hydrated, gate } = useAuth();
  const router = useRouter();
  useSettings();
  useEffect(() => { if (hydrated && gate !== 'ready') router.replace(gateRoute(gate)); }, [hydrated, gate, router]);

  if (!hydrated || gate !== 'ready') {
    return <div className="nx-boot" role="status" aria-label="Loading"><Backdrop /><div className="nx-boot__ring" /><small>VERIFYING SESSION…</small></div>;
  }
  return (
    <ChatProvider>
      <SendersProvider>
        <NotifSync />
        <Shell>{children}</Shell>
      </SendersProvider>
    </ChatProvider>
  );
}
