'use client';
import { Button } from '@/components/UI/Button';
import { Chip } from '@/components/UI/Bits';
import { Gauge } from '@/components/UI/Charts';
import { useUI } from '@/components/Providers/UIProvider';
import type { SimStage } from '@/hooks/useSimulation';
import { BAN_REASONS, BUG_TYPES, GROUPS, GROUP_SCANS, HACK_TARGETS, ISSUE_TYPES, SEVERITIES, VULN_KB, banResult, bugResult, groupResult, hackResult, reportText, sevTone, traceId, validTarget, type Sev } from '@/lib/sim';
import { cleanText } from '@/lib/utils';
import type { LabConfig, Values } from './SimLab';

const SEV_OPTS = SEVERITIES.map((s) => ({ id: s, label: s.toUpperCase() }));
const stages = (a: string[], b: string[], c: string[], d: string[], e: string[]): SimStage[] => [
  { at: 0, status: 'INITIALIZING', lines: a }, { at: 20, status: 'SCANNING', lines: b }, { at: 45, status: 'ANALYZING', lines: c },
  { at: 70, status: 'PROCESSING', lines: d }, { at: 92, status: 'FINALIZING', lines: e },
];
const label = (v: string, max = 32) => (/^[A-Za-z0-9 _.-]{3,32}$/.test(v.trim()) ? null : `3–${max} karakter: huruf, angka, spasi, _ . -`);

/* ================= BUG ================= */
export const bugLab: LabConfig<ReturnType<typeof bugResult>> = {
  code: 'LAB 01', title: 'BUG LAB', kind: 'lab:bug', startLabel: 'START BUG SIMULATION',
  desc: 'Simulasi visual lokal pada target virtual — tidak ada payload, pengiriman, atau aksi ke sistem nyata.',
  fields: [
    { id: 'target', label: 'TARGET LABEL', type: 'select', def: 'virtual-device-a', options: [{ id: 'virtual-device-a', label: 'VIRTUAL DEVICE A' }, { id: 'virtual-device-b', label: 'VIRTUAL DEVICE B' }, { id: 'demo-app-ui', label: 'DEMO APP UI' }, { id: 'sandbox-chat', label: 'SANDBOX CHAT' }] },
    { id: 'type', label: 'BUG TYPE', type: 'select', def: 'message-ui', options: BUG_TYPES.map((b) => ({ id: b.id, label: b.label })) },
    { id: 'sev', label: 'SEVERITY', type: 'seg', def: 'medium', options: SEV_OPTS },
  ],
  stages: (v) => stages([`[*] boot bug-lab sandbox · target=${v.target}`, '[*] loading virtual device profile'], ['[*] scanning render tree…', '[*] hooking virtual event bus'], ['[*] analyzing component states…', `[*] type=${v.type} severity=${v.sev}`], ['[*] correlating traces…', '[*] building findings'], ['[+] findings compiled', '[+] simulation sealed (local only)']),
  build: (v) => bugResult(v.target, v.type, v.sev as Sev),
  summary: (v, r) => `Bug sim ${v.target} · ${r.type} · ${v.sev} → ${r.findings.length} findings`,
  Result: ({ r }) => (
    <div className="nx-res">
      <div className="nx-res__top"><Gauge value={r.score} label="stability" /><ul className="nx-kv"><li><span>Trace</span><b>{r.trace}</b></li><li><span>Type</span><b>{r.type}</b></li><li><span>Findings</span><b>{r.findings.length}</b></li><li><span>Duration</span><b>{r.duration} ms (sim)</b></li></ul></div>
      <ul className="nx-cards">{r.findings.map((f) => <li key={f.id} className={`is-${sevTone(f.severity)}`}><Chip tone={sevTone(f.severity)}>{f.severity.toUpperCase()}</Chip><div><b>{f.component}</b><p>{f.note}</p><code>{f.id}</code></div></li>)}</ul>
    </div>
  ),
};

/* ================= BUG GROUP ================= */
export const bugGroupLab: LabConfig<ReturnType<typeof groupResult>> = {
  code: 'LAB 02', title: 'BUG GROUP', kind: 'lab:bug-group', startLabel: 'START GROUP SCAN',
  desc: 'Pemindaian simulasi pada grup fiktif lokal. Tidak ada tindakan terhadap grup atau platform eksternal.',
  fields: [
    { id: 'group', label: 'GROUP (LOCAL DUMMY)', type: 'select', def: 'ninja-squad', options: GROUPS.map((g) => ({ id: g.id, label: `${g.label} · ${g.members} members` })) },
    { id: 'scan', label: 'SCAN TYPE', type: 'select', def: 'ui', options: GROUP_SCANS },
  ],
  stages: (v) => stages([`[*] group selector → ${v.group}`, '[*] opening local group sandbox'], ['[*] enumerating dummy members…', '[*] sampling event stream'], ['[*] analyzing group state…'], ['[*] replaying simulated events…'], ['[+] group health computed', '[+] no external action performed']),
  build: (v) => groupResult(v.group, v.scan),
  summary: (v, r) => `Group scan ${r.group} · ${v.scan} → ${r.anomalies} anomalies, health ${r.health}%`,
  Result: ({ r }) => (
    <div className="nx-res">
      <div className="nx-res__top"><Gauge value={r.health} label="group health" /><ul className="nx-kv"><li><span>Group</span><b>{r.group}</b></li><li><span>Members scanned</span><b>{r.scanned}/{r.members}</b></li><li><span>Anomalies</span><b>{r.anomalies}</b></li></ul></div>
      <ul className="nx-feed">{r.events.map((e, i) => <li key={i}><time>{e.t}</time><span>{e.ev} — <b className={e.ok ? 'is-ok' : 'is-warn'}>{e.ok ? 'OK' : 'ANOMALY'}</b></span></li>)}</ul>
    </div>
  ),
};

/* ================= BAN GROUP ================= */
export const banGroupLab: LabConfig<ReturnType<typeof banResult>> = {
  code: 'LAB 03', title: 'BAN GROUP', kind: 'lab:ban-group', startLabel: 'SIMULATE MODERATION',
  desc: 'Laboratorium moderasi/keamanan simulasi. Tidak ada ban, report, atau request ke platform mana pun.',
  fields: [
    { id: 'group', label: 'GROUP IDENTIFIER (LABEL)', type: 'text', def: 'GRP-DEMO-01', maxLength: 32, validate: (v) => label(v), hint: 'Label fiktif untuk simulasi.' },
    { id: 'reason', label: 'REASON', type: 'select', def: 'spam', options: BAN_REASONS },
    { id: 'sev', label: 'SEVERITY', type: 'seg', def: 'medium', options: SEV_OPTS },
  ],
  stages: (v) => stages([`[*] checking group ${cleanText(v.group, 32)}`], ['[*] analyzing activity signals…'], ['[*] evaluating policy rules…', `[*] reason=${v.reason}`], ['[*] processing decision (simulated)…'], ['[+] decision recorded in local audit log', '[+] NO external ban/report was sent']),
  build: (v) => banResult(cleanText(v.group, 32), v.reason, v.sev as Sev),
  summary: (v, r) => `Ban sim ${r.group} · ${r.reason} · ${v.sev} → ${r.verdict}`,
  Result: ({ r }) => (
    <div className="nx-res">
      <div className="nx-verdict is-bad"><b>{r.verdict}</b><small>BAN GROUP SIMULATION COMPLETE</small></div>
      <ul className="nx-kv"><li><span>Group</span><b>{r.group}</b></li><li><span>Reason</span><b>{r.reason}</b></li><li><span>Severity</span><b>{r.severity.toUpperCase()}</b></li><li><span>Confidence</span><b>{r.confidence}%</b></li><li><span>Reviewers (sim)</span><b>{r.reviewers}</b></li><li><span>Audit ID</span><b>{r.audit}</b></li></ul>
    </div>
  ),
};

/* ================= HACK ================= */
export const hackLab: LabConfig<ReturnType<typeof hackResult>> = {
  code: 'LAB 04', title: 'HACK LAB', kind: 'lab:hack', startLabel: 'RUN SECURITY SCAN',
  desc: 'Scanner keamanan simulasi. Hanya target dummy/lokal; tidak ada request jaringan ke target.',
  fields: [
    { id: 'target', label: 'TARGET (DUMMY ONLY)', type: 'text', def: 'target.local', maxLength: 64, hint: 'Hanya *.local, *.test, *.example, 192.0.2.x, 198.51.100.x, 203.0.113.x, 192.168.x.x.', validate: (v) => (validTarget(v) ? null : 'Target harus fiktif/lokal (mis. target.local, 192.0.2.10).') },
    { id: 'mode', label: 'SCAN MODE', type: 'seg', def: 'full', options: [{ id: 'ports', label: 'PORTS' }, { id: 'vuln', label: 'VULN' }, { id: 'full', label: 'FULL' }] },
  ],
  stages: (v) => stages([`[*] target accepted: ${v.target.trim().toLowerCase()} (dummy)`, '[*] no network request will be made'], ['[*] generating simulated port map…'], ['[*] matching simulated signatures…'], ['[*] ranking findings…'], ['[+] scan report ready', '[+] all data is fictional']),
  build: (v) => hackResult(v.target.trim().toLowerCase(), v.mode),
  summary: (v, r) => `Hack scan ${r.target} · ${v.mode} → ${r.vulns.length} findings, risk ${r.risk}`,
  Result: ({ r, v }) => (
    <div className="nx-res">
      <div className="nx-res__top"><Gauge value={100 - r.risk} label="target health" /><ul className="nx-kv"><li><span>Target</span><b>{r.target}</b></li><li><span>OS (sim)</span><b>{r.os}</b></li><li><span>Risk score</span><b className={r.risk > 60 ? 'is-bad' : r.risk > 35 ? 'is-warn' : 'is-ok'}>{r.risk}/100</b></li></ul></div>
      {v.mode !== 'vuln' ? <div className="nx-tablewrap"><table className="nx-table"><thead><tr><th>PORT</th><th>SERVICE</th><th>STATE</th></tr></thead><tbody>{r.ports.map((p) => <tr key={p.port}><td>{p.port}</td><td>{p.name}</td><td><Chip tone={p.state === 'open' ? 'ok' : p.state === 'filtered' ? 'warn' : 'off'}>{p.state.toUpperCase()}</Chip></td></tr>)}</tbody></table></div> : null}
      {v.mode !== 'ports' ? <ul className="nx-cards">{r.vulns.map((x) => <li key={x.id} className={`is-${sevTone(x.severity)}`}><Chip tone={sevTone(x.severity)}>{x.severity.toUpperCase()}</Chip><div><b>{x.name}</b><p>Mitigasi: {x.fix}</p><code>{x.id}</code></div></li>)}</ul> : null}
    </div>
  ),
};

/* ================= REPORT ================= */
function ReportPreview({ v }: { v: Values }) {
  const { toast } = useUI();
  const text = reportText({ issue: v.issue, sev: v.sev, target: v.target, summary: cleanText(v.summary, 200) });
  const copy = async () => { try { await navigator.clipboard.writeText(text); toast('Laporan disalin', 'success'); } catch { toast('Tidak bisa menyalin (izin clipboard).', 'error'); } };
  const dl = () => {
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = `ninjax-report-${traceId(text).slice(4)}.txt`; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return (
    <div className="nx-res">
      <pre className="nx-pre" tabIndex={0}>{text}</pre>
      <div className="nx-row"><Button size="sm" variant="ghost" onClick={() => void copy()}>COPY</Button><Button size="sm" variant="ghost" onClick={dl}>DOWNLOAD .TXT</Button></div>
      <div className="nx-verdict is-ok"><b>REPORT SIMULATION COMPLETE</b><small>Tidak dikirim ke platform mana pun</small></div>
    </div>
  );
}
export const reportLab: LabConfig<{ id: string }> = {
  code: 'LAB 05', title: 'REPORT LAB', kind: 'lab:report', startLabel: 'GENERATE REPORT',
  desc: 'Generator laporan keamanan simulasi. Laporan dibuat lokal dan tidak dikirim ke platform eksternal.',
  fields: [
    { id: 'issue', label: 'ISSUE TYPE', type: 'select', def: 'config', options: ISSUE_TYPES },
    { id: 'sev', label: 'SEVERITY', type: 'seg', def: 'medium', options: SEV_OPTS },
    { id: 'target', label: 'TARGET LABEL', type: 'text', def: 'demo-app', maxLength: 32, validate: (v) => label(v) },
    { id: 'summary', label: 'SUMMARY', type: 'textarea', def: 'Contoh temuan pada aplikasi demo.', maxLength: 200, validate: (v) => (v.trim().length >= 5 ? null : 'Ringkasan minimal 5 karakter.') },
  ],
  stages: (v) => stages(['[*] preparing report template'], ['[*] validating fields…'], ['[*] queued for local render'], ['[*] processing summary…', `[*] issue=${v.issue}`], ['[+] report generated locally', '[+] not transmitted anywhere']),
  build: (v) => ({ id: traceId(v.issue + v.sev + v.target + v.summary) }),
  summary: (v, r) => `Report ${r.id} · ${v.issue} · ${v.sev} · ${v.target}`,
  Result: ({ v }) => <ReportPreview v={v} />,
};

/* ================= EXPLOIT (edukatif) ================= */
export const exploitLab: LabConfig<(typeof VULN_KB)[number]> = {
  code: 'LAB 06', title: 'EXPLOIT LAB', kind: 'lab:exploit', startLabel: 'ANALYZE VULNERABILITY',
  desc: 'Simulasi edukatif: memahami penyebab, dampak, dan mitigasi kerentanan. Tidak ada payload yang bisa dipakai terhadap sistem nyata.',
  fields: [
    { id: 'vuln', label: 'VULNERABILITY TYPE', type: 'select', def: 'sqli', options: VULN_KB.map((x) => ({ id: x.id, label: x.label })) },
    { id: 'env', label: 'ENVIRONMENT', type: 'seg', def: 'sandbox', options: [{ id: 'sandbox', label: 'SANDBOX' }, { id: 'training', label: 'TRAINING APP' }] },
  ],
  stages: (v) => stages([`[*] loading knowledge base: ${v.vuln}`], ['[*] building abstract scenario (inert)…'], ['[*] analyzing root cause…'], ['[*] mapping to OWASP category…'], ['[+] mitigation plan ready', '[+] no payload executed']),
  build: (v) => VULN_KB.find((x) => x.id === v.vuln) ?? VULN_KB[0],
  summary: (v, r) => `Exploit analysis ${r.label} · ${v.env} · ${r.sev}`,
  Result: ({ r }) => (
    <div className="nx-res">
      <div className="nx-res__top"><Chip tone={sevTone(r.sev)}>{r.sev.toUpperCase()}</Chip><b>{r.label}</b><small className="nx-dim">{r.owasp}</small></div>
      <h5 className="nx-sub-h">SIMULATED PAYLOAD REPRESENTATION</h5>
      <div className="nx-token">⟦ INERT · {r.token} ⟧</div>
      <h5 className="nx-sub-h">ANALYSIS</h5>
      <ul className="nx-kv"><li><span>Root cause</span><b>{r.cause}</b></li><li><span>Impact</span><b>{r.impact}</b></li></ul>
      <h5 className="nx-sub-h">MITIGATION</h5>
      <ul className="nx-checks">{r.fix.map((f) => <li key={f}>{f}</li>)}</ul>
    </div>
  ),
};

export { HACK_TARGETS };

/* ================= OSINT (data fiktif) ================= */
import { BarChart } from '@/components/UI/Charts';
import { osintResult, type OsintResult } from '@/lib/sim';

export const osintLab: LabConfig<OsintResult> = {
  code: 'LAB 07', title: 'OSINT LAB', kind: 'lab:osint', startLabel: 'RUN OSINT SIMULATION', duration: 3200,
  desc: 'Laboratorium OSINT dengan data dummy/internal. Hasil acak & fiktif — jangan memasukkan data pribadi orang nyata.',
  fields: [
    { id: 'mode', label: 'MODULE', type: 'select', def: 'username', options: [{ id: 'username', label: 'USERNAME LOOKUP' }, { id: 'profile', label: 'PROFILE ANALYSIS' }, { id: 'metadata', label: 'METADATA VIEWER' }, { id: 'domain', label: 'DOMAIN INFORMATION (MOCKUP)' }] },
    { id: 'q', label: 'QUERY (DUMMY)', type: 'text', def: 'demo_user', maxLength: 48, hint: 'Username fiktif, label file, atau domain fiktif (*.local/*.test/*.example).',
      validate: (v, all) => {
        const s = v.trim();
        if (all.mode === 'domain') return /^(?:[a-z0-9-]+\.)+(local|test|example|invalid)$/i.test(s) ? null : 'Gunakan domain fiktif: *.local, *.test, *.example.';
        if (all.mode === 'metadata') return /^[A-Za-z0-9 _.-]{3,48}$/.test(s) ? null : 'Label file: 3–48 karakter sederhana.';
        return /^[A-Za-z0-9_.]{3,24}$/.test(s) ? null : 'Username 3–24 karakter (huruf, angka, _ atau .).';
      } },
  ],
  stages: (v) => stages([`[*] module=${v.mode} · dataset=dummy`], ['[*] querying simulated index…'], ['[*] correlating fictional records…'], ['[*] building result cards…'], ['[+] result ready — SIMULATED', '[+] no real data source was contacted']),
  build: (v) => osintResult(v.mode, v.q.trim()),
  summary: (v) => `OSINT ${v.mode} · ${v.q.trim()}`,
  Result: ({ r, v }) => {
    if (r.mode === 'username' && 'hits' in r) return (
      <div className="nx-res"><p className="nx-note">Hasil fiktif untuk <b>{v.q}</b>.</p><ul className="nx-cards">{r.hits.map((h) => <li key={h.platform} className={h.found ? 'is-ok' : 'is-off'}><Chip tone={h.found ? 'ok' : 'off'}>{h.found ? 'FOUND' : 'NOT FOUND'}</Chip><div><b>{h.platform}</b><p>{h.found ? `${h.handle} · ${h.followers} followers (sim)` : 'No matching dummy profile'}</p></div></li>)}</ul></div>
    );
    if (r.mode === 'profile' && 'week' in r) return (
      <div className="nx-res"><ul className="nx-kv"><li><span>Account age (sim)</span><b>{r.ageDays} days</b></li><li><span>Posts (sim)</span><b>{r.posts}</b></li><li><span>Exposure score</span><b>{r.risk}/100</b></li></ul><div className="nx-chips">{r.tags.map((t) => <Chip key={t} tone="cy">#{t}</Chip>)}</div><h5 className="nx-sub-h">ACTIVITY BY DAY</h5><BarChart data={r.week} /></div>
    );
    if ('rows' in r) return <div className="nx-res"><ul className="nx-kv">{r.rows.map(([k, val]) => <li key={k}><span>{k}</span><b>{val}</b></li>)}</ul></div>;
    return null;
  },
};
