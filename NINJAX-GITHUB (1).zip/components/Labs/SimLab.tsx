'use client';
import { useEffect, useMemo, useRef, useState, type ComponentType, type ReactNode } from 'react';
import { Button } from '@/components/UI/Button';
import { Chip, EmptyState, Field, PageHeader, Progress, Seg, SimTag } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { Panel } from '@/components/UI/Panel';
import { ScanViz } from '@/components/Visual/ScanViz';
import { useSimulation, type SimStage } from '@/hooks/useSimulation';
import { useStore } from '@/hooks/useStore';
import { activityLog, logActivity } from '@/services/activity';
import { pushNotification } from '@/services/notifications';
import { fmtAgo } from '@/lib/utils';

export type Values = Record<string, string>;
export type FieldDef = {
  id: string; label: string; type: 'select' | 'text' | 'seg' | 'textarea';
  options?: Array<{ id: string; label: string }>; placeholder?: string; maxLength?: number; hint?: string; def: string;
  validate?: (v: string, all: Values) => string | null; showIf?: (all: Values) => boolean;
};
export type LabConfig<R> = {
  code: string; title: string; desc: string; kind: string; startLabel: string; duration?: number;
  fields: FieldDef[];
  stages: (v: Values) => SimStage[];
  build: (v: Values) => R;
  summary: (v: Values, r: R) => string;
  Result: ComponentType<{ v: Values; r: R }>;
};

function Console({ lines, running }: { lines: string[]; running: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => { ref.current?.scrollTo({ top: ref.current.scrollHeight }); }, [lines.length]);
  return (
    <div className="nx-console" ref={ref} role="log" aria-live="polite" aria-label="Console output" tabIndex={0}>
      {lines.length === 0 ? <span className="nx-dim">&gt; idle — set parameters and start the simulation</span> : lines.map((l, i) => <div key={i} className={l.startsWith('[!]') ? 'is-warn' : l.startsWith('[+]') ? 'is-ok' : undefined}>{l}</div>)}
      {running ? <span className="nx-caret" aria-hidden="true" /> : null}
    </div>
  );
}

export function SimLab<R>({ cfg, extra }: { cfg: LabConfig<R>; extra?: ReactNode }) {
  const defaults = useMemo(() => Object.fromEntries(cfg.fields.map((f) => [f.id, f.def])) as Values, [cfg]);
  const [vals, setVals] = useState<Values>(defaults);
  const [errs, setErrs] = useState<Record<string, string>>({});
  const [res, setRes] = useState<{ v: Values; r: R } | null>(null);
  const sim = useSimulation(cfg.duration ?? 4200);
  const history = useStore(activityLog.store).filter((a) => a.kind === cfg.kind);
  const [q, setQ] = useState('');

  const set = (id: string, v: string) => { setVals((x) => ({ ...x, [id]: v })); setErrs((e) => { if (!e[id]) return e; const n = { ...e }; delete n[id]; return n; }); };

  const start = () => {
    const e: Record<string, string> = {};
    for (const f of cfg.fields) {
      if (f.showIf && !f.showIf(vals)) continue;
      const v = vals[f.id] ?? '';
      const m = f.validate?.(v, vals);
      if (m) e[f.id] = m;
    }
    setErrs(e);
    if (Object.keys(e).length) return;
    setRes(null);
    const snap = { ...vals };
    sim.start(cfg.stages(snap), () => {
      const r = cfg.build(snap);
      setRes({ v: snap, r });
      logActivity(cfg.kind, cfg.summary(snap, r), { values: snap });
      pushNotification('system', `${cfg.title} complete`, cfg.summary(snap, r).slice(0, 100));
    });
  };
  const reset = () => { sim.reset(); setRes(null); };

  const shown = history.filter((h) => !q.trim() || h.detail.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 20);

  return (
    <div className="nx-page">
      <PageHeader code={cfg.code} title={cfg.title} desc={cfg.desc} aside={<SimTag />} />
      <div className="nx-lab">
        <Panel title="PARAMETERS">
          <form onSubmit={(e) => { e.preventDefault(); if (!sim.running) start(); }} className="nx-form" noValidate>
            {cfg.fields.filter((f) => !f.showIf || f.showIf(vals)).map((f) => (
              <Field key={f.id} label={f.label} hint={f.hint} error={errs[f.id]}>
                {f.type === 'select' ? (
                  <select className="nx-input" value={vals[f.id]} onChange={(e) => set(f.id, e.target.value)} disabled={sim.running}>{f.options?.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}</select>
                ) : f.type === 'seg' ? (
                  <Seg label={f.label} value={vals[f.id]} onChange={(v) => set(f.id, v)} options={f.options ?? []} />
                ) : f.type === 'textarea' ? (
                  <textarea className="nx-input nx-textarea" rows={3} value={vals[f.id]} maxLength={f.maxLength} placeholder={f.placeholder} onChange={(e) => set(f.id, e.target.value)} disabled={sim.running} />
                ) : (
                  <input className="nx-input" value={vals[f.id]} maxLength={f.maxLength} placeholder={f.placeholder} onChange={(e) => set(f.id, e.target.value)} disabled={sim.running} autoComplete="off" autoCapitalize="none" spellCheck={false} />
                )}
              </Field>
            ))}
            <div className="nx-row">
              <Button type="submit" disabled={sim.running}><Icon name="check" size={16} /> {cfg.startLabel}</Button>
              <Button variant="ghost" onClick={sim.stop} disabled={!sim.running}>STOP</Button>
              <Button variant="ghost" onClick={reset} disabled={sim.running && false}>RESET</Button>
            </div>
          </form>
        </Panel>

        <Panel title="SIMULATION" aside={<Chip tone={sim.running ? 'warn' : sim.done ? 'ok' : sim.status === 'STOPPED' ? 'bad' : 'off'} dot>{sim.status}</Chip>}>
          <div className="nx-simrow"><ScanViz active={sim.running} pct={sim.pct} label={sim.done ? 'DONE' : 'READY'} />
            <div className="nx-simrow__info"><small>PROGRESS</small><b>{sim.pct}%</b><Progress value={sim.pct} label={`${cfg.title} progress`} tone={sim.done ? 'ok' : 'default'} /></div></div>
          <Console lines={sim.lines} running={sim.running} />
        </Panel>
      </div>

      {res ? (
        <Panel title="RESULT" tone="ok" aside={<Chip tone="ok">COMPLETED</Chip>} className="nx-result">
          <cfg.Result v={res.v} r={res.r} />
          <SimTag />
        </Panel>
      ) : null}
      {extra}

      <Panel title="HISTORY" aside={<small className="nx-dim">{history.length} runs</small>}>
        {history.length > 4 ? <label className="nx-search"><Icon name="search" size={16} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search history…" aria-label="Search history" maxLength={40} /></label> : null}
        {shown.length === 0 ? <EmptyState icon="history" title="NO HISTORY YET" text="Jalankan simulasi pertama Anda." /> : (
          <ul className="nx-feed">{shown.map((h) => <li key={h.id}><time>{fmtAgo(h.created_at)}</time><span>{h.detail}</span></li>)}</ul>
        )}
      </Panel>
    </div>
  );
}
