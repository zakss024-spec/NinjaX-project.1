'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '@/components/UI/Button';
import { Chip, PageHeader, Seg, SimTag } from '@/components/UI/Bits';
import { Panel } from '@/components/UI/Panel';
import { Sparkline } from '@/components/UI/Charts';
import { settingsStore } from '@/lib/settings';
import { rng } from '@/lib/utils';
import { logActivity } from '@/services/activity';
import { useUI } from '@/components/Providers/UIProvider';

type Topo = 'star' | 'mesh' | 'ring';
type Node = { id: number; name: string; x: number; y: number; ip: string; down: boolean };
type Edge = [number, number];

function build(topo: Topo, n: number): { nodes: Node[]; edges: Edge[] } {
  const r = rng(`${topo}${n}`);
  const nodes: Node[] = Array.from({ length: n }, (_, i) => {
    const a = (i / n) * Math.PI * 2 - Math.PI / 2;
    const hub = topo === 'star' && i === 0;
    return { id: i, name: hub ? 'CORE-GW' : `NODE-${String(i).padStart(2, '0')}`, x: hub ? 0.5 : 0.5 + Math.cos(a) * 0.38, y: hub ? 0.5 : 0.5 + Math.sin(a) * 0.38, ip: `192.0.2.${10 + i}`, down: false };
  });
  const edges: Edge[] = [];
  if (topo === 'star') for (let i = 1; i < n; i++) edges.push([0, i]);
  else if (topo === 'ring') for (let i = 0; i < n; i++) edges.push([i, (i + 1) % n]);
  else for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (r() < 0.45 || j === i + 1) edges.push([i, j]);
  return { nodes, edges };
}

export function NetworkLab() {
  const [topo, setTopo] = useState<Topo>('mesh');
  const [count, setCount] = useState('7');
  const [paused, setPaused] = useState(false);
  const [down, setDown] = useState<Set<number>>(new Set());
  const [lat, setLat] = useState<number[]>([]);
  const [traffic, setTraffic] = useState<number[]>(Array(40).fill(20));
  const [pkts, setPkts] = useState(0);
  const cv = useRef<HTMLCanvasElement>(null);
  const { toast } = useUI();
  const graph = useMemo(() => build(topo, Number(count)), [topo, count]);
  const downRef = useRef(down); useEffect(() => { downRef.current = down; }, [down]);
  const pausedRef = useRef(paused); useEffect(() => { pausedRef.current = paused; }, [paused]);
  const pktTotal = useRef(0);

  // statistik simulasi (latency + traffic) — satu interval, dibersihkan saat unmount
  useEffect(() => {
    const t = setInterval(() => {
      if (document.hidden || pausedRef.current) return;
      setLat(graph.nodes.map((n) => (downRef.current.has(n.id) ? -1 : 6 + Math.round(Math.random() * 40))));
      setTraffic((v) => [...v.slice(1), 15 + Math.round(Math.random() * 70)]);
      setPkts(pktTotal.current);
    }, 1200);
    setLat(graph.nodes.map(() => 6 + Math.round(Math.random() * 40)));
    return () => clearInterval(t);
  }, [graph]);

  // animasi paket di canvas
  useEffect(() => {
    const c = cv.current; if (!c) return;
    const ctx = c.getContext('2d'); if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    let w = 0, h = 0, raf = 0, last = 0;
    type P = { e: number; t: number; v: number; rev: boolean };
    let ps: P[] = [];
    const resize = () => { w = c.clientWidth; h = c.clientHeight; c.width = Math.floor(w * dpr); c.height = Math.floor(h * dpr); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); };
    resize();
    const frame = (t: number) => {
      raf = requestAnimationFrame(frame);
      if (t - last < 33) return; last = t;
      const anim = settingsStore.get().animations;
      ctx.clearRect(0, 0, w, h);
      const live = graph.edges.map((e, i) => ({ e, i })).filter(({ e }) => !downRef.current.has(e[0]) && !downRef.current.has(e[1]));
      ctx.lineWidth = 1;
      for (const [a, b] of graph.edges) {
        const A = graph.nodes[a], B = graph.nodes[b], off = downRef.current.has(a) || downRef.current.has(b);
        ctx.strokeStyle = off ? 'rgba(255,77,141,.25)' : 'rgba(168,85,247,.45)'; ctx.setLineDash(off ? [4, 4] : []);
        ctx.beginPath(); ctx.moveTo(A.x * w, A.y * h); ctx.lineTo(B.x * w, B.y * h); ctx.stroke();
      }
      ctx.setLineDash([]);
      if (!pausedRef.current && anim && live.length && ps.length < 26 && Math.random() < 0.35) { ps.push({ e: live[Math.floor(Math.random() * live.length)].i, t: 0, v: 0.012 + Math.random() * 0.02, rev: Math.random() < 0.5 }); pktTotal.current++; }
      ps = ps.filter((p) => p.t < 1);
      for (const p of ps) {
        if (!pausedRef.current) p.t += p.v;
        const [a, b] = graph.edges[p.e]; const A = graph.nodes[p.rev ? b : a], B = graph.nodes[p.rev ? a : b];
        const x = (A.x + (B.x - A.x) * p.t) * w, y = (A.y + (B.y - A.y) * p.t) * h;
        ctx.fillStyle = '#22d3ee'; ctx.shadowColor = '#22d3ee'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.arc(x, y, 2.6, 0, 6.283); ctx.fill(); ctx.shadowBlur = 0;
      }
      for (const n of graph.nodes) {
        const off = downRef.current.has(n.id);
        ctx.fillStyle = '#0b0618'; ctx.strokeStyle = off ? '#ff4d8d' : n.name === 'CORE-GW' ? '#4ade80' : '#a855f7'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(n.x * w, n.y * h, 11, 0, 6.283); ctx.fill(); ctx.stroke();
        ctx.fillStyle = off ? '#ff4d8d' : '#ece9ff'; ctx.font = '9px ui-monospace, monospace'; ctx.textAlign = 'center'; ctx.fillText(String(n.id), n.x * w, n.y * h + 3);
      }
    };
    raf = requestAnimationFrame(frame);
    const vis = () => { cancelAnimationFrame(raf); if (!document.hidden) raf = requestAnimationFrame(frame); };
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('resize', resize);
    return () => { cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); window.removeEventListener('resize', resize); };
  }, [graph]);

  const toggle = useCallback((id: number) => setDown((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; }), []);
  const online = graph.nodes.length - down.size;
  const avg = lat.filter((x) => x >= 0);
  const mean = avg.length ? Math.round(avg.reduce((a, b) => a + b, 0) / avg.length) : 0;
  const snapshot = () => { logActivity('lab:network', `Network snapshot ${topo} · ${online}/${graph.nodes.length} nodes · avg ${mean}ms`); toast('Snapshot disimpan ke history', 'success'); };

  return (
    <div className="nx-page">
      <PageHeader code="LAB 08" title="NETWORK LAB" desc="Visualisasi node, paket, latency, dan traffic — semuanya simulasi lokal. Tidak ada koneksi ke jaringan nyata." aside={<SimTag />} />
      <Panel title="NETWORK MAP" aside={<Chip tone={down.size ? 'warn' : 'ok'} dot>{online}/{graph.nodes.length} ONLINE</Chip>}>
        <canvas ref={cv} className="nx-netcv" aria-label="Simulated network map" role="img" />
        <div className="nx-netctl">
          <Seg<Topo> label="Topology" value={topo} onChange={(t) => { setTopo(t); setDown(new Set()); }} options={[{ id: 'star', label: 'STAR' }, { id: 'mesh', label: 'MESH' }, { id: 'ring', label: 'RING' }]} />
          <Seg label="Nodes" value={count} onChange={(c) => { setCount(c); setDown(new Set()); }} options={[{ id: '5', label: '5' }, { id: '7', label: '7' }, { id: '9', label: '9' }]} />
        </div>
        <div className="nx-row"><Button size="sm" variant="ghost" onClick={() => setPaused((p) => !p)}>{paused ? 'RESUME' : 'PAUSE'}</Button><Button size="sm" variant="ghost" onClick={() => setDown(new Set())} disabled={!down.size}>RESTORE ALL</Button><Button size="sm" onClick={snapshot}>SAVE SNAPSHOT</Button></div>
      </Panel>
      <div className="nx-grid2">
        <Panel title="LATENCY" aside={<small className="nx-dim">avg {mean} ms</small>}>
          <ul className="nx-nodes">
            {graph.nodes.map((n, i) => {
              const v = lat[i] ?? 0, off = down.has(n.id);
              return (
                <li key={n.id}><span><b>{n.name}</b><code>{n.ip}</code></span><Chip tone={off ? 'bad' : v > 35 ? 'warn' : 'ok'} dot>{off ? 'OFFLINE' : `${v} ms`}</Chip>
                  <button type="button" className="nx-linkbtn" onClick={() => toggle(n.id)} aria-pressed={off}>{off ? 'BRING UP' : 'FAULT (SIM)'}</button></li>
              );
            })}
          </ul>
        </Panel>
        <Panel title="TRAFFIC" aside={<small className="nx-dim">{pkts} packets (sim)</small>}>
          <Sparkline values={traffic} height={90} />
          <ul className="nx-kv"><li><span>Throughput (sim)</span><b>{traffic[traffic.length - 1]} Mb/s</b></li><li><span>Status</span><b className={down.size ? 'is-warn' : 'is-ok'}>{down.size ? 'DEGRADED' : 'HEALTHY'}</b></li></ul>
        </Panel>
      </div>
    </div>
  );
}
