'use client';
import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { PageHeader, SimTag } from '@/components/UI/Bits';
import { Panel } from '@/components/UI/Panel';
import { LAB_ITEMS } from '@/lib/nav';
import { traceId } from '@/lib/sim';
import { fmtDur } from '@/lib/utils';
import { logActivity } from '@/services/activity';

type Line = { id: number; text: string; cls?: 'cmd' | 'err' | 'ok' | 'dim' };
const CMDS = ['help', 'status', 'clear', 'scan', 'modules', 'system', 'history', 'about'];
const started = typeof performance !== 'undefined' ? Date.now() : 0;

/** Terminal internal: hanya perintah lokal (whitelist). Tidak ada eksekusi shell/OS. */
export function TerminalView() {
  const { cloud, profile } = useAuth();
  const { status, online } = useChat();
  const [lines, setLines] = useState<Line[]>([]);
  const [val, setVal] = useState('');
  const [busy, setBusy] = useState(false);
  const hist = useRef<string[]>([]);
  const hi = useRef(0);
  const out = useRef<HTMLDivElement>(null);
  const idc = useRef(0);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const input = useRef<HTMLInputElement>(null);

  const push = useCallback((text: string, cls?: Line['cls']) => setLines((l) => [...l.slice(-300), { id: ++idc.current, text, cls }]), []);
  /** Cetak beberapa baris berurutan dengan efek ketik per-baris. */
  const emit = useCallback((arr: Array<[string, Line['cls']?]>, gap = 120) => new Promise<void>((res) => {
    arr.forEach(([t, c], i) => { timers.current.push(setTimeout(() => { push(t, c); if (i === arr.length - 1) res(); }, i * gap)); });
    if (!arr.length) res();
  }), [push]);

  useEffect(() => {
    void emit([['NINJAX TERMINAL v1.0 — local simulation shell', 'ok'], ['No OS commands are executed. Type "help" to list commands.', 'dim']], 160);
    const t = timers.current;
    return () => { t.forEach(clearTimeout); t.length = 0; };
  }, [emit]);
  useEffect(() => { out.current?.scrollTo({ top: out.current.scrollHeight }); }, [lines]);

  const run = async (raw: string) => {
    const cmd = raw.trim();
    push(`ninja@local:~$ ${cmd}`, 'cmd');
    if (!cmd) return;
    hist.current.push(cmd); hi.current = hist.current.length;
    const [name, ...args] = cmd.split(/\s+/);
    logActivity('terminal', `Terminal: ${name.toLowerCase().slice(0, 20)}`);
    setBusy(true);
    switch (name.toLowerCase()) {
      case 'help': await emit([['Available commands:', 'ok'], ...[['help', 'show this list'], ['status', 'cloud & realtime status'], ['scan', 'run a simulated local scan'], ['modules', 'list laboratory modules'], ['system', 'device/session info'], ['history', 'command history'], ['about', 'about NinjaX'], ['clear', 'clear the screen']].map(([c, d]) => [`  ${c.padEnd(9)} ${d}`] as [string])], 60); break;
      case 'clear': setLines([]); break;
      case 'status': await emit([[`cloud      : ${cloud.toUpperCase()}`], [`realtime   : ${status.toUpperCase()}`], [`online     : ${online.length} user(s)`], [`user       : @${profile?.username ?? 'n/a'}`], ['mode       : LOCAL SIMULATION', 'ok']], 80); break;
      case 'modules': await emit([['Modules:', 'ok'], ...LAB_ITEMS.map((l) => [`  ${l.label.padEnd(12)} ${l.href}`] as [string])], 60); break;
      case 'system': await emit([[`platform   : ${navigator.platform || 'n/a'}`], [`viewport   : ${window.innerWidth}x${window.innerHeight} @${window.devicePixelRatio || 1}x`], [`language   : ${navigator.language}`], [`online     : ${navigator.onLine ? 'yes' : 'no'}`], [`session    : ${fmtDur(Date.now() - started)}`]], 80); break;
      case 'history': await emit(hist.current.length ? hist.current.slice(-15).map((h, i) => [`  ${String(i + 1).padStart(2)}  ${h}`] as [string]) : [['(empty)', 'dim']], 50); break;
      case 'about': await emit([['NinjaX — cyber operations center', 'ok'], ['Realtime chat + sender manager + simulation labs.'], ['Developers: Zakss · DAKA · NATHAN'], ['All cyber modules are local simulations.', 'dim']], 90); break;
      case 'scan': {
        const id = traceId(String(Date.now()));
        await emit([[`[*] scan ${id} started (local, dummy targets)`], ['[*] enumerating virtual nodes…'], ['[*] node-01 192.0.2.11 ... ok', 'ok'], ['[*] node-02 192.0.2.12 ... ok', 'ok'], ['[!] node-03 192.0.2.13 ... latency high (simulated)'], ['[+] scan complete — 3 nodes, 1 warning (SIMULATED)', 'ok']], 380);
        break;
      }
      case 'echo': push(args.join(' ').slice(0, 200)); break;
      default:
        if (['rm', 'sudo', 'curl', 'wget', 'ssh', 'nc', 'bash', 'sh', 'python', 'node', 'cat', 'ls'].includes(name.toLowerCase())) push(`${name}: blocked — this terminal does not run OS commands`, 'err');
        else push(`${name}: command not found. Type "help".`, 'err');
    }
    setBusy(false);
  };

  const submit = () => { const v = val; setVal(''); void run(v); input.current?.focus(); };
  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') { e.preventDefault(); hi.current = Math.max(0, hi.current - 1); setVal(hist.current[hi.current] ?? ''); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); hi.current = Math.min(hist.current.length, hi.current + 1); setVal(hist.current[hi.current] ?? ''); }
    else if (e.key === 'Tab') { e.preventDefault(); const m = CMDS.filter((c) => c.startsWith(val.toLowerCase())); if (m.length === 1) setVal(m[0]); }
  };

  return (
    <div className="nx-page">
      <PageHeader code="CONSOLE" title="TERMINAL" desc="Terminal internal dengan perintah lokal. Tidak ada akses shell atau server." aside={<SimTag />} />
      <Panel flush className="nx-term">
        <div className="nx-term__bar"><i /><i /><i /><span>ninja@local:~</span></div>
        <div className="nx-term__out" ref={out} role="log" aria-live="polite" tabIndex={0} onClick={() => input.current?.focus()}>
          {lines.map((l) => <div key={l.id} className={l.cls ? `is-${l.cls}` : undefined}>{l.text}</div>)}
          {busy ? <span className="nx-caret" aria-hidden="true" /> : null}
        </div>
        <form className="nx-term__form" onSubmit={(e) => { e.preventDefault(); submit(); }} autoComplete="off">
          <label htmlFor="nx-term-in">ninja@local:~$</label>
          <input id="nx-term-in" ref={input} value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={onKey} maxLength={80} autoCapitalize="none" autoCorrect="off" spellCheck={false} enterKeyHint="send" aria-label="Terminal command" />
          <button type="submit" className="nx-btn nx-btn--primary nx-btn--sm"><span className="nx-btn__label">RUN</span></button>
        </form>
        <div className="nx-term__chips">{CMDS.map((c) => <button key={c} type="button" className="nx-cmdchip" onClick={() => void run(c)} disabled={busy}>{c}</button>)}</div>
      </Panel>
    </div>
  );
}
