'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Modal } from '@/components/UI/Modal';
import { Button } from '@/components/UI/Button';
import { uid } from '@/lib/utils';

type ToastKind = 'info' | 'success' | 'error' | 'warn';
type Toast = { id: string; kind: ToastKind; text: string };
type ConfirmOpts = { title: string; text: string; confirm?: string; cancel?: string; danger?: boolean };

type Ctx = {
  toast: (text: string, kind?: ToastKind) => void;
  confirm: (o: ConfirmOpts) => Promise<boolean>;
};
const UICtx = createContext<Ctx | null>(null);

export function useUI(): Ctx {
  const c = useContext(UICtx);
  if (!c) throw new Error('useUI harus di dalam UIProvider');
  return c;
}

export function UIProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());
  const [conf, setConf] = useState<(ConfirmOpts & { resolve: (v: boolean) => void }) | null>(null);

  const toast = useCallback((text: string, kind: ToastKind = 'info') => {
    const id = uid();
    setToasts((t) => [...t.slice(-3), { id, kind, text }]);
    timers.current.set(id, setTimeout(() => {
      setToasts((t) => t.filter((x) => x.id !== id));
      timers.current.delete(id);
    }, kind === 'error' ? 5200 : 3200));
  }, []);

  useEffect(() => { const m = timers.current; return () => { m.forEach((t) => clearTimeout(t)); m.clear(); }; }, []);

  const confirm = useCallback((o: ConfirmOpts) => new Promise<boolean>((resolve) => setConf({ ...o, resolve })), []);
  const close = (v: boolean) => { conf?.resolve(v); setConf(null); };

  const value = useMemo(() => ({ toast, confirm }), [toast, confirm]);
  return (
    <UICtx.Provider value={value}>
      {children}
      <div className="nx-toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`nx-toast nx-toast--${t.kind}`}>
            <i aria-hidden="true" />
            <span>{t.text}</span>
          </div>
        ))}
      </div>
      <Modal open={!!conf} title={conf?.title ?? ''} onClose={() => close(false)} size="sm">
        <p className="nx-modal__text">{conf?.text}</p>
        <div className="nx-modal__actions">
          <Button variant="ghost" onClick={() => close(false)}>{conf?.cancel ?? 'CANCEL'}</Button>
          <Button variant={conf?.danger ? 'danger' : 'primary'} onClick={() => close(true)} autoFocus>{conf?.confirm ?? 'CONFIRM'}</Button>
        </div>
      </Modal>
    </UICtx.Provider>
  );
}
