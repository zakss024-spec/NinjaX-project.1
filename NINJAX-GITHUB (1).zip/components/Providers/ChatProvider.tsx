'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { managedChannel, type Managed } from '@/lib/realtime';
import { createRateLimiter, validateMessage } from '@/lib/moderation';
import type { ChatMessage, RtStatus } from '@/lib/types';
import { editMessage, fetchRecent, fetchSince, friendlyError, insertMessage, removeMessage } from '@/services/messages';
import { logActivity } from '@/services/activity';
import { pushNotification } from '@/services/notifications';
import { uid } from '@/lib/utils';
import { useAuth } from './AuthProvider';

export type PresenceUser = { user_id: string; username: string; display_name: string; avatar_url: string | null; at: number };

type Ctx = {
  messages: ChatMessage[];
  status: RtStatus;
  presenceStatus: RtStatus;
  loading: boolean;
  error: string | null;
  online: PresenceUser[];
  sessions: number;
  unread: number;
  errors: Record<string, string>;
  send: (text: string) => Promise<{ ok: boolean; error?: string }>;
  retry: (id: string) => Promise<void>;
  discard: (id: string) => void;
  edit: (id: string, text: string) => Promise<{ ok: boolean; error?: string }>;
  remove: (id: string) => Promise<void>;
  reload: () => void;
  reconnect: () => void;
  setActive: (active: boolean) => void;
};

const ChatCtx = createContext<Ctx | null>(null);
export function useChat(): Ctx {
  const c = useContext(ChatCtx);
  if (!c) throw new Error('useChat harus di dalam ChatProvider');
  return c;
}

const MAX_MEM = 300;

function merge(list: ChatMessage[], incoming: ChatMessage[]): ChatMessage[] {
  const map = new Map<string, ChatMessage>();
  for (const m of list) map.set(m.id, m);
  for (const m of incoming) map.set(m.id, { ...m, _state: undefined });
  return Array.from(map.values())
    .sort((a, b) => (a.created_at === b.created_at ? (a.id < b.id ? -1 : 1) : a.created_at < b.created_at ? -1 : 1))
    .slice(-MAX_MEM);
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const { cloud, userId, profile } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [status, setStatus] = useState<RtStatus>('connecting');
  const [presenceStatus, setPresenceStatus] = useState<RtStatus>('connecting');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [online, setOnline] = useState<PresenceUser[]>([]);
  const [sessions, setSessions] = useState(0);
  const [unread, setUnread] = useState(0);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const active = useRef(false);
  const limiter = useRef(createRateLimiter(5, 10000, 700));
  const msgRef = useRef<ChatMessage[]>([]);
  const msgChan = useRef<Managed | null>(null);
  const presChan = useRef<Managed | null>(null);
  const userRef = useRef<{ id: string | null; username: string; display: string; avatar: string | null }>({ id: null, username: '', display: '', avatar: null });
  const [tick, setTick] = useState(0);

  useEffect(() => { msgRef.current = messages; }, [messages]);
  useEffect(() => {
    userRef.current = { id: userId, username: profile?.username ?? '', display: profile?.display_name ?? '', avatar: profile?.avatar_url ?? null };
  }, [userId, profile]);

  const serverCursor = () => {
    const srv = msgRef.current.filter((m) => !m._state);
    return srv.length ? srv[srv.length - 1].created_at : null;
  };

  const handleIncoming = useCallback((m: ChatMessage, fresh: boolean) => {
    setMessages((prev) => merge(prev, [m]));
    const mine = m.user_id === userRef.current.id;
    if (fresh && !mine) {
      if (!active.current || document.hidden) {
        setUnread((u) => u + 1);
        pushNotification('chat', `New message from ${m.username}`, m.content.slice(0, 80));
      }
    }
  }, []);

  /* ---------- muat awal ---------- */
  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try { setMessages(merge([], await fetchRecent(100))); }
    catch (e) { setError(friendlyError(e)); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    if (cloud !== 'ready' || !userId) return;
    void load();
  }, [cloud, userId, load, tick]);

  /* ---------- channel pesan (INSERT/UPDATE/DELETE) ---------- */
  useEffect(() => {
    if (cloud !== 'ready' || !userId) return;
    const m = managedChannel({
      name: 'ninjax-messages',
      onStatus: setStatus,
      build: (ch) => {
        ch.on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (p) => handleIncoming(p.new as ChatMessage, true));
        ch.on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, (p) => handleIncoming(p.new as ChatMessage, false));
        ch.on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'messages' }, (p) => {
          const id = (p.old as { id?: string }).id;
          if (id) setMessages((prev) => prev.filter((x) => x.id !== id));
        });
      },
      // setelah (re)connect: ambil pesan yang terlewat selama terputus
      onConnected: () => {
        const since = serverCursor();
        if (!since) return;
        fetchSince(since).then((rows) => {
          if (!rows.length) return;
          setMessages((prev) => merge(prev, rows));
          const others = rows.filter((r) => r.user_id !== userRef.current.id);
          if (others.length && (!active.current || document.hidden)) setUnread((u) => u + others.length);
        }).catch(() => undefined);
      },
    });
    msgChan.current = m;
    return () => { m.destroy(); msgChan.current = null; };
  }, [cloud, userId, handleIncoming]);

  /* ---------- presence (online users) ---------- */
  useEffect(() => {
    if (cloud !== 'ready' || !userId) return;
    const p = managedChannel({
      name: 'ninjax-presence',
      config: { presence: { key: userId } },
      onStatus: setPresenceStatus,
      build: (ch) => {
        ch.on('presence', { event: 'sync' }, () => {
          const st = ch.presenceState<PresenceUser>();
          const list: PresenceUser[] = []; let n = 0;
          for (const key of Object.keys(st)) {
            const metas = st[key];
            n += metas.length;
            if (metas[0]) list.push(metas[0] as unknown as PresenceUser);
          }
          list.sort((a, b) => a.display_name.localeCompare(b.display_name));
          setOnline(list); setSessions(n);
        });
      },
      onConnected: (ch) => {
        const u = userRef.current;
        void ch.track({ user_id: u.id, username: u.username, display_name: u.display, avatar_url: u.avatar, at: Date.now() });
      },
    });
    presChan.current = p;
    return () => { p.destroy(); presChan.current = null; setOnline([]); setSessions(0); };
  }, [cloud, userId]);

  // perbarui data presence bila profil berubah
  useEffect(() => {
    if (!userId || !profile) return;
    presChan.current?.reconnect();
  }, [userId, profile?.display_name, profile?.avatar_url]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------- aksi ---------- */
  const send = useCallback(async (text: string) => {
    const u = userRef.current;
    if (!u.id) return { ok: false, error: 'Belum terhubung.' };
    const v = validateMessage(text);
    if (!v.ok) return { ok: false, error: v.error };
    const rl = limiter.current.check();
    if (!rl.ok) return { ok: false, error: `Terlalu cepat — tunggu ${Math.ceil(rl.waitMs / 1000)}s.` };
    const id = uid();
    const now = new Date().toISOString();
    const optimistic: ChatMessage = { id, user_id: u.id, username: u.username, content: v.value, created_at: now, updated_at: now, _state: 'sending' };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const row = await insertMessage({ id, user_id: u.id, username: u.username, content: v.value });
      setMessages((prev) => merge(prev, [row]));
      logActivity('chat', `Sent message (${v.value.length} chars)`);
      return { ok: true };
    } catch (e) {
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, _state: 'failed' } : m)));
      setErrors((x) => ({ ...x, [id]: friendlyError(e) }));
      return { ok: false, error: friendlyError(e) };
    }
  }, []);

  const retry = useCallback(async (id: string) => {
    const m = msgRef.current.find((x) => x.id === id);
    const u = userRef.current;
    if (!m || !u.id) return;
    setMessages((prev) => prev.map((x) => (x.id === id ? { ...x, _state: 'sending' } : x)));
    try {
      const row = await insertMessage({ id, user_id: u.id, username: u.username, content: m.content });
      setMessages((prev) => merge(prev, [row]));
      setErrors((x) => { const n = { ...x }; delete n[id]; return n; });
    } catch (e) {
      setMessages((prev) => prev.map((x) => (x.id === id ? { ...x, _state: 'failed' } : x)));
      setErrors((x) => ({ ...x, [id]: friendlyError(e) }));
    }
  }, []);

  const discard = useCallback((id: string) => { setMessages((prev) => prev.filter((m) => m.id !== id)); }, []);

  const edit = useCallback(async (id: string, text: string) => {
    const v = validateMessage(text);
    if (!v.ok) return { ok: false, error: v.error };
    try { const row = await editMessage(id, v.value); setMessages((prev) => merge(prev, [row])); return { ok: true }; }
    catch (e) { return { ok: false, error: friendlyError(e) }; }
  }, []);

  const remove = useCallback(async (id: string) => {
    const keep = msgRef.current;
    setMessages((prev) => prev.filter((m) => m.id !== id));
    try { await removeMessage(id); } catch { setMessages(keep); }
  }, []);

  const setActive = useCallback((a: boolean) => { active.current = a; if (a) setUnread(0); }, []);
  const reload = useCallback(() => setTick((t) => t + 1), []);
  const reconnect = useCallback(() => { msgChan.current?.reconnect(); presChan.current?.reconnect(); }, []);

  // saat tab kembali terlihat dan chat aktif -> nol-kan unread
  useEffect(() => {
    const f = () => { if (!document.hidden && active.current) setUnread(0); };
    document.addEventListener('visibilitychange', f);
    return () => document.removeEventListener('visibilitychange', f);
  }, []);

  const value = useMemo<Ctx>(() => ({
    messages, status, presenceStatus, loading, error, online, sessions, unread, errors,
    send, retry, discard, edit, remove, reload, reconnect, setActive,
  }), [messages, status, presenceStatus, loading, error, online, sessions, unread, errors, send, retry, discard, edit, remove, reload, reconnect, setActive]);

  return <ChatCtx.Provider value={value}>{children}</ChatCtx.Provider>;
}
