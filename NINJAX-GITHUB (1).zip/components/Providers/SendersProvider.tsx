'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { managedChannel } from '@/lib/realtime';
import type { RtStatus, Sender } from '@/lib/types';
import { addGlobal, fetchGlobal, removeGlobal, updateGlobal, type SenderInput } from '@/services/senders';
import { friendlyError } from '@/services/messages';
import { pushNotification } from '@/services/notifications';
import { useAuth } from './AuthProvider';

type Ctx = {
  list: Sender[];
  status: RtStatus;
  loading: boolean;
  error: string | null;
  reload: () => void;
  add: (i: SenderInput) => Promise<Sender>;
  update: (id: string, p: Partial<SenderInput>) => Promise<Sender>;
  remove: (id: string) => Promise<void>;
};
const Ctx_ = createContext<Ctx | null>(null);
export function useGlobalSenders(): Ctx {
  const c = useContext(Ctx_);
  if (!c) throw new Error('useGlobalSenders harus di dalam SendersProvider');
  return c;
}

const sortDesc = (l: Sender[]) => [...l].sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
const upsert = (l: Sender[], s: Sender) => sortDesc([s, ...l.filter((x) => x.id !== s.id)]);

export function SendersProvider({ children }: { children: ReactNode }) {
  const { cloud, userId } = useAuth();
  const [list, setList] = useState<Sender[]>([]);
  const [status, setStatus] = useState<RtStatus>('connecting');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try { setList(sortDesc(await fetchGlobal())); } catch (e) { setError(friendlyError(e)); } finally { setLoading(false); }
  }, []);

  useEffect(() => { if (cloud === 'ready') void load(); }, [cloud, load, tick]);

  useEffect(() => {
    if (cloud !== 'ready' || !userId) return;
    const m = managedChannel({
      name: 'ninjax-senders',
      onStatus: setStatus,
      build: (ch) => {
        ch.on('postgres_changes', { event: '*', schema: 'public', table: 'senders_global' }, (p) => {
          if (p.eventType === 'DELETE') {
            const id = (p.old as { id?: string }).id;
            if (id) setList((l) => l.filter((x) => x.id !== id));
          } else {
            const s = p.new as Sender;
            setList((l) => upsert(l, s));
            if (p.eventType === 'INSERT' && s.owner_id !== userId) pushNotification('sender', 'New global sender', `${s.name} (${s.sender_code})`);
          }
        });
      },
      onConnected: () => { void fetchGlobal().then((r) => setList(sortDesc(r))).catch(() => undefined); },
    });
    return () => m.destroy();
  }, [cloud, userId]);

  const add = useCallback(async (i: SenderInput) => {
    if (!userId) throw new Error('Belum terhubung');
    const s = await addGlobal(userId, i);
    setList((l) => upsert(l, s));
    return s;
  }, [userId]);
  const update = useCallback(async (id: string, p: Partial<SenderInput>) => {
    const s = await updateGlobal(id, p);
    setList((l) => upsert(l, s));
    return s;
  }, []);
  const remove = useCallback(async (id: string) => {
    await removeGlobal(id);
    setList((l) => l.filter((x) => x.id !== id));
  }, []);
  const reload = useCallback(() => setTick((t) => t + 1), []);

  const value = useMemo(() => ({ list, status, loading, error, reload, add, update, remove }), [list, status, loading, error, reload, add, update, remove]);
  return <Ctx_.Provider value={value}>{children}</Ctx_.Provider>;
}
