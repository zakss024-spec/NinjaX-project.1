'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { getGate, setGate, type Gate } from '@/lib/auth';
import { getSupabase, isSupabaseConfigured } from '@/lib/supabase';
import type { CloudState, Profile } from '@/lib/types';
import { ensureProfile, setOnline } from '@/services/profiles';
import { activityLog, logActivity } from '@/services/activity';
import { notifLog } from '@/services/notifications';
import { errMsg } from '@/lib/utils';

type Ctx = {
  hydrated: boolean;
  gate: Gate;
  cloud: CloudState;
  cloudError: string | null;
  userId: string | null;
  profile: Profile | null;
  isAnonymous: boolean;
  advance: (g: Gate) => void;
  connect: () => Promise<void>;
  logout: () => Promise<void>;
  resetIdentity: () => Promise<void>;
  setProfile: (p: Profile) => void;
};
const AuthCtx = createContext<Ctx | null>(null);

export function useAuth(): Ctx {
  const c = useContext(AuthCtx);
  if (!c) throw new Error('useAuth harus di dalam AuthProvider');
  return c;
}

function explain(e: unknown): string {
  const m = errMsg(e);
  if (/anonymous/i.test(m) && /disabled|not enabled|allowed/i.test(m)) return 'Anonymous sign-ins belum aktif di Supabase (Authentication → Providers → Anonymous).';
  if (/fetch|network|Failed to fetch/i.test(m)) return 'Tidak dapat menjangkau Supabase (jaringan).';
  if (/relation .* does not exist|schema cache/i.test(m)) return 'Tabel belum dibuat — jalankan supabase/schema.sql.';
  return m;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [gate, setGateState] = useState<Gate>('none');
  const [cloud, setCloud] = useState<CloudState>('idle');
  const [cloudError, setCloudError] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [profile, setProfileState] = useState<Profile | null>(null);
  const [isAnonymous, setAnon] = useState(true);
  const busy = useRef(false);

  useEffect(() => {
    activityLog.load(); notifLog.load();
    setGateState(getGate());
    setHydrated(true);
  }, []);

  const connect = useCallback(async () => {
    if (busy.current) return;
    if (!isSupabaseConfigured) { setCloud('unconfigured'); setCloudError('Environment Supabase belum diisi.'); return; }
    const sb = getSupabase();
    if (!sb) return;
    busy.current = true;
    setCloud('connecting'); setCloudError(null);
    try {
      let { data: { session } } = await sb.auth.getSession();
      if (!session) {
        const r = await sb.auth.signInAnonymously();
        if (r.error) throw r.error;
        session = r.data.session;
      }
      if (!session) throw new Error('Sesi tidak tersedia');
      const uid = session.user.id;
      setUserId(uid); setAnon(Boolean(session.user.is_anonymous));
      activityLog.setUser(uid); notifLog.setUser(uid);
      const p = await ensureProfile(uid);
      setProfileState(p);
      void setOnline(uid, true);
      void activityLog.hydrate(); void notifLog.hydrate();
      setCloud('ready');
    } catch (e) {
      setCloud('error'); setCloudError(explain(e));
    } finally { busy.current = false; }
  }, []);

  // sambungkan otomatis begitu gerbang login terlewati (atau setelah refresh)
  useEffect(() => {
    if (hydrated && gate !== 'none' && cloud === 'idle') void connect();
  }, [hydrated, gate, cloud, connect]);

  // jaga token tetap valid + sinkron antar tab
  useEffect(() => {
    const sb = getSupabase();
    if (!sb) return;
    const { data } = sb.auth.onAuthStateChange((evt, session) => {
      if (evt === 'SIGNED_OUT') { setUserId(null); setProfileState(null); }
      else if (session) setUserId(session.user.id);
    });
    return () => data.subscription.unsubscribe();
  }, []);

  // tandai offline saat halaman ditutup (best-effort)
  useEffect(() => {
    if (!userId) return;
    const off = () => { void setOnline(userId, false); };
    window.addEventListener('pagehide', off);
    return () => window.removeEventListener('pagehide', off);
  }, [userId]);

  const advance = useCallback((g: Gate) => { setGate(g); setGateState(g); }, []);

  const logout = useCallback(async () => {
    if (userId) { logActivity('logout', 'Logout'); void setOnline(userId, false); }
    setGate('none'); setGateState('none');
  }, [userId]);

  const resetIdentity = useCallback(async () => {
    const sb = getSupabase();
    if (userId) await setOnline(userId, false).catch(() => undefined);
    if (sb) await sb.auth.signOut().catch(() => undefined);
    activityLog.wipeLocal(); notifLog.wipeLocal();
    activityLog.setUser(null); notifLog.setUser(null);
    setUserId(null); setProfileState(null); setCloud('idle');
    setGate('none'); setGateState('none');
  }, [userId]);

  const value = useMemo<Ctx>(() => ({
    hydrated, gate, cloud, cloudError, userId, profile, isAnonymous, advance, connect, logout, resetIdentity,
    setProfile: setProfileState,
  }), [hydrated, gate, cloud, cloudError, userId, profile, isAnonymous, advance, connect, logout, resetIdentity]);

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
