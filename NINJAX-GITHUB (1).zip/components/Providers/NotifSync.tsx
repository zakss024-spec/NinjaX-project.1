'use client';
import { useEffect } from 'react';
import { managedChannel } from '@/lib/realtime';
import type { NotificationItem } from '@/lib/types';
import { notifLog } from '@/services/notifications';
import { useAuth } from './AuthProvider';

/** Sinkronkan notifikasi milik user antar perangkat/tab lewat Supabase Realtime (RLS: hanya baris sendiri). */
export function NotifSync() {
  const { cloud, userId } = useAuth();
  useEffect(() => {
    if (cloud !== 'ready' || !userId) return;
    const m = managedChannel({
      name: 'ninjax-notif',
      onStatus: () => undefined,
      build: (ch) => {
        ch.on('postgres_changes', { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${userId}` }, (p) => {
          if (p.eventType === 'DELETE') { const id = (p.old as { id?: string }).id; if (id) notifLog.store.set((l) => l.filter((x) => x.id !== id)); }
          else notifLog.store.set((l) => {
            const n = p.new as NotificationItem;
            return [n, ...l.filter((x) => x.id !== n.id)].sort((a, b) => (a.created_at < b.created_at ? 1 : -1)).slice(0, 100);
          });
        });
      },
    });
    return () => m.destroy();
  }, [cloud, userId]);
  return null;
}
