'use client';
import { useMemo, useState } from 'react';
import { Button } from '@/components/UI/Button';
import { Chip, EmptyState } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { useUI } from '@/components/Providers/UIProvider';
import { useStore } from '@/hooks/useStore';
import { ACTIVITY_GROUPS, activityLog } from '@/services/activity';
import { fmtDateTime } from '@/lib/utils';
import type { ActivityItem } from '@/lib/types';

const TONE: Record<string, 'ok' | 'cy' | 'warn' | 'bad' | 'default'> = { login: 'ok', fingerprint: 'ok', logout: 'warn', module: 'default', chat: 'cy', sender: 'cy', settings: 'warn', security: 'bad', terminal: 'default' };
export const toneOf = (k: string) => TONE[k] ?? (k.startsWith('lab:') ? 'cy' : 'default');

export function ActivityList({ groups, title, clearable }: { groups?: string[]; title?: string; clearable?: boolean }) {
  const all = useStore(activityLog.store);
  const { confirm, toast } = useUI();
  const [q, setQ] = useState('');
  const [f, setF] = useState<string>('all');
  const [lim, setLim] = useState(30);

  const keys = groups ?? Object.keys(ACTIVITY_GROUPS);
  const rows = useMemo(() => {
    const allowed = new Set(keys.flatMap((g) => ACTIVITY_GROUPS[g] ?? []));
    const t = q.trim().toLowerCase();
    return all.filter((a: ActivityItem) => (groups ? allowed.has(a.kind) : true) && (f === 'all' || (ACTIVITY_GROUPS[f] ?? []).includes(a.kind)) && (!t || a.detail.toLowerCase().includes(t) || a.kind.includes(t)));
  }, [all, q, f, keys, groups]);

  const clear = async () => {
    if (await confirm({ title: 'CLEAR ACTIVITY', text: 'Hapus seluruh riwayat aktivitas milik Anda?', confirm: 'CLEAR', danger: true })) { activityLog.clear(); toast('Riwayat dihapus', 'success'); }
  };

  return (
    <>
      <div className="nx-toolbar">
        <label className="nx-search"><Icon name="search" size={18} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search…" aria-label="Search" maxLength={40} /></label>
        {clearable ? <Button size="sm" variant="danger" onClick={() => void clear()} disabled={!all.length}>CLEAR</Button> : null}
      </div>
      {!groups || keys.length > 1 ? (
        <div className="nx-chipscroll" role="group" aria-label="Filter">
          {['all', ...keys].map((g) => <button key={g} type="button" className={`nx-fchip${f === g ? ' is-on' : ''}`} onClick={() => setF(g)} aria-pressed={f === g}>{g.toUpperCase()}</button>)}
        </div>
      ) : null}
      {rows.length === 0 ? <EmptyState icon="activity" title={title ?? 'NO ACTIVITY'} text="Jalankan modul atau kirim chat untuk melihat aktivitas di sini." /> : (
        <ul className="nx-timeline">
          {rows.slice(0, lim).map((a) => (
            <li key={a.id}><time>{fmtDateTime(a.created_at)}</time><div><Chip tone={toneOf(a.kind)}>{a.kind.replace('lab:', '').toUpperCase()}</Chip><span>{a.detail}</span></div></li>
          ))}
        </ul>
      )}
      {rows.length > lim ? <Button block variant="ghost" size="sm" onClick={() => setLim((l) => l + 30)}>SHOW MORE ({rows.length - lim})</Button> : null}
    </>
  );
}
