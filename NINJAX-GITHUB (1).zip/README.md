# NINJAX

Cyber operations center bergaya futuristik: **Global Chat realtime**, **Sender Manager (Private/Global)**, dan **lab simulasi** — Next.js 15 + React 19 + TypeScript + Supabase. Mobile-first (Android), desktop didukung.

> Semua modul lab (BUG, BUG GROUP, BAN GROUP, HACK, OSINT, NETWORK, REPORT, EXPLOIT, TERMINAL) adalah **simulasi lokal/edukasi** dengan data fiktif. Tidak ada request ke target, tidak ada shell asli, tidak ada pengiriman ke WhatsApp/SMS/email/platform lain. Sender hanyalah profil internal NinjaX.

## 1. Install dependencies
```bash
npm install
```
Butuh Node.js 18.18+ (disarankan 20+).

## 2. Setup Supabase
1. Buat project di <https://supabase.com>.
2. **Authentication → Providers → Anonymous Sign-Ins → Enable.** (Login demo hanyalah gerbang UI; identitas nyata untuk RLS memakai sesi anonim Supabase.)
3. **SQL Editor** → tempel isi `supabase/schema.sql` → **Run** (aman dijalankan ulang).

## 3. Environment variables
Salin `.env.local.example` menjadi `.env.local`, lalu isi:
```
NEXT_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=<publishable/anon key>
```
Jangan pernah memasukkan `service_role` / secret key ke frontend atau repo.

## 4. Tabel database
| Tabel | Isi |
|---|---|
| `profiles` | id, username, display_name, avatar_url, online, last_seen, created_at |
| `messages` | id, user_id, username, content, created_at, updated_at |
| `senders_global` | sender global (nama, sender_id, avatar, status, owner, aktivitas) |
| `notifications` | notifikasi per pengguna |
| `activity` | riwayat aktivitas per pengguna |

## 5. RLS
Semua tabel memakai Row Level Security; akses `anon` dicabut, hanya `authenticated`. Pengguna hanya dapat mengubah/menghapus barisnya sendiri; `messages` dan `senders_global` dapat dibaca semua pengguna NinjaX. Trigger `messages_guard` memaksa `username` dari profil, membersihkan karakter kontrol, menolak pesan kosong, dan membatasi **6 pesan / 10 detik** per pengguna.

## 6. Realtime
`schema.sql` menambahkan `messages`, `senders_global`, `notifications`, `profiles` ke publication `supabase_realtime` dan memakai `replica identity full`. Chat memakai listener `postgres_changes` (INSERT/UPDATE/DELETE) + **Presence** untuk daftar online, dengan reconnect otomatis (exponential backoff), sinkronisasi ulang setelah tersambung, dan pembersihan channel saat unmount. Status ditampilkan: `REALTIME CONNECTED` / `REALTIME DISCONNECTED`.

## 7. Menjalankan lokal
```bash
npm run dev        # http://localhost:3000
npm run typecheck  # pemeriksaan tipe
npm run build && npm start
```
Login demo (hanya alur UI): `Ninja` / `Ninja123` → Fingerprint (simulasi) → Ninja Loading (`[ SKIP INTRO ]` tersedia) → Dashboard.

**Tes chat dua perangkat:** buka app di dua browser/perangkat (atau satu normal + satu incognito), login keduanya, buka CHAT; kirim "Hello" dari A → muncul di B tanpa refresh.

## 8. GitHub
```bash
git init && git add . && git commit -m "NinjaX"
git branch -M main
git remote add origin https://github.com/<user>/ninjax.git
git push -u origin main
```
`.env.local` ada di `.gitignore`.

## 9. Deploy ke Vercel
1. Vercel → **Add New Project** → import repo GitHub.
2. Framework: Next.js (otomatis).
3. **Settings → Environment Variables**: tambahkan `NEXT_PUBLIC_SUPABASE_URL` dan `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY` (Production/Preview/Development). Variabel `NEXT_PUBLIC_*` ditanam saat build, jadi **redeploy** setelah mengubahnya.
4. Deploy. Pastikan Anonymous Sign-Ins aktif dan `schema.sql` sudah dijalankan.

## Struktur
```
app/ (login, fingerprint, loading, (app)/dashboard|chat|sender|tools|labs|activity|history|notifications|security|statistics|settings)
components/ (Shell, Chat, Sender, Labs, Terminal, Dashboard, Providers, UI, Visual)
lib/ (supabase, auth, realtime, moderation, sim, settings, ...)  hooks/  services/  styles/  public/assets/  supabase/schema.sql
```

## Catatan keamanan & batasan
- Kredensial demo `Ninja/Ninja123` ada di kode klien — itu hanya gerbang UI, **bukan** keamanan. Keamanan data berasal dari Supabase Auth + RLS + trigger server.
- Password tidak disimpan. Rate limit chat ada di klien **dan** server (trigger).
- Sender **Private** disimpan di perangkat (localStorage); **Global** disimpan di Supabase.
- Fingerprint adalah animasi UI lokal, bukan akses biometrik perangkat.
- `next.config.mjs` memakai `typescript.ignoreBuildErrors` agar build tidak gagal karena tipe; jalankan `npm run typecheck` sebelum rilis dan hapus opsi itu bila ingin build ketat.

## Troubleshooting
- *"REALTIME DISCONNECTED"* / tidak ada pesan: cek env vars, Anonymous Sign-Ins, dan bahwa `schema.sql` sudah dijalankan.
- *Error saat login Supabase*: Anonymous Sign-Ins belum diaktifkan.
- *Pesan "RATE_LIMITED"*: terlalu cepat mengirim; tunggu beberapa detik.
