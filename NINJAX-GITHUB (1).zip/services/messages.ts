import { getSupabase } from '@/lib/supabase';
import type { ChatMessage } from '@/lib/types';
import { errMsg } from '@/lib/utils';

export function friendlyError(e: unknown): string {
  const m = errMsg(e);
  if (m.includes('RATE_LIMITED')) return 'Terlalu cepat — tunggu sebentar.';
  if (m.includes('EMPTY_MESSAGE')) return 'Pesan kosong.';
  if (m.includes('PROFILE_REQUIRED')) return 'Profil belum siap. Muat ulang halaman.';
  if (/row-level security|permission/i.test(m)) return 'Akses ditolak oleh kebijakan keamanan (RLS).';
  if (/fetch|network|Failed/i.test(m)) return 'Jaringan bermasalah.';
  return m;
}

export async function fetchRecent(limit = 100): Promise<ChatMessage[]> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('messages').select('*').order('created_at', { ascending: false }).limit(limit);
  if (error) throw error;
  return ((data ?? []) as ChatMessage[]).reverse();
}

export async function fetchSince(iso: string): Promise<ChatMessage[]> {
  const sb = getSupabase();
  if (!sb) return [];
  const { data, error } = await sb.from('messages').select('*').gt('created_at', iso).order('created_at', { ascending: true }).limit(200);
  if (error) throw error;
  return (data ?? []) as ChatMessage[];
}

export async function insertMessage(m: { id: string; user_id: string; username: string; content: string }): Promise<ChatMessage> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('messages').insert(m).select('*').single();
  if (error) throw error;
  return data as ChatMessage;
}

export async function editMessage(id: string, content: string): Promise<ChatMessage> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('messages').update({ content }).eq('id', id).select('*').single();
  if (error) throw error;
  return data as ChatMessage;
}

export async function removeMessage(id: string): Promise<void> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { error } = await sb.from('messages').delete().eq('id', id);
  if (error) throw error;
}

export async function countMessages(): Promise<number> {
  const sb = getSupabase();
  if (!sb) return 0;
  const { count } = await sb.from('messages').select('id', { count: 'exact', head: true });
  return count ?? 0;
}
