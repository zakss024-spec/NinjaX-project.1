import { getSupabase } from '@/lib/supabase';
import type { Profile } from '@/lib/types';
import { cleanText } from '@/lib/utils';

const COLS = 'id,username,display_name,avatar_url,online,last_seen,created_at';

function randomHandle(): string {
  const a = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let s = '';
  for (let i = 0; i < 5; i++) s += a[Math.floor(Math.random() * a.length)];
  return `ninja_${s}`;
}

/** Ambil profil milik user; buat bila belum ada (username acak unik). */
export async function ensureProfile(userId: string): Promise<Profile> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const got = await sb.from('profiles').select(COLS).eq('id', userId).maybeSingle();
  if (got.error) throw got.error;
  if (got.data) return got.data as Profile;
  for (let i = 0; i < 6; i++) {
    const username = randomHandle();
    const display = 'Ninja ' + username.slice(-4).toUpperCase();
    const ins = await sb.from('profiles').insert({ id: userId, username, display_name: display, avatar_url: `/assets/avatars/a${1 + Math.floor(Math.random() * 6)}.svg`, online: true }).select(COLS).single();
    if (!ins.error) return ins.data as Profile;
    if (ins.error.code !== '23505') throw ins.error;
    // 23505 = unique violation: bisa karena race pada id (profil sudah ada) atau username bentrok
    const again = await sb.from('profiles').select(COLS).eq('id', userId).maybeSingle();
    if (again.data) return again.data as Profile;
  }
  throw new Error('Gagal membuat profil');
}

export async function updateProfile(userId: string, patch: { display_name?: string; avatar_url?: string | null }): Promise<Profile> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const p: Record<string, unknown> = {};
  if (patch.display_name !== undefined) {
    const n = cleanText(patch.display_name, 24);
    if (n.length < 2) throw new Error('Nama tampilan minimal 2 karakter.');
    p.display_name = n;
  }
  if (patch.avatar_url !== undefined) p.avatar_url = patch.avatar_url;
  const { data, error } = await sb.from('profiles').update(p).eq('id', userId).select(COLS).single();
  if (error) throw error;
  return data as Profile;
}

export async function setOnline(userId: string, online: boolean) {
  const sb = getSupabase();
  if (!sb) return;
  await sb.from('profiles').update({ online, last_seen: new Date().toISOString() }).eq('id', userId);
}

export async function fetchProfiles(ids: string[]): Promise<Profile[]> {
  const sb = getSupabase();
  if (!sb || ids.length === 0) return [];
  const { data } = await sb.from('profiles').select(COLS).in('id', ids.slice(0, 100));
  return (data ?? []) as Profile[];
}
