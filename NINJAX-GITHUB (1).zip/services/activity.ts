import { createLog } from '@/lib/logStore';
import type { ActivityItem } from '@/lib/types';

export const activityLog = createLog<ActivityItem>({ key: 'activity', table: 'activity', cap: 400 });

/** Catat aktivitas (lokal instan + mirror ke Supabase). */
export function logActivity(kind: string, detail: string, meta?: Record<string, unknown>): ActivityItem {
  return activityLog.add({ kind, detail: detail.slice(0, 240), meta: meta ?? null });
}

export const ACTIVITY_GROUPS: Record<string, string[]> = {
  login: ['login', 'fingerprint', 'logout'],
  module: ['module'],
  chat: ['chat'],
  sender: ['sender'],
  settings: ['settings'],
  security: ['security'],
  scan: ['lab:bug', 'lab:bug-group', 'lab:ban-group', 'lab:hack', 'lab:report', 'lab:exploit', 'lab:osint', 'lab:network', 'terminal'],
};
