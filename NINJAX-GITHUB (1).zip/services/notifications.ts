import { createLog } from '@/lib/logStore';
import { settingsStore } from '@/lib/settings';
import type { NotifKind, NotificationItem } from '@/lib/types';

export const notifLog = createLog<NotificationItem>({ key: 'notifications', table: 'notifications', cap: 100 });

let lastChatAt = 0;
let lastChatId: string | null = null;
let chatCount = 0;

/** Tambah notifikasi sesuai pengaturan. Notifikasi chat digabung agar tidak membanjiri. */
export function pushNotification(kind: NotifKind, title: string, body?: string): NotificationItem | null {
  const s = settingsStore.get();
  if (kind === 'chat' && !s.notifyChat) return null;
  if (kind !== 'chat' && !s.notifySystem) return null;
  if (kind === 'chat') {
    const now = Date.now();
    if (lastChatId && now - lastChatAt < 15000) {
      chatCount += 1;
      lastChatAt = now;
      notifLog.update(lastChatId, { title: `${chatCount} new chat messages`, body: body ?? null, read: false, created_at: new Date().toISOString() });
      return null;
    }
    chatCount = 1; lastChatAt = now;
    const it = notifLog.add({ kind, title, body: body ?? null, read: false });
    lastChatId = it.id;
    return it;
  }
  return notifLog.add({ kind, title, body: body ?? null, read: false });
}
