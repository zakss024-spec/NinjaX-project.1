import { getSupabase } from '@/lib/supabase';
import { createStore } from '@/lib/store';
import { lsGetJson, lsSetJson } from '@/lib/storage';
import type { Sender, SenderStatus } from '@/lib/types';
import { cleanText, uid } from '@/lib/utils';

export type SenderInput = { name: string; sender_code: string; avatar_url: string | null; status: SenderStatus; note: string | null };

export function validateSender(i: SenderInput): string | null {
  const name = cleanText(i.name, 32);
  if (name.length < 2) return 'Nama sender minimal 2 karakter.';
  if (!/^[A-Za-z0-9_-]{3,24}$/.test(i.sender_code)) return 'Sender ID: 3–24 karakter (huruf, angka, _ atau -).';
  if (i.note && i.note.length > 120) return 'Catatan maksimal 120 karakter.';
  return null;
}
export const normalizeInput = (i: SenderInput): SenderInput => ({ ...i, name: cleanText(i.name, 32), sender_code: i.sender_code.trim(), note: i.note ? cleanText(i.note, 120) : null });

/* =============== PRIVATE (localStorage, hanya perangkat ini) =============== */
const PKEY = 'senders.private.v1';
export const privateStore = createStore<Sender[]>([]);
let pLoaded = false;
let corruptNotified: (() => void) | null = null;
export function onPrivateCorrupt(fn: () => void) { corruptNotified = fn; }

const isSenderArr = (v: unknown) => Array.isArray(v) && v.every((s) => s && typeof (s as Sender).id === 'string' && typeof (s as Sender).name === 'string');

export function loadPrivate() {
  if (pLoaded) return;
  pLoaded = true;
  privateStore.set(lsGetJson<Sender[]>(PKEY, [], isSenderArr, () => corruptNotified?.()));
}
function savePrivate(list: Sender[]) { privateStore.set(list); lsSetJson(PKEY, list); }

export function privateCodeTaken(code: string, exceptId?: string) {
  return privateStore.get().some((s) => s.id !== exceptId && s.sender_code.toLowerCase() === code.toLowerCase());
}
export function addPrivate(i: SenderInput): Sender {
  const now = new Date().toISOString();
  const s: Sender = { id: uid(), ...normalizeInput(i), created_at: now, updated_at: now, last_activity: now };
  savePrivate([s, ...privateStore.get()]);
  return s;
}
export function updatePrivate(id: string, patch: Partial<SenderInput>) {
  const now = new Date().toISOString();
  savePrivate(privateStore.get().map((s) => (s.id === id ? { ...s, ...patch, updated_at: now, last_activity: now } : s)));
}
export function touchPrivate(id: string) {
  savePrivate(privateStore.get().map((s) => (s.id === id ? { ...s, last_activity: new Date().toISOString() } : s)));
}
export function removePrivate(id: string) { savePrivate(privateStore.get().filter((s) => s.id !== id)); }

/* =============== GLOBAL (Supabase, RLS) =============== */
const COLS = 'id,owner_id,name,sender_code,avatar_url,status,note,created_at,updated_at,last_activity';

export async function fetchGlobal(): Promise<Sender[]> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('senders_global').select(COLS).order('created_at', { ascending: false }).limit(500);
  if (error) throw error;
  return (data ?? []) as Sender[];
}
export async function addGlobal(ownerId: string, i: SenderInput): Promise<Sender> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('senders_global').insert({ owner_id: ownerId, ...normalizeInput(i) }).select(COLS).single();
  if (error) throw error.code === '23505' ? new Error('Sender ID sudah dipakai.') : error;
  return data as Sender;
}
export async function updateGlobal(id: string, patch: Partial<SenderInput>): Promise<Sender> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { data, error } = await sb.from('senders_global').update({ ...patch, last_activity: new Date().toISOString() }).eq('id', id).select(COLS).single();
  if (error) throw error.code === '23505' ? new Error('Sender ID sudah dipakai.') : error;
  return data as Sender;
}
export async function removeGlobal(id: string): Promise<void> {
  const sb = getSupabase();
  if (!sb) throw new Error('Supabase belum dikonfigurasi');
  const { error } = await sb.from('senders_global').delete().eq('id', id);
  if (error) throw error;
}
