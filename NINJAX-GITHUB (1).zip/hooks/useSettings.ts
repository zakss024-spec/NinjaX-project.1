'use client';
import { useEffect } from 'react';
import { loadSettings, settingsStore, updateSettings, type Settings } from '@/lib/settings';
import { useStore } from './useStore';

export function useSettings(): [Settings, (p: Partial<Settings>) => void] {
  const s = useStore(settingsStore);
  useEffect(() => { loadSettings(); }, []);
  return [s, updateSettings];
}
