'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { settingsStore } from '@/lib/settings';

export type SimStage = { at: number; status: string; lines: string[] };
export type SimState = 'READY' | string;

const FACTOR = { slow: 1.6, normal: 1, fast: 0.6 } as const;

/**
 * Mesin simulasi berbasis waktu (Date.now) — progres tidak bisa macet.
 * Semua timer dibersihkan saat unmount / stop / reset.
 */
export function useSimulation(duration = 4200) {
  const [status, setStatus] = useState<SimState>('READY');
  const [pct, setPct] = useState(0);
  const [lines, setLines] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [done, setDone] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const emitted = useRef(0);
  const cfg = useRef<{ stages: SimStage[]; onDone: () => void; start: number; total: number } | null>(null);

  const clear = useCallback(() => { if (timer.current) { clearInterval(timer.current); timer.current = null; } }, []);
  useEffect(() => clear, [clear]);

  const reset = useCallback(() => {
    clear(); emitted.current = 0; cfg.current = null;
    setStatus('READY'); setPct(0); setLines([]); setRunning(false); setDone(false);
  }, [clear]);

  const stop = useCallback(() => {
    if (!timer.current) return;
    clear(); setRunning(false); setStatus('STOPPED');
    setLines((l) => [...l, '[!] simulation stopped by user']);
  }, [clear]);

  const start = useCallback((stages: SimStage[], onDone: () => void) => {
    if (timer.current) return false;
    const speed = settingsStore.get().animations ? FACTOR[settingsStore.get().animSpeed] : 0.35;
    const total = duration * speed;
    emitted.current = 0; setLines([]); setPct(0); setDone(false); setRunning(true); setStatus(stages[0]?.status ?? 'INITIALIZING');
    cfg.current = { stages, onDone, start: Date.now(), total };
    const tick = () => {
      const c = cfg.current; if (!c) return;
      const p = Math.min(100, Math.round(((Date.now() - c.start) / c.total) * 100));
      setPct(p);
      let idx = 0;
      c.stages.forEach((s, i) => { if (p >= s.at) idx = i; });
      setStatus(c.stages[idx].status);
      const flat: string[] = [];
      c.stages.forEach((s, i) => { if (i <= idx) flat.push(...s.lines); });
      if (flat.length > emitted.current) {
        const add = flat.slice(emitted.current);
        emitted.current = flat.length;
        setLines((l) => [...l, ...add]);
      }
      if (p >= 100) {
        clear(); setRunning(false); setDone(true); setStatus('COMPLETED'); c.onDone();
      }
    };
    timer.current = setInterval(tick, 90);
    tick();
    return true;
  }, [clear, duration]);

  return { status, pct, lines, running, done, start, stop, reset };
}
