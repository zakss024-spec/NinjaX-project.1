'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { getSupabase } from '@/lib/supabase';
import { lsKeys } from '@/lib/storage';
import { logActivity } from '@/services/activity';

export type Check = { group: string; label: string; ok: boolean; warn?: boolean; value: string; weight: number };

/** Pemeriksaan keamanan LOKAL aplikasi (bukan audit keamanan sungguhan). */
export function useSecurity(autoRun = false) {
  const { cloud, userId, gate, isAnonymous } = useAuth();
  const { status } = useChat();
  const [probes, setProbes] = useState<{ dbMs: number | null; dbOk: boolean | null; rlsOk: boolean | null; expires: number | null }>({ dbMs: null, dbOk: null, rlsOk: null, expires: null });
  const [running, setRunning] = useState(false);
  const alive = useRef(true);
  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);

  const run = useCallback(async () => {
    const sb = getSupabase();
    if (!sb || !userId) return;
    setRunning(true);
    let dbMs: number | null = null, dbOk = false, rlsOk: boolean | null = null, expires: number | null = null;
    try {
      const t0 = performance.now();
      const r = await sb.from('profiles').select('id', { count: 'exact', head: true });
      dbMs = Math.round(performance.now() - t0); dbOk = !r.error;
      // RLS probe: baris notifikasi milik user LAIN tidak boleh terlihat
      const n = await sb.from('notifications').select('id', { count: 'exact', head: true }).neq('user_id', userId);
      rlsOk = !n.error && (n.count ?? 0) === 0;
      const s = await sb.auth.getSession();
      expires = s.data.session?.expires_at ?? null;
    } catch { dbOk = false; }
    if (alive.current) { setProbes({ dbMs, dbOk, rlsOk, expires }); setRunning(false); }
    logActivity('security', `Security check ${dbOk && rlsOk !== false ? 'passed' : 'warning'}`);
  }, [userId]);

  useEffect(() => { if (autoRun && cloud === 'ready') void run(); }, [autoRun, cloud, run]);

  const secure = typeof window !== 'undefined' && (window.isSecureContext || /^(localhost|127\.0\.0\.1)$/.test(window.location.hostname));
  const leak = typeof window !== 'undefined' && lsKeys().some((k) => { try { return (window.localStorage.getItem(k) ?? '').includes('Ninja123'); } catch { return false; } });

  const checks: Check[] = [
    { group: 'SESSION', label: 'Access gate', ok: gate === 'ready', value: gate === 'ready' ? 'VERIFIED' : 'INCOMPLETE', weight: 20 },
    { group: 'SESSION', label: 'Auth session', ok: cloud === 'ready' && !!userId, value: cloud === 'ready' ? (isAnonymous ? 'ACTIVE (anonymous)' : 'ACTIVE') : cloud.toUpperCase(), weight: 20 },
    { group: 'SESSION', label: 'Token expiry', ok: probes.expires === null || probes.expires * 1000 > Date.now(), warn: probes.expires === null, value: probes.expires ? new Date(probes.expires * 1000).toLocaleTimeString() : 'run check', weight: 3 },
    { group: 'REALTIME', label: 'Realtime connection', ok: status === 'connected', warn: status === 'connecting', value: status.toUpperCase(), weight: 15 },
    { group: 'DATABASE', label: 'Database reachable', ok: probes.dbOk === true, warn: probes.dbOk === null, value: probes.dbOk === null ? 'run check' : probes.dbOk ? `OK · ${probes.dbMs} ms` : 'UNREACHABLE', weight: 15 },
    { group: 'DATABASE', label: 'RLS own-rows probe', ok: probes.rlsOk === true, warn: probes.rlsOk === null, value: probes.rlsOk === null ? 'run check' : probes.rlsOk ? 'ENFORCED (no foreign rows)' : 'CHECK POLICIES', weight: 15 },
    { group: 'CLIENT', label: 'Password not stored', ok: !leak, value: leak ? 'FOUND IN STORAGE' : 'NOT STORED', weight: 20 },
    { group: 'CLIENT', label: 'Secure context (HTTPS)', ok: secure, value: secure ? 'YES' : 'NO', weight: 5 },
    { group: 'CLIENT', label: 'Secret keys in frontend', ok: true, value: 'NONE (publishable key only)', weight: 0 },
  ];
  const lost = checks.reduce((a, c) => a + (!c.ok && !c.warn ? c.weight : c.warn && !c.ok ? c.weight * 0.3 : 0), 0);
  const score = Math.max(0, Math.round(100 - lost));
  return { checks, score, run, running, probes };
}
