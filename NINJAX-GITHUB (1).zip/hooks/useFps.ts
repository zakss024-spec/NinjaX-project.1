'use client';
import { useEffect, useState } from 'react';

/** Hitung FPS nyata lewat requestAnimationFrame; berhenti saat tab tersembunyi atau komponen di-unmount. */
export function useFps(active = true): number {
  const [fps, setFps] = useState(0);
  useEffect(() => {
    if (!active) return;
    let raf = 0; let frames = 0; let last = performance.now(); let stopped = false;
    const loop = (t: number) => {
      if (stopped) return;
      frames++;
      if (t - last >= 1000) { setFps(Math.round((frames * 1000) / (t - last))); frames = 0; last = t; }
      raf = requestAnimationFrame(loop);
    };
    const vis = () => { if (document.hidden) { cancelAnimationFrame(raf); } else { last = performance.now(); frames = 0; raf = requestAnimationFrame(loop); } };
    raf = requestAnimationFrame(loop);
    document.addEventListener('visibilitychange', vis);
    return () => { stopped = true; cancelAnimationFrame(raf); document.removeEventListener('visibilitychange', vis); };
  }, [active]);
  return fps;
}
