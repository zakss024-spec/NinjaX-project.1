import { hash32, pick, rng } from './utils';

/** Generator data FIKTIF deterministik. Tidak ada request jaringan dan tidak ada data nyata. */
export type Sev = 'low' | 'medium' | 'high' | 'critical';
export const SEVERITIES: Sev[] = ['low', 'medium', 'high', 'critical'];
export const sevTone = (s: Sev | string) => (s === 'critical' ? 'bad' : s === 'high' ? 'bad' : s === 'medium' ? 'warn' : 'ok') as 'bad' | 'warn' | 'ok';

/** Hanya target fiktif: *.local / *.test / *.example / *.invalid, rentang dokumentasi RFC 5737, atau 192.168.x.x. */
export function validTarget(t: string): boolean {
  const s = t.trim().toLowerCase();
  if (!s || s.length > 64) return false;
  if (/^(?:[a-z0-9-]+\.)+(local|test|example|invalid)$/.test(s)) return true;
  const m = s.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m) return false;
  const o = m.slice(1).map(Number);
  if (o.some((n) => n > 255)) return false;
  return (o[0] === 192 && o[1] === 0 && o[2] === 2) || (o[0] === 198 && o[1] === 51 && o[2] === 100) || (o[0] === 203 && o[1] === 0 && o[2] === 113) || (o[0] === 192 && o[1] === 168);
}

export const traceId = (seed: string) => 'SIM-' + hash32(seed).toString(16).toUpperCase().padStart(8, '0');

/* ---------------- BUG ---------------- */
export const BUG_TYPES = [
  { id: 'message-ui', label: 'MESSAGE UI', comps: ['bubble-renderer', 'timestamp-label', 'avatar-slot', 'reply-preview'] },
  { id: 'group-ui', label: 'GROUP UI', comps: ['member-list', 'header-bar', 'pin-banner', 'unread-divider'] },
  { id: 'connection', label: 'CONNECTION', comps: ['socket-layer', 'retry-queue', 'heartbeat', 'sync-cursor'] },
  { id: 'loading', label: 'LOADING STATE', comps: ['skeleton-view', 'lazy-chunk', 'image-pipeline', 'cache-layer'] },
  { id: 'render', label: 'RENDER', comps: ['layout-engine', 'paint-scheduler', 'font-loader', 'scroll-anchor'] },
];
export function bugResult(target: string, type: string, sev: Sev) {
  const t = BUG_TYPES.find((b) => b.id === type) ?? BUG_TYPES[0];
  const r = rng(`${target}|${type}|${sev}`);
  const n = 1 + SEVERITIES.indexOf(sev) + Math.floor(r() * 2);
  const notes = ['Layout shift ketika konten dimuat', 'State tidak sinkron setelah rekoneksi', 'Event handler terpasang ganda', 'Memori naik pada sesi panjang', 'Fallback tidak ditampilkan saat error', 'Urutan render tidak konsisten'];
  const findings = Array.from({ length: n }, (_, i) => ({ id: `${traceId(target + type + i)}`, component: pick(r, t.comps), severity: SEVERITIES[Math.min(3, Math.max(0, SEVERITIES.indexOf(sev) - (i > 1 ? 1 : 0)))], note: pick(r, notes) }));
  return { trace: traceId(`${target}${type}${sev}`), type: t.label, findings, score: Math.max(8, 100 - n * 11 - Math.floor(r() * 9)), duration: 800 + Math.floor(r() * 2400) };
}

/* ---------------- BUG GROUP ---------------- */
export const GROUPS = [
  { id: 'ninja-squad', label: 'NINJA SQUAD', members: 12 },
  { id: 'shadow-team', label: 'SHADOW TEAM', members: 8 },
  { id: 'cyber-lab', label: 'CYBER LAB', members: 21 },
  { id: 'void-crew', label: 'VOID CREW', members: 5 },
];
export const GROUP_SCANS = [
  { id: 'ui', label: 'GROUP UI' }, { id: 'message', label: 'MESSAGE FLOW' }, { id: 'member', label: 'MEMBER EVENTS' }, { id: 'connection', label: 'CONNECTION' },
];
export function groupResult(groupId: string, scan: string) {
  const g = GROUPS.find((x) => x.id === groupId) ?? GROUPS[0];
  const r = rng(`${groupId}|${scan}`);
  const anomalies = Math.floor(r() * 5);
  const events = ['member_join', 'member_leave', 'pin_update', 'title_change', 'permission_sync', 'reaction_burst'];
  return {
    group: g.label, members: g.members, scanned: g.members, anomalies, health: Math.max(40, 100 - anomalies * 9 - Math.floor(r() * 8)),
    events: Array.from({ length: 4 + Math.floor(r() * 3) }, (_, i) => ({ t: `T+${(i * 0.7 + r()).toFixed(1)}s`, ev: pick(r, events), ok: r() > 0.25 })),
  };
}

/* ---------------- BAN GROUP ---------------- */
export const BAN_REASONS = [
  { id: 'spam', label: 'SPAM PATTERN' }, { id: 'abuse', label: 'ABUSIVE CONTENT' }, { id: 'fake', label: 'FAKE ACCOUNT SIGNALS' },
  { id: 'rule', label: 'RULE VIOLATION (SIM)' }, { id: 'custom', label: 'OTHER (SIM)' },
];
export function banResult(group: string, reason: string, sev: Sev) {
  const r = rng(`${group}|${reason}|${sev}`);
  return {
    group, reason: BAN_REASONS.find((b) => b.id === reason)?.label ?? reason, severity: sev,
    verdict: sev === 'low' ? 'WARNING ISSUED (SIMULATED)' : sev === 'medium' ? 'MUTE 24H (SIMULATED)' : 'BAN APPLIED (SIMULATED)',
    audit: traceId(`${group}${reason}`), reviewers: 1 + Math.floor(r() * 3), confidence: 70 + Math.floor(r() * 28),
  };
}

/* ---------------- HACK ---------------- */
export const HACK_TARGETS = ['target.local', 'demo.local', 'lab.test', '192.0.2.10', '198.51.100.7'];
const SVC = [[21, 'ftp'], [22, 'ssh'], [25, 'smtp'], [53, 'dns'], [80, 'http'], [110, 'pop3'], [143, 'imap'], [443, 'https'], [3306, 'mysql'], [5432, 'postgres'], [8080, 'http-alt']] as const;
const VULNS = [
  ['Outdated TLS configuration', 'medium', 'Nonaktifkan protokol lama; gunakan TLS 1.2+ dengan cipher modern.'],
  ['Verbose error messages', 'low', 'Tampilkan pesan generik ke pengguna; log detail hanya di server.'],
  ['Missing security headers', 'low', 'Tambahkan CSP, X-Content-Type-Options, dan Referrer-Policy.'],
  ['Weak password policy', 'high', 'Terapkan panjang minimum, blocklist, dan MFA.'],
  ['Directory listing enabled', 'medium', 'Matikan autoindex pada web server.'],
  ['Default credentials on admin panel', 'critical', 'Ganti kredensial bawaan dan batasi akses panel admin.'],
  ['Unpatched dependency (simulated)', 'high', 'Perbarui dependensi dan aktifkan pemindaian otomatis.'],
  ['Open service without need', 'medium', 'Tutup port yang tidak diperlukan di firewall.'],
] as const;
export function hackResult(target: string, mode: string) {
  const r = rng(`${target}|${mode}`);
  const ports = SVC.map(([port, name]) => ({ port, name, state: r() > 0.62 ? 'open' : r() > 0.5 ? 'filtered' : 'closed' }));
  const count = 2 + Math.floor(r() * 4);
  const idx = new Set<number>(); while (idx.size < count) idx.add(Math.floor(r() * VULNS.length));
  const vulns = Array.from(idx).map((i) => ({ id: traceId(target + i), name: VULNS[i][0], severity: VULNS[i][1] as Sev, fix: VULNS[i][2] }));
  return { target, mode, ports, vulns, risk: Math.min(99, 18 + vulns.reduce((a, v) => a + (SEVERITIES.indexOf(v.severity) + 1) * 8, 0)), os: pick(r, ['Linux 6.x (sim)', 'FreeBSD (sim)', 'Windows Server (sim)']) };
}

/* ---------------- REPORT ---------------- */
export const ISSUE_TYPES = [
  { id: 'injection', label: 'INPUT VALIDATION' }, { id: 'auth', label: 'AUTHENTICATION' }, { id: 'config', label: 'MISCONFIGURATION' },
  { id: 'exposure', label: 'DATA EXPOSURE' }, { id: 'ui', label: 'UI / UX DEFECT' },
];
export function reportText(v: { issue: string; sev: string; target: string; summary: string }, at = new Date()) {
  const id = traceId(`${v.issue}${v.sev}${v.target}${v.summary}`);
  const issue = ISSUE_TYPES.find((i) => i.id === v.issue)?.label ?? v.issue;
  return [
    '==================================================', ' NINJAX · SECURITY REPORT (SIMULATED)', '==================================================',
    `Report ID : ${id}`, `Generated : ${at.toISOString()}`, `Target    : ${v.target}`, `Issue     : ${issue}`, `Severity  : ${v.sev.toUpperCase()}`, '',
    'SUMMARY', '-------', v.summary || '(no summary provided)', '',
    'RECOMMENDATION', '--------------', '1. Validasi dan sanitasi semua input di sisi server.', '2. Terapkan prinsip least-privilege dan tinjau ulang konfigurasi.', '3. Tambahkan pengujian regresi untuk mencegah kemunculan kembali.', '',
    'NOTE: Laporan ini dibuat lokal untuk simulasi. Tidak dikirim ke pihak mana pun.',
  ].join('\n');
}

/* ---------------- EXPLOIT (edukatif) ---------------- */
export const VULN_KB = [
  { id: 'sqli', label: 'SQL INJECTION', owasp: 'A03:2021 Injection', sev: 'critical' as Sev, token: 'tautology-style string in a query parameter', cause: 'Input pengguna digabung langsung ke query SQL tanpa parameterisasi.', impact: 'Kebocoran atau perubahan data basis data.', fix: ['Gunakan prepared statement / parameterized query', 'Validasi tipe & panjang input', 'Beri akun DB hak akses minimum'] },
  { id: 'xss', label: 'CROSS-SITE SCRIPTING', owasp: 'A03:2021 Injection', sev: 'high' as Sev, token: 'markup-like text inserted into a rendered field', cause: 'Data pengguna dirender sebagai HTML tanpa escape.', impact: 'Pencurian sesi atau manipulasi tampilan di browser korban.', fix: ['Escape output sesuai konteks', 'Terapkan Content-Security-Policy', 'Gunakan framework yang auto-escape (React)'] },
  { id: 'csrf', label: 'CSRF', owasp: 'A01:2021 Broken Access Control', sev: 'medium' as Sev, token: 'forged cross-origin form submission', cause: 'Aksi sensitif tidak memverifikasi asal permintaan.', impact: 'Aksi tidak diinginkan atas nama pengguna.', fix: ['Token anti-CSRF', 'Cookie SameSite=Lax/Strict', 'Verifikasi header Origin'] },
  { id: 'idor', label: 'IDOR', owasp: 'A01:2021 Broken Access Control', sev: 'high' as Sev, token: 'sequential identifier substituted in a request path', cause: 'Server tidak memeriksa kepemilikan objek.', impact: 'Akses ke data pengguna lain.', fix: ['Cek otorisasi per objek', 'Gunakan Row Level Security', 'Gunakan ID tak berurutan (UUID)'] },
  { id: 'path', label: 'PATH TRAVERSAL', owasp: 'A01:2021 Broken Access Control', sev: 'high' as Sev, token: 'parent-directory sequence in a file parameter', cause: 'Path file dari input tidak dinormalisasi.', impact: 'Pembacaan file di luar direktori yang diizinkan.', fix: ['Normalisasi & allowlist path', 'Jangan gunakan input sebagai path langsung', 'Jalankan layanan dengan hak minimum'] },
  { id: 'auth', label: 'AUTH BYPASS', owasp: 'A07:2021 Identification Failures', sev: 'critical' as Sev, token: 'manipulated session/role claim', cause: 'Keputusan otorisasi hanya dipercayakan ke sisi klien.', impact: 'Akses fitur administratif tanpa hak.', fix: ['Validasi sesi di server', 'Gunakan token bertanda tangan & kedaluwarsa', 'Terapkan RLS di database'] },
  { id: 'ssrf', label: 'SSRF', owasp: 'A10:2021 SSRF', sev: 'high' as Sev, token: 'internal address supplied as a fetch URL', cause: 'Server mengambil URL yang dikontrol pengguna.', impact: 'Akses ke layanan internal.', fix: ['Allowlist host tujuan', 'Blokir rentang IP privat', 'Pisahkan jaringan layanan'] },
  { id: 'crypto', label: 'WEAK CRYPTO', owasp: 'A02:2021 Cryptographic Failures', sev: 'medium' as Sev, token: 'legacy hash used for password storage', cause: 'Algoritma hash cepat/usang dipakai untuk kata sandi.', impact: 'Kata sandi mudah dipecahkan bila basis data bocor.', fix: ['Gunakan Argon2id / bcrypt', 'Tambahkan salt unik', 'Terapkan rotasi kredensial'] },
];

/* ---------------- OSINT (fiktif) ---------------- */
const PLATFORMS = ['NinjaNet', 'VoidBook', 'CyberGram', 'ShadowTube', 'GlitchHub', 'NeonBoard', 'PixelForum', 'OrbitChat'];
const TAGS = ['gaming', 'security', 'design', 'music', 'travel', 'coding', 'photography', 'crypto-art', 'memes', 'science'];
export function osintResult(mode: string, q: string) {
  const r = rng(`${mode}|${q.toLowerCase()}`);
  if (mode === 'username') return { mode, hits: PLATFORMS.map((p) => ({ platform: p, found: r() > 0.5, handle: `@${q}`, followers: Math.floor(r() * 5000) })) };
  if (mode === 'profile') return {
    mode, ageDays: 40 + Math.floor(r() * 1800), posts: Math.floor(r() * 900), tags: Array.from(new Set(Array.from({ length: 4 }, () => pick(r, TAGS)))),
    week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((d) => ({ label: d, value: Math.floor(r() * 40) })), risk: Math.floor(r() * 60),
  };
  if (mode === 'metadata') return {
    mode, rows: [['File label', q], ['Format', pick(r, ['JPEG', 'PNG', 'WEBP'])], ['Dimensions', `${800 + Math.floor(r() * 3000)} × ${600 + Math.floor(r() * 2000)}`], ['Device', 'NinjaCam X1 (simulated)'], ['Created', new Date(Date.now() - Math.floor(r() * 4e10)).toISOString().slice(0, 10)], ['GPS', 'REDACTED (simulated)'], ['Software', 'NinjaX Editor 1.0 (sim)']],
  };
  return {
    mode, rows: [['Domain', q], ['Registrar', 'Example Registrar (fictional)'], ['Created', new Date(Date.now() - Math.floor(r() * 6e10)).toISOString().slice(0, 10)], ['Nameservers', 'ns1.example.test, ns2.example.test'], ['TLS issuer', 'Ninja Test CA (fictional)'], ['A record', `192.0.2.${1 + Math.floor(r() * 250)}`], ['MX', `mail.${q}`], ['TXT', 'v=spf1 -all (sim)']],
  };
}
export type OsintResult = ReturnType<typeof osintResult>;
