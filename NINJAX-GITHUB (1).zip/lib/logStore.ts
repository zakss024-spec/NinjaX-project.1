import { createStore } from './store';
import { lsGetJson, lsSetJson } from './storage';
import { getSupabase } from './supabase';
import { uid } from './utils';

type Row = { id: string; created_at: string };

/**
 * Log lokal-dulu (instan, tahan offline) + mirror ke tabel Supabase (best-effort, dibatasi RLS per user).
 * Item memakai id klien (uuid) sehingga hydrate/realtime tidak membuat duplikat.
 */
export function createLog<T extends Row>(opts: { key: string; table: 'activity' | 'notifications'; cap?: number }) {
  const cap = opts.cap ?? 300;
  const store = createStore<T[]>([]);
  let userId: string | null = null;
  let hydrated = false;
  const storeKey = `${opts.key}.v1`;
  const isArr = (v: unknown) => Array.isArray(v);

  function persist() { lsSetJson(storeKey, store.get().slice(0, cap)); }
  function sorted(list: T[]): T[] {
    const seen = new Set<string>();
    return list
      .filter((x) => (seen.has(x.id) ? false : (seen.add(x.id), true)))
      .sort((a, b) => (a.created_at < b.created_at ? 1 : -1))
      .slice(0, cap);
  }

  return {
    store,
    load() { if (!hydrated) { hydrated = true; store.set(sorted(lsGetJson<T[]>(storeKey, [], isArr))); } },
    setUser(id: string | null) { userId = id; },
    /** Gabungkan item dari server (hydrate / realtime). */
    merge(items: T[]) { store.set((prev) => sorted([...items, ...prev])); persist(); },
    async hydrate() {
      const sb = getSupabase();
      if (!sb || !userId) return;
      const { data, error } = await sb.from(opts.table).select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(cap);
      if (!error && data) this.merge(data as unknown as T[]);
    },
    add(partial: Omit<T, 'id' | 'created_at'> & { id?: string; created_at?: string }): T {
      const item = { id: uid(), created_at: new Date().toISOString(), ...partial } as unknown as T;
      store.set((prev) => sorted([item, ...prev]));
      persist();
      const sb = getSupabase();
      if (sb && userId) {
        void sb.from(opts.table).insert({ ...(item as unknown as Record<string, unknown>), user_id: userId }).then(() => undefined, () => undefined);
      }
      return item;
    },
    update(id: string, patch: Partial<T>) {
      store.set((prev) => prev.map((x) => (x.id === id ? { ...x, ...patch } : x)));
      persist();
      const sb = getSupabase();
      if (sb && userId) void sb.from(opts.table).update(patch as Record<string, unknown>).eq('id', id).eq('user_id', userId).then(() => undefined, () => undefined);
    },
    updateAll(patch: Partial<T>) {
      store.set((prev) => prev.map((x) => ({ ...x, ...patch })));
      persist();
      const sb = getSupabase();
      if (sb && userId) void sb.from(opts.table).update(patch as Record<string, unknown>).eq('user_id', userId).then(() => undefined, () => undefined);
    },
    remove(id: string) {
      store.set((prev) => prev.filter((x) => x.id !== id));
      persist();
      const sb = getSupabase();
      if (sb && userId) void sb.from(opts.table).delete().eq('id', id).eq('user_id', userId).then(() => undefined, () => undefined);
    },
    clear() {
      store.set([]);
      persist();
      const sb = getSupabase();
      if (sb && userId) void sb.from(opts.table).delete().eq('user_id', userId).then(() => undefined, () => undefined);
    },
    /** hapus cache lokal saja (untuk reset identitas). */
    wipeLocal() { store.set([]); persist(); hydrated = false; },
  };
}
