export type Profile = {
  id: string;
  username: string;
  display_name: string;
  avatar_url: string | null;
  online: boolean;
  last_seen: string;
  created_at: string;
};

export type ChatMessage = {
  id: string;
  user_id: string;
  username: string;
  content: string;
  created_at: string;
  updated_at: string;
  /** hanya klien: status optimistic */
  _state?: 'sending' | 'failed';
};

export type SenderStatus = 'active' | 'inactive' | 'disabled';

export type Sender = {
  id: string;
  name: string;
  sender_code: string;
  avatar_url: string | null;
  status: SenderStatus;
  note: string | null;
  created_at: string;
  updated_at: string;
  last_activity: string;
  owner_id?: string;
};

export type NotifKind = 'chat' | 'system' | 'security' | 'sender';

export type NotificationItem = {
  id: string;
  user_id?: string;
  kind: NotifKind;
  title: string;
  body: string | null;
  read: boolean;
  created_at: string;
};

export type ActivityItem = {
  id: string;
  user_id?: string;
  kind: string;
  detail: string;
  meta?: Record<string, unknown> | null;
  created_at: string;
};

export type RtStatus = 'connecting' | 'connected' | 'disconnected';
export type CloudState = 'idle' | 'connecting' | 'ready' | 'error' | 'unconfigured';
