import { createStore } from './store';
import { lsGetJson, lsSetJson } from './storage';

export type Accent = 'violet' | 'cyan' | 'green';
export type Quality = 'low' | 'medium' | 'high';
export type AnimSpeed = 'slow' | 'normal' | 'fast';

export type Settings = {
  accent: Accent;
  effects: boolean;      // scanlines + glitch
  animations: boolean;
  animSpeed: AnimSpeed;
  particles: boolean;
  glow: boolean;
  quality: Quality;
  notifyChat: boolean;
  notifySystem: boolean;
};

export const DEFAULT_SETTINGS: Settings = {
  accent: 'violet', effects: true, animations: true, animSpeed: 'normal', particles: true, glow: true,
  quality: 'medium', notifyChat: true, notifySystem: true,
};

const KEY = 'settings.v1';
const isObj = (v: unknown) => !!v && typeof v === 'object';

export const settingsStore = createStore<Settings>(DEFAULT_SETTINGS);
let loaded = false;

export function loadSettings(): Settings {
  if (loaded) return settingsStore.get();
  loaded = true;
  const saved = lsGetJson<Partial<Settings>>(KEY, {}, isObj);
  const reduce = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const merged: Settings = { ...DEFAULT_SETTINGS, ...(reduce ? { animations: false, particles: false } : {}), ...saved };
  settingsStore.set(merged);
  applySettings(merged);
  return merged;
}

export function applySettings(s: Settings) {
  if (typeof document === 'undefined') return;
  const d = document.documentElement.dataset;
  d.accent = s.accent;
  d.fx = s.effects ? 'on' : 'off';
  d.anim = s.animations ? s.animSpeed : 'off';
  d.glow = s.glow ? 'on' : 'off';
  d.quality = s.quality;
}

export function updateSettings(patch: Partial<Settings>) {
  const next = { ...settingsStore.get(), ...patch };
  settingsStore.set(next);
  lsSetJson(KEY, next);
  applySettings(next);
}
export function resetSettings() { updateSettings({ ...DEFAULT_SETTINGS }); }
