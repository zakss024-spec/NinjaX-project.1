/** Moderasi dasar sisi klien (server tetap membatasi panjang, rate limit, dan spoofing lewat trigger SQL). */
const BANNED = ['anjing', 'bangsat', 'kontol', 'memek', 'fuck', 'shit', 'bitch', 'asshole'];

export const MAX_MESSAGE = 500;

export function maskBanned(text: string): { text: string; flagged: boolean } {
  let flagged = false;
  let out = text;
  for (const w of BANNED) {
    const re = new RegExp(w.split('').join('[\\W_]*'), 'gi');
    out = out.replace(re, (m) => { flagged = true; return '*'.repeat(m.length); });
  }
  return { text: out, flagged };
}

export type Validation = { ok: true; value: string; flagged: boolean } | { ok: false; error: string };

export function validateMessage(raw: string): Validation {
  // eslint-disable-next-line no-control-regex
  const s = raw.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F‮]/g, '').trim();
  if (!s) return { ok: false, error: 'Pesan kosong.' };
  if (s.length > MAX_MESSAGE) return { ok: false, error: `Maksimal ${MAX_MESSAGE} karakter.` };
  if (/(.)\1{29,}/.test(s)) return { ok: false, error: 'Pesan terdeteksi spam (karakter berulang).' };
  const m = maskBanned(s);
  return { ok: true, value: m.text, flagged: m.flagged };
}

/** Rate limiter geser: max `limit` aksi per `windowMs`, jeda minimal `minGap`. */
export function createRateLimiter(limit = 5, windowMs = 10000, minGap = 700) {
  let stamps: number[] = [];
  return {
    check(): { ok: true } | { ok: false; waitMs: number } {
      const now = Date.now();
      stamps = stamps.filter((t) => now - t < windowMs);
      const last = stamps[stamps.length - 1];
      if (last && now - last < minGap) return { ok: false, waitMs: minGap - (now - last) };
      if (stamps.length >= limit) return { ok: false, waitMs: windowMs - (now - stamps[0]) };
      stamps.push(now);
      return { ok: true };
    },
  };
}
