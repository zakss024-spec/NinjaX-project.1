export type NavItem = { href: string; label: string; icon: string; match?: string[] };

export const MAIN_NAV: NavItem[] = [
  { href: '/dashboard', label: 'HOME', icon: 'home' },
  { href: '/chat', label: 'CHAT', icon: 'chat' },
  { href: '/tools', label: 'TOOLS', icon: 'tools', match: ['/tools', '/sender'] },
  { href: '/labs', label: 'LABS', icon: 'labs', match: ['/labs'] },
  { href: '/activity', label: 'ACTIVITY', icon: 'activity', match: ['/activity', '/history'] },
  { href: '/settings', label: 'SETTINGS', icon: 'settings' },
];

export const MORE_NAV: NavItem[] = [
  { href: '/sender', label: 'MANAGE SENDER', icon: 'sender' },
  { href: '/notifications', label: 'NOTIFICATIONS', icon: 'bell' },
  { href: '/statistics', label: 'STATISTICS', icon: 'stats' },
  { href: '/security', label: 'SECURITY CENTER', icon: 'shield' },
  { href: '/history', label: 'HISTORY', icon: 'history' },
];

export const LAB_ITEMS = [
  { href: '/labs/bug', label: 'BUG LAB', icon: 'bug', desc: 'Simulasi bug UI/pesan/koneksi pada target virtual.' },
  { href: '/labs/bug-group', label: 'BUG GROUP', icon: 'group', desc: 'Pemindaian simulasi pada grup lokal fiktif.' },
  { href: '/labs/ban-group', label: 'BAN GROUP', icon: 'ban', desc: 'Laboratorium moderasi — tanpa aksi ke platform.' },
  { href: '/labs/hack', label: 'HACK LAB', icon: 'hack', desc: 'Scanner keamanan simulasi pada target dummy.' },
  { href: '/labs/osint', label: 'OSINT LAB', icon: 'osint', desc: 'Analisis data dummy/internal — hasil fiktif.' },
  { href: '/labs/network', label: 'NETWORK LAB', icon: 'network', desc: 'Visualisasi node, paket, dan latency (simulasi).' },
  { href: '/labs/report', label: 'REPORT LAB', icon: 'report', desc: 'Generator laporan keamanan lokal.' },
  { href: '/labs/exploit', label: 'EXPLOIT LAB', icon: 'exploit', desc: 'Simulasi edukatif: analisis & mitigasi kerentanan.' },
];

export const TOOL_ITEMS = [
  { href: '/tools/terminal', label: 'TERMINAL', icon: 'terminal', desc: 'Terminal internal dengan perintah lokal.' },
  { href: '/labs/osint', label: 'OSINT LAB', icon: 'osint', desc: 'Laboratorium OSINT data dummy.' },
  { href: '/labs/network', label: 'NETWORK LAB', icon: 'network', desc: 'Peta jaringan & traffic simulasi.' },
  { href: '/sender', label: 'SENDER MANAGER', icon: 'sender', desc: 'Kelola sender private & global.' },
  { href: '/tools/image-test', label: 'IMAGE TEST', icon: 'image', desc: 'Uji pemuatan semua aset gambar.' },
  { href: '/tools/performance', label: 'PERFORMANCE', icon: 'perf', desc: 'FPS, memori, dan status realtime.' },
  { href: '/tools/system', label: 'SYSTEM INFO', icon: 'info', desc: 'Informasi perangkat, sesi, dan versi.' },
];

export function labelFor(path: string): string {
  const all = [...MAIN_NAV, ...MORE_NAV, ...LAB_ITEMS, ...TOOL_ITEMS];
  const exact = all.find((n) => n.href === path);
  return exact ? exact.label : path.replace(/^\//, '').toUpperCase() || 'HOME';
}
