export type AssetDef = { id: string; label: string; group: string; path: string };

/** Sumber tunggal path aset. Semua path relatif ke /public (huruf kecil, tanpa path absolut OS). */
export const ASSETS: AssetDef[] = [
  { id: 'blackhole', label: 'Black Hole', group: 'BLACK HOLE', path: '/assets/images/blackhole.webp' },
  { id: 'ninja', label: 'Ninja', group: 'NINJA', path: '/assets/images/ninja.webp' },
  { id: 'background', label: 'Cosmic Background', group: 'BACKGROUND', path: '/assets/images/background.webp' },
  { id: 'fallback', label: 'Fallback', group: 'BACKGROUND', path: '/assets/images/fallback.webp' },
  { id: 'grid', label: 'Cyber Grid', group: 'TEXTURES', path: '/assets/effects/grid.svg' },
  { id: 'noise', label: 'Noise Texture', group: 'TEXTURES', path: '/assets/effects/noise.svg' },
  { id: 'favicon', label: 'Favicon', group: 'ICONS', path: '/assets/icons/favicon.svg' },
  { id: 'icon192', label: 'App Icon 192', group: 'ICONS', path: '/assets/icons/icon-192.png' },
  ...[1, 2, 3, 4, 5, 6].map((n) => ({ id: `avatar${n}`, label: `Avatar ${n}`, group: 'AVATARS', path: `/assets/avatars/a${n}.svg` })),
];

export const AVATARS = [1, 2, 3, 4, 5, 6].map((n) => `/assets/avatars/a${n}.svg`);
export const FALLBACK_IMG = '/assets/images/fallback.webp';

export type ProbeResult = { id: string; label: string; group: string; path: string; ok: boolean; w: number; h: number; ms: number; error?: string };

export function probe(a: AssetDef, bust = false): Promise<ProbeResult> {
  return new Promise((resolve) => {
    const t0 = performance.now();
    const img = new Image();
    const done = (ok: boolean, error?: string) => {
      if (!ok) console.warn('[NinjaX] image failed:', a.path);
      resolve({ ...a, ok, w: img.naturalWidth, h: img.naturalHeight, ms: Math.round(performance.now() - t0), error });
    };
    img.onload = () => done(img.naturalWidth > 0, img.naturalWidth > 0 ? undefined : 'empty image');
    img.onerror = () => done(false, 'failed to load');
    setTimeout(() => done(false, 'timeout'), 8000);
    img.src = bust ? `${a.path}?r=${Date.now()}` : a.path;
  });
}
export const probeAll = (bust = false) => Promise.all(ASSETS.map((a) => probe(a, bust)));
