import { createClient, type SupabaseClient } from '@supabase/supabase-js';

// Nilai env (Vercel / .env.local) diutamakan; jika kosong dipakai nilai cadangan di bawah.
// Publishable key memang publik by design (dilindungi RLS). JANGAN pernah taruh secret/service-role key di sini.
const FALLBACK_URL = 'https://umzgmozuiigugboughlp.supabase.co';
const FALLBACK_KEY = 'sb_publishable_NRVJh861SQzMtKwYwg3-5g_PE-W8WMr';
const URL = process.env.NEXT_PUBLIC_SUPABASE_URL || FALLBACK_URL;
const KEY = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || FALLBACK_KEY;

export const isSupabaseConfigured = Boolean(URL && KEY);

let client: SupabaseClient | null = null;

/** Singleton klien browser. Hanya memakai publishable (anon) key — tidak ada secret key di frontend. */
export function getSupabase(): SupabaseClient | null {
  if (!isSupabaseConfigured) return null;
  if (typeof window === 'undefined') return null;
  if (!client) {
    client = createClient(URL as string, KEY as string, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storageKey: 'ninjax-auth' },
      realtime: { params: { eventsPerSecond: 10 } },
    });
  }
  return client;
}
