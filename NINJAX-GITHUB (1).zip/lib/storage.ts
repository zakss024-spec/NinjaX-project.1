/** localStorage aman: try/catch + deteksi data rusak. Tidak pernah menyimpan password. */
const PREFIX = 'ninjax.';

export function lsGet(key: string): string | null {
  try { return typeof window === 'undefined' ? null : window.localStorage.getItem(PREFIX + key); } catch { return null; }
}
export function lsSet(key: string, value: string): boolean {
  try { window.localStorage.setItem(PREFIX + key, value); return true; } catch { return false; }
}
export function lsRemove(key: string) { try { window.localStorage.removeItem(PREFIX + key); } catch { /* abaikan */ } }

/** Baca JSON; bila rusak -> kembalikan fallback + hapus key + laporkan lewat callback. */
export function lsGetJson<T>(key: string, fallback: T, validate?: (v: unknown) => boolean, onCorrupt?: () => void): T {
  const raw = lsGet(key);
  if (raw === null) return fallback;
  try {
    const v = JSON.parse(raw);
    if (validate && !validate(v)) throw new Error('invalid');
    return v as T;
  } catch {
    lsRemove(key);
    onCorrupt?.();
    return fallback;
  }
}
export function lsSetJson(key: string, v: unknown): boolean {
  try { return lsSet(key, JSON.stringify(v)); } catch { return false; }
}

export function ssGet(key: string): string | null {
  try { return typeof window === 'undefined' ? null : window.sessionStorage.getItem(PREFIX + key); } catch { return null; }
}
export function ssSet(key: string, v: string) { try { window.sessionStorage.setItem(PREFIX + key, v); } catch { /* abaikan */ } }
export function ssRemove(key: string) { try { window.sessionStorage.removeItem(PREFIX + key); } catch { /* abaikan */ } }

export function lsKeys(): string[] {
  try { return Object.keys(window.localStorage).filter((k) => k.startsWith(PREFIX)); } catch { return []; }
}
