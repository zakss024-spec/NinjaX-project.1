import { lsGetJson, lsSetJson, ssGet, ssRemove, ssSet } from './storage';

/**
 * LOGIN DEMO (hanya untuk alur UI). Kredensial ini ada di bundle klien sehingga BUKAN keamanan sungguhan.
 * Keamanan data ditegakkan oleh Supabase Auth + Row Level Security, bukan oleh gerbang UI ini.
 */
const DEMO_USER = 'Ninja';
const DEMO_PASS = 'Ninja123';

export function verifyCredentials(user: string, pass: string): boolean {
  return user === DEMO_USER && pass === DEMO_PASS;
}

/* ---------- gerbang alur: login -> fingerprint -> loading -> ready ---------- */
export type Gate = 'none' | 'login' | 'fingerprint' | 'ready';
const GATE_KEY = 'gate';

export function getGate(): Gate {
  const v = ssGet(GATE_KEY);
  return v === 'login' || v === 'fingerprint' || v === 'ready' ? v : 'none';
}
export function setGate(g: Gate) { if (g === 'none') ssRemove(GATE_KEY); else ssSet(GATE_KEY, g); }

export function gateRoute(g: Gate): string {
  switch (g) {
    case 'login': return '/fingerprint';
    case 'fingerprint': return '/loading';
    case 'ready': return '/dashboard';
    default: return '/login';
  }
}

/* ---------- pembatasan percobaan login: 5 gagal => kunci 30 detik ---------- */
type Lock = { fails: number; until: number };
const LOCK_KEY = 'loginlock';
const valid = (v: unknown) => !!v && typeof (v as Lock).fails === 'number' && typeof (v as Lock).until === 'number';

export function getLock(): Lock { return lsGetJson<Lock>(LOCK_KEY, { fails: 0, until: 0 }, valid); }
export function lockRemainingMs(): number { return Math.max(0, getLock().until - Date.now()); }
export function registerFail(): Lock {
  const l = getLock();
  const fails = l.fails + 1;
  const next: Lock = fails >= 5 ? { fails: 0, until: Date.now() + 30000 } : { fails, until: l.until };
  lsSetJson(LOCK_KEY, next);
  return next;
}
export function resetFails() { lsSetJson(LOCK_KEY, { fails: 0, until: 0 }); }
