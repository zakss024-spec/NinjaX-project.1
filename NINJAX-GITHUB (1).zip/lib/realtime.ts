import type { RealtimeChannel, RealtimeChannelOptions } from '@supabase/supabase-js';
import { getSupabase } from './supabase';
import type { RtStatus } from './types';

type Opts = {
  name: string;
  config?: RealtimeChannelOptions['config'];
  /** Pasang listener (.on) pada channel baru. Dipanggil ulang tiap reconnect. */
  build: (ch: RealtimeChannel) => void;
  onStatus: (s: RtStatus) => void;
  /** Dipanggil tiap kali SUBSCRIBED (termasuk setelah reconnect) — untuk resync data / track presence. */
  onConnected?: (ch: RealtimeChannel) => void;
};

export type Managed = { destroy: () => void; reconnect: () => void };

/**
 * Channel Supabase dengan reconnect otomatis (exponential backoff 1s..15s),
 * respons event online/offline, dan cleanup penuh saat destroy().
 */
export function managedChannel(o: Opts): Managed {
  const sb = getSupabase();
  if (!sb) { o.onStatus('disconnected'); return { destroy() {}, reconnect() {} }; }
  const supabase = sb;
  let ch: RealtimeChannel | null = null;
  let dead = false;
  let attempt = 0;
  let gen = 0;
  let timer: ReturnType<typeof setTimeout> | null = null;

  function clearTimer() { if (timer) { clearTimeout(timer); timer = null; } }

  function schedule() {
    if (dead || timer) return;
    const delay = Math.min(15000, 1000 * Math.pow(2, attempt++));
    timer = setTimeout(() => { timer = null; connect(); }, delay);
  }

  function connect() {
    if (dead) return;
    const my = ++gen;
    o.onStatus('connecting');
    if (ch) { const old = ch; ch = null; void supabase.removeChannel(old); }
    const next = supabase.channel(`${o.name}:${Date.now().toString(36)}`, { config: o.config });
    ch = next;
    o.build(next);
    next.subscribe((status) => {
      if (dead || my !== gen) return;
      if (status === 'SUBSCRIBED') { attempt = 0; o.onStatus('connected'); o.onConnected?.(next); }
      else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') { o.onStatus('disconnected'); schedule(); }
    });
  }

  const onOnline = () => { if (dead) return; attempt = 0; clearTimer(); connect(); };
  const onOffline = () => { if (!dead) o.onStatus('disconnected'); };
  window.addEventListener('online', onOnline);
  window.addEventListener('offline', onOffline);
  connect();

  return {
    reconnect: onOnline,
    destroy() {
      dead = true;
      clearTimer();
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
      if (ch) { const old = ch; ch = null; void supabase.removeChannel(old); }
    },
  };
}
