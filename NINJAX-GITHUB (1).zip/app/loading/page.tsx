'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Backdrop, Particles } from '@/components/Visual/Particles';
import { BlackHole, NinjaSilhouette } from '@/components/Visual/BlackHole';
import { Button } from '@/components/UI/Button';
import { Progress } from '@/components/UI/Bits';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useSettings } from '@/hooks/useSettings';

const STEPS: Array<[number, string]> = [[0, 'INITIALIZING…'], [18, 'LOADING MODULES…'], [42, 'SYNCING REALTIME…'], [72, 'RENDERING INTERFACE…'], [93, 'READY']];

export default function LoadingPage() {
  const router = useRouter();
  const { hydrated, gate, advance, cloud } = useAuth();
  useSettings();
  const [pct, setPct] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const done = useRef(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => { if (hydrated && (gate === 'none' || gate === 'login')) router.replace(gate === 'login' ? '/fingerprint' : '/login'); }, [hydrated, gate, router]);

  const finish = useCallback(() => {
    if (done.current) return;
    done.current = true;
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    setPct(100); setLeaving(true);
    advance('ready');
    setTimeout(() => router.replace('/dashboard'), 450);
  }, [advance, router]);

  useEffect(() => {
    if (!hydrated || gate === 'none' || gate === 'login') return;
    const t0 = Date.now(), total = 4200;
    timer.current = setInterval(() => {
      const p = Math.min(100, Math.round(((Date.now() - t0) / total) * 100));
      setPct(p);
      if (p >= 100) finish();
    }, 70);
    // watchdog: apapun yang terjadi, masuk dashboard maksimal 9 detik
    const wd = setTimeout(finish, 9000);
    return () => { if (timer.current) clearInterval(timer.current); clearTimeout(wd); };
  }, [hydrated, gate, finish]);

  const status = [...STEPS].reverse().find((s) => pct >= s[0])?.[1] ?? STEPS[0][1];
  return (
    <div className={`nx-stage${leaving ? ' is-leaving' : ''}`}>
      <Backdrop /><Particles force />
      <Button className="nx-skip" size="sm" variant="ghost" onClick={finish}>[ SKIP INTRO ]</Button>
      <div className="nx-stage__inner">
        <BlackHole size={300} pulse>
          <div className="nx-flyer"><NinjaSilhouette size={96} /></div>
        </BlackHole>
        <i className="nx-orbit nx-orbit--1" aria-hidden="true" />
        <h1 className="nx-title nx-glitch" data-text="NINJA LOADING">NINJA LOADING</h1>
        <p className="nx-sub">ENTERING THE VOID</p>
        <div className="nx-loadbox">
          <div className="nx-loadbox__row"><span role="status" aria-live="polite">{status}</span><b>{pct}%</b></div>
          <Progress value={pct} label="loading" />
          <small className="nx-loadbox__cloud">{cloud === 'ready' ? 'CLOUD LINK ESTABLISHED' : cloud === 'error' ? 'CLOUD OFFLINE — continuing' : cloud === 'unconfigured' ? 'CLOUD NOT CONFIGURED' : 'LINKING CLOUD…'}</small>
        </div>
      </div>
    </div>
  );
}
