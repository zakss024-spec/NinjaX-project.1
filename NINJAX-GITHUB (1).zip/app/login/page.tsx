'use client';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { Backdrop, Particles } from '@/components/Visual/Particles';
import { BlackHole, NinjaSilhouette } from '@/components/Visual/BlackHole';
import { Button } from '@/components/UI/Button';
import { Icon } from '@/components/UI/Icon';
import { useAuth } from '@/components/Providers/AuthProvider';
import { lockRemainingMs, registerFail, resetFails, verifyCredentials } from '@/lib/auth';
import { logActivity } from '@/services/activity';
import { useSettings } from '@/hooks/useSettings';

export default function LoginPage() {
  const router = useRouter();
  const { hydrated, gate, advance, connect, cloud } = useAuth();
  useSettings();
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [lock, setLock] = useState(0);
  const [shake, setShake] = useState(0);
  const userRef = useRef<HTMLInputElement>(null);

  useEffect(() => { if (hydrated && gate === 'ready') router.replace('/dashboard'); else if (hydrated && gate === 'login') router.replace('/fingerprint'); }, [hydrated, gate, router]);

  useEffect(() => { setLock(lockRemainingMs()); }, []);
  useEffect(() => {
    if (lock <= 0) return;
    const t = setInterval(() => { const r = lockRemainingMs(); setLock(r); if (r <= 0) { clearInterval(t); setError(null); } }, 250);
    return () => clearInterval(t);
  }, [lock > 0]); // eslint-disable-line react-hooks/exhaustive-deps

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (lockRemainingMs() > 0) { setLock(lockRemainingMs()); return; }
    if (!user.trim() || !pass) { setError('Username dan password wajib diisi.'); setShake((s) => s + 1); return; }
    setBusy(true); setError(null);
    await new Promise((r) => setTimeout(r, 650)); // efek verifikasi
    if (verifyCredentials(user.trim(), pass)) {
      resetFails();
      setPass('');
      advance('login');
      logActivity('login', 'Login success');
      void connect();
      router.push('/fingerprint');
    } else {
      const l = registerFail();
      setPass(''); setShake((s) => s + 1); setBusy(false);
      if (l.until > Date.now()) { setLock(lockRemainingMs()); setError('Terlalu banyak percobaan. Akses dikunci sementara.'); }
      else setError(`ACCESS DENIED — kredensial salah (${5 - l.fails} percobaan tersisa).`);
    }
  };

  const locked = lock > 0;
  return (
    <div className="nx-stage">
      <Backdrop /><Particles />
      <div className="nx-stage__inner">
        <BlackHole size={150} pulse><NinjaSilhouette size={60} /></BlackHole>
        <h1 className="nx-title nx-glitch" data-text="NINJAX">NINJAX</h1>
        <p className="nx-sub">SECURE ACCESS PORTAL</p>
        <form className={`nx-panel nx-login${shake ? ' is-shake' : ''}`} key={shake} onSubmit={onSubmit} noValidate autoComplete="off">
          <i className="nx-br nx-br--tl" /><i className="nx-br nx-br--br" />
          <label className="nx-field">
            <span className="nx-field__label">USERNAME</span>
            <input ref={userRef} className="nx-input" value={user} onChange={(e) => setUser(e.target.value)} name="ninjax-user" type="text" placeholder="username" autoComplete="off" autoCapitalize="none" autoCorrect="off" spellCheck={false} maxLength={32} disabled={busy || locked} aria-invalid={!!error} />
          </label>
          <label className="nx-field">
            <span className="nx-field__label">PASSWORD</span>
            <span className="nx-input-wrap">
              <input className="nx-input" value={pass} onChange={(e) => setPass(e.target.value)} name="ninjax-pass" type={show ? 'text' : 'password'} placeholder="••••••••" autoComplete="new-password" autoCapitalize="none" autoCorrect="off" spellCheck={false} maxLength={64} disabled={busy || locked} aria-invalid={!!error} />
              <button type="button" className="nx-input-eye" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show}><Icon name="lock" size={18} /></button>
            </span>
          </label>
          <div className="nx-formmsg" role="alert" aria-live="assertive">
            {locked ? <span className="is-bad">LOCKED — coba lagi dalam {Math.ceil(lock / 1000)} detik</span> : error ? <span className="is-bad">{error}</span> : null}
          </div>
          <Button type="submit" block loading={busy} disabled={locked}>[ ACCESS NINJAX ]</Button>
          <p className="nx-note">Login demo untuk alur UI. Data dilindungi oleh Supabase Auth &amp; RLS.{cloud === 'unconfigured' ? ' (Supabase belum dikonfigurasi)' : ''}</p>
        </form>
      </div>
    </div>
  );
}

