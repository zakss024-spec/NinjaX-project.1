import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="nx-boot">
      <b className="nx-404">404</b>
      <small>ROUTE NOT FOUND</small>
      <Link href="/dashboard" className="nx-btn nx-btn--primary"><span className="nx-btn__label">BACK TO HOME</span></Link>
    </div>
  );
}
