'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Backdrop, Particles } from '@/components/Visual/Particles';
import { Button } from '@/components/UI/Button';
import { useAuth } from '@/components/Providers/AuthProvider';
import { logActivity } from '@/services/activity';
import { useSettings } from '@/hooks/useSettings';

const PRINT = (
  <>
    <path d="M22 34A36 36 0 0 1 78 34" /><path d="M12 80V54A38 38 0 0 1 88 54v18" /><path d="M21 92V56A29 29 0 0 1 79 56v8M79 78v10" />
    <path d="M30 100V58A20 20 0 0 1 70 58v36" /><path d="M39 106V60A11 11 0 0 1 61 60v20M61 92v12" /><path d="M48 112V62a2 2 0 0 1 4 0v14" />
  </>
);

type Phase = 'idle' | 'scanning' | 'granted';

export default function FingerprintPage() {
  const router = useRouter();
  const { hydrated, gate, advance } = useAuth();
  useSettings();
  const [phase, setPhase] = useState<Phase>('idle');
  const [pct, setPct] = useState(0);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const goTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { if (hydrated && gate === 'none') router.replace('/login'); }, [hydrated, gate, router]);
  useEffect(() => () => { if (timer.current) clearInterval(timer.current); if (goTimer.current) clearTimeout(goTimer.current); }, []);

  const grant = useCallback(() => {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    setPct(100); setPhase('granted');
    advance(gate === 'ready' ? 'ready' : 'fingerprint');
    logActivity('fingerprint', 'Fingerprint verified (simulation)');
    goTimer.current = setTimeout(() => router.replace('/loading'), 900);
  }, [advance, gate, router]);

  const start = useCallback(() => {
    if (phase !== 'idle') return;
    setPhase('scanning'); setPct(0);
    const t0 = Date.now(), total = 2800;
    timer.current = setInterval(() => {
      const p = Math.min(100, Math.round(((Date.now() - t0) / total) * 100));
      setPct(p);
      if (p >= 100) grant();
    }, 60);
  }, [phase, grant]);

  const status = phase === 'idle' ? 'TAP TO SCAN' : phase === 'granted' ? 'ACCESS GRANTED' : pct < 55 ? 'SCANNING…' : 'VERIFYING…';
  return (
    <div className="nx-stage">
      <Backdrop /><Particles />
      <div className="nx-stage__inner">
        <p className="nx-sub">BIOMETRIC ACCESS</p>
        <h1 className="nx-title">FINGERPRINT SCAN</h1>
        <button type="button" className={`nx-fp is-${phase}`} onClick={start} aria-label="Tap to start fingerprint scan (simulation)" style={{ ['--p' as string]: `${pct}%` }}>
          <i className="nx-fp__ripple" />
          <svg className="nx-fp__svg nx-fp__base" viewBox="0 0 100 120" fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round">{PRINT}</svg>
          <svg className="nx-fp__svg nx-fp__fill" viewBox="0 0 100 120" fill="none" stroke="currentColor" strokeWidth="3.4" strokeLinecap="round">{PRINT}</svg>
          <i className="nx-fp__line" />
        </button>
        <div className="nx-fp__pct" aria-hidden="true">{pct}%</div>
        <div className={`nx-fp__status${phase === 'granted' ? ' is-ok' : ''}`} role="status" aria-live="polite">{status}</div>
        <div className="nx-steps" aria-hidden="true">{[25, 50, 75, 100].map((s) => <span key={s} className={pct >= s ? 'is-on' : ''}>{s}%</span>)}</div>
        <p className="nx-note">Simulasi UI lokal — bukan akses sensor biometrik perangkat.</p>
        <div className="nx-row nx-row--center">
          <Button size="sm" variant="ghost" onClick={() => { advance('none'); router.replace('/login'); }} disabled={phase === 'granted'}>BACK</Button>
          <Button size="sm" variant="ghost" onClick={grant} disabled={phase === 'granted'}>SKIP</Button>
        </div>
      </div>
    </div>
  );
}
