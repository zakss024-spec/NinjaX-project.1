'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/components/Providers/AuthProvider';
import { gateRoute } from '@/lib/auth';

export default function Index() {
  const { hydrated, gate } = useAuth();
  const router = useRouter();
  useEffect(() => { if (hydrated) router.replace(gateRoute(gate)); }, [hydrated, gate, router]);
  return <div className="nx-boot" role="status"><div className="nx-boot__ring" /><small>BOOTING…</small></div>;
}
