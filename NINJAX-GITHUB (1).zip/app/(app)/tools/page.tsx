'use client';
import Link from 'next/link';
import { PageHeader } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { TOOL_ITEMS } from '@/lib/nav';

export default function ToolsPage() {
  return (
    <div className="nx-page">
      <PageHeader code="UTILITIES" title="TOOLS" desc="Terminal, laboratorium, manajer sender, dan alat diagnostik aplikasi." />
      <div className="nx-cardgrid">
        {TOOL_ITEMS.map((l, i) => (
          <Link key={l.href + l.label} href={l.href} className="nx-hubcard" style={{ animationDelay: `${i * 50}ms` }}>
            <span className="nx-hubcard__ico"><Icon name={l.icon} size={26} /></span>
            <b>{l.label}</b><p>{l.desc}</p><em>OPEN →</em>
          </Link>
        ))}
      </div>
    </div>
  );
}
