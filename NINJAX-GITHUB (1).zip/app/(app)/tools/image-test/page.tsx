'use client';
import { useCallback, useEffect, useState } from 'react';
import { Button } from '@/components/UI/Button';
import { Chip, PageHeader, Skeleton } from '@/components/UI/Bits';
import { Panel } from '@/components/UI/Panel';
import { SafeImage } from '@/components/UI/SafeImage';
import { probeAll, type ProbeResult } from '@/lib/images';
import { logActivity } from '@/services/activity';

export default function ImageTestPage() {
  const [res, setRes] = useState<ProbeResult[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [bust, setBust] = useState(0);

  const run = useCallback(async (reload = false) => {
    setBusy(true);
    const r = await probeAll(reload);
    setRes(r); setBusy(false);
    if (reload) setBust(Date.now());
    const bad = r.filter((x) => !x.ok).length;
    logActivity('module', `Image test: ${r.length - bad}/${r.length} loaded`);
  }, []);
  useEffect(() => { void run(false); }, [run]);

  const groups = res ? Array.from(new Set(res.map((r) => r.group))) : [];
  const failed = res?.filter((r) => !r.ok).length ?? 0;
  return (
    <div className="nx-page">
      <PageHeader code="DIAGNOSTIC" title="IMAGE TEST" desc="Menguji pemuatan seluruh aset gambar lokal. Path yang gagal ditampilkan di sini." aside={<Chip tone={!res ? 'warn' : failed ? 'bad' : 'ok'} dot>{!res ? 'TESTING' : failed ? `${failed} FAILED` : 'ALL LOADED'}</Chip>} />
      <Button block onClick={() => void run(true)} loading={busy}>RELOAD ASSETS</Button>
      {!res ? <Skeleton lines={6} /> : groups.map((g) => {
        const rows = res.filter((r) => r.group === g);
        const ok = rows.every((r) => r.ok);
        return (
          <Panel key={g} title={g} aside={<Chip tone={ok ? 'ok' : 'bad'}>{ok ? 'LOADED' : 'FAILED'}</Chip>}>
            <ul className="nx-imgrows">
              {rows.map((r) => (
                <li key={r.id} className={r.ok ? 'is-ok' : 'is-bad'}>
                  <span className="nx-imgrows__th"><SafeImage src={bust ? `${r.path}?r=${bust}` : r.path} width={44} height={44} /></span>
                  <div><b>{r.label}</b>{r.ok ? <small>{r.w}×{r.h} · {r.ms} ms</small> : <small className="is-bad">PATH: {r.path} ({r.error})</small>}</div>
                  <Chip tone={r.ok ? 'ok' : 'bad'}>{r.ok ? 'LOADED' : 'FAILED'}</Chip>
                </li>
              ))}
            </ul>
          </Panel>
        );
      })}
      <Panel title="FALLBACK DEMO" aside={<Chip tone="cy">SAFE IMAGE</Chip>}>
        <div className="nx-row nx-row--gap">
          <SafeImage src="/assets/images/does-not-exist.webp" width={64} height={64} alt="missing asset falls back" />
          <p className="nx-note">Gambar di kiri sengaja menunjuk file yang tidak ada — komponen otomatis memakai <code>fallback.webp</code>, lalu placeholder CSS jika itu pun gagal.</p>
        </div>
      </Panel>
    </div>
  );
}
