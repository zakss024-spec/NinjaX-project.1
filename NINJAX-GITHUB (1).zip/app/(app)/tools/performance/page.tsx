'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { Chip, PageHeader, Seg } from '@/components/UI/Bits';
import { Gauge, Sparkline } from '@/components/UI/Charts';
import { Panel } from '@/components/UI/Panel';
import { useFps } from '@/hooks/useFps';
import { useSettings } from '@/hooks/useSettings';
import { getSupabase } from '@/lib/supabase';
import type { Quality } from '@/lib/settings';

type Mem = { used: number; limit: number } | null;

export default function PerformancePage() {
  const fps = useFps(true);
  const [series, setSeries] = useState<number[]>(Array(30).fill(0));
  const [mem, setMem] = useState<Mem>(null);
  const [chans, setChans] = useState(0);
  const [s, update] = useSettings();
  const { cloud } = useAuth();
  const { status, presenceStatus } = useChat();

  useEffect(() => { setSeries((v) => [...v.slice(1), fps]); }, [fps]);
  useEffect(() => {
    const t = setInterval(() => {
      const m = (performance as unknown as { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } }).memory;
      setMem(m ? { used: Math.round(m.usedJSHeapSize / 1048576), limit: Math.round(m.jsHeapSizeLimit / 1048576) } : null);
      setChans(getSupabase()?.getChannels().length ?? 0);
    }, 1500);
    return () => clearInterval(t);
  }, []);

  const nav = (typeof performance !== 'undefined' && performance.getEntriesByType('navigation')[0]) as PerformanceNavigationTiming | undefined;
  return (
    <div className="nx-page">
      <PageHeader code="DIAGNOSTIC" title="PERFORMANCE" desc="FPS nyata, memori, dan status koneksi realtime aplikasi." />
      <div className="nx-grid2">
        <Panel title="FRAME RATE"><div className="nx-row nx-row--gap"><Gauge value={Math.min(100, (fps / 60) * 100)} label="fps" tone={fps >= 50 ? 'ok' : fps >= 30 ? 'warn' : 'bad'} /><div><b className="nx-bignum">{fps || '--'}</b><small className="nx-dim"> FPS</small></div></div><Sparkline values={series} height={50} /></Panel>
        <Panel title="MEMORY & LOAD"><ul className="nx-kv"><li><span>JS heap</span><b>{mem ? `${mem.used} / ${mem.limit} MB` : 'n/a (browser)'}</b></li><li><span>DOM content loaded</span><b>{nav ? `${Math.round(nav.domContentLoadedEventEnd)} ms` : 'n/a'}</b></li><li><span>Page load</span><b>{nav && nav.loadEventEnd ? `${Math.round(nav.loadEventEnd)} ms` : 'n/a'}</b></li><li><span>Device memory</span><b>{(navigator as unknown as { deviceMemory?: number }).deviceMemory ? `${(navigator as unknown as { deviceMemory: number }).deviceMemory} GB` : 'n/a'}</b></li></ul></Panel>
      </div>
      <Panel title="REALTIME">
        <ul className="nx-kv"><li><span>Cloud</span><b><Chip tone={cloud === 'ready' ? 'ok' : cloud === 'connecting' ? 'warn' : 'bad'} dot>{cloud.toUpperCase()}</Chip></b></li><li><span>Messages channel</span><b><Chip tone={status === 'connected' ? 'ok' : 'warn'} dot>{status.toUpperCase()}</Chip></b></li><li><span>Presence channel</span><b><Chip tone={presenceStatus === 'connected' ? 'ok' : 'warn'} dot>{presenceStatus.toUpperCase()}</Chip></b></li><li><span>Active channels</span><b>{chans}</b></li></ul>
        <p className="nx-note">Semua channel dibersihkan otomatis saat logout / keluar dari aplikasi.</p>
      </Panel>
      <Panel title="QUICK TUNING">
        <div className="nx-field"><span className="nx-field__label">ANIMATION QUALITY</span><Seg<Quality> label="Quality" value={s.quality} onChange={(q) => update({ quality: q })} options={[{ id: 'low', label: 'LOW' }, { id: 'medium', label: 'MEDIUM' }, { id: 'high', label: 'HIGH' }]} /></div>
        <p className="nx-note">Pilih LOW bila FPS di bawah 30 pada perangkat Android lama.</p>
      </Panel>
    </div>
  );
}
