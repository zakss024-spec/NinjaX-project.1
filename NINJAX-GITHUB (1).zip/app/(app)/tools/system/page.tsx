'use client';
import { useEffect, useState } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { Chip, PageHeader } from '@/components/UI/Bits';
import { Panel } from '@/components/UI/Panel';
import { isSupabaseConfigured } from '@/lib/supabase';
import { lsKeys } from '@/lib/storage';
import { fmtDur } from '@/lib/utils';
import { APP_VERSION } from '@/lib/version';

const t0 = Date.now();

export default function SystemPage() {
  const { userId, profile, cloud, isAnonymous } = useAuth();
  const [now, setNow] = useState(0);
  const [info, setInfo] = useState<Array<[string, string]>>([]);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    const dark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
    setInfo([
      ['Platform', navigator.platform || 'n/a'], ['Language', navigator.language], ['Time zone', Intl.DateTimeFormat().resolvedOptions().timeZone],
      ['Viewport', `${window.innerWidth} × ${window.innerHeight} @${window.devicePixelRatio || 1}x`], ['Screen', `${screen.width} × ${screen.height}`],
      ['Touch points', String(navigator.maxTouchPoints || 0)], ['Cores', String(navigator.hardwareConcurrency || 'n/a')], ['Online', navigator.onLine ? 'YES' : 'NO'],
      ['Color scheme', dark ? 'dark' : 'light'], ['Reduced motion', window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 'YES' : 'NO'], ['Secure context', window.isSecureContext ? 'YES' : 'NO'],
      ['Local keys', String(lsKeys().length)],
    ]);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="nx-page">
      <PageHeader code="DIAGNOSTIC" title="SYSTEM INFO" desc="Informasi perangkat, sesi, dan versi aplikasi." />
      <Panel title="APPLICATION">
        <ul className="nx-kv"><li><span>App</span><b>NINJAX</b></li><li><span>Version</span><b>{APP_VERSION}</b></li><li><span>Mode</span><b className="is-ok">REALTIME + LOCAL SIMULATION</b></li><li><span>Uptime</span><b>{fmtDur((now || t0) - t0)}</b></li></ul>
      </Panel>
      <Panel title="SESSION" aside={<Chip tone={cloud === 'ready' ? 'ok' : 'warn'} dot>{cloud.toUpperCase()}</Chip>}>
        <ul className="nx-kv"><li><span>Supabase</span><b>{isSupabaseConfigured ? 'CONFIGURED' : 'NOT CONFIGURED'}</b></li><li><span>User ID</span><b>{userId ? `${userId.slice(0, 8)}…` : '-'}</b></li><li><span>Username</span><b>{profile ? `@${profile.username}` : '-'}</b></li><li><span>Auth type</span><b>{isAnonymous ? 'anonymous session' : 'registered'}</b></li></ul>
      </Panel>
      <Panel title="DEVICE"><ul className="nx-kv">{info.map(([k, v]) => <li key={k}><span>{k}</span><b>{v}</b></li>)}</ul></Panel>
    </div>
  );
}
