'use client';
import { TerminalView } from '@/components/Terminal/TerminalView';

export default function Page() { return <TerminalView />; }
