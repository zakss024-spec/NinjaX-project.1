'use client';
import { useMemo, useState } from 'react';
import { ActivityList } from '@/components/Dashboard/ActivityList';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { Chip, EmptyState, PageHeader, Tabs } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { Panel } from '@/components/UI/Panel';
import { fmtDateTime } from '@/lib/utils';

type T = 'chat' | 'activity' | 'scan' | 'sender' | 'security';

function ChatHistory() {
  const { messages } = useChat();
  const { userId } = useAuth();
  const [q, setQ] = useState('');
  const mine = useMemo(() => messages.filter((m) => m.user_id === userId && !m._state).reverse().filter((m) => !q.trim() || m.content.toLowerCase().includes(q.trim().toLowerCase())), [messages, userId, q]);
  return (
    <>
      <div className="nx-toolbar"><label className="nx-search"><Icon name="search" size={18} /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search my messages…" aria-label="Search chat history" maxLength={40} /></label></div>
      {mine.length === 0 ? <EmptyState icon="chat" title="NO CHAT HISTORY" text="Pesan yang Anda kirim di Global Chat akan tampil di sini." /> : (
        <ul className="nx-timeline">{mine.slice(0, 60).map((m) => <li key={m.id}><time>{fmtDateTime(m.created_at)}</time><div><Chip tone="cy">CHAT</Chip><span>{m.content}</span></div></li>)}</ul>
      )}
    </>
  );
}

export default function HistoryPage() {
  const [tab, setTab] = useState<T>('chat');
  return (
    <div className="nx-page">
      <PageHeader code="CENTER" title="HISTORY" desc="Riwayat chat, aktivitas, pemindaian, sender, dan keamanan — dengan filter dan pencarian." />
      <Tabs<T> label="History type" value={tab} onChange={setTab} tabs={[{ id: 'chat', label: 'CHAT' }, { id: 'activity', label: 'ACTIVITY' }, { id: 'scan', label: 'SCANS' }, { id: 'sender', label: 'SENDERS' }, { id: 'security', label: 'SECURITY' }]} />
      <Panel>
        {tab === 'chat' ? <ChatHistory /> : tab === 'activity' ? <ActivityList groups={['login', 'module', 'settings']} /> : tab === 'scan' ? <ActivityList groups={['scan']} title="NO SCAN HISTORY" /> : tab === 'sender' ? <ActivityList groups={['sender']} title="NO SENDER HISTORY" /> : <ActivityList groups={['security']} title="NO SECURITY EVENTS" />}
      </Panel>
    </div>
  );
}
