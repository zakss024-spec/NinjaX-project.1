'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { useGlobalSenders } from '@/components/Providers/SendersProvider';
import { Chip, ErrorState, PageHeader } from '@/components/UI/Bits';
import { BarChart, Donut, HBars } from '@/components/UI/Charts';
import { Panel } from '@/components/UI/Panel';
import { useStore } from '@/hooks/useStore';
import { activityLog } from '@/services/activity';
import { countMessages } from '@/services/messages';
import { privateStore } from '@/services/senders';

export default function StatisticsPage() {
  const { cloud } = useAuth();
  const { online, sessions, messages } = useChat();
  const { list: gs } = useGlobalSenders();
  const priv = useStore(privateStore);
  const acts = useStore(activityLog.store);
  const [total, setTotal] = useState<number | null>(null);
  const [err, setErr] = useState(false);

  const load = useCallback(() => { setErr(false); countMessages().then(setTotal).catch(() => setErr(true)); }, []);
  useEffect(() => { if (cloud === 'ready') load(); }, [cloud, load, messages.length]);

  const week = useMemo(() => {
    const d0 = new Date(); d0.setHours(0, 0, 0, 0);
    return Array.from({ length: 7 }, (_, i) => {
      const day = new Date(d0.getTime() - (6 - i) * 86400000);
      const n = acts.filter((a) => { const t = new Date(a.created_at).getTime(); return t >= day.getTime() && t < day.getTime() + 86400000; }).length;
      return { label: `${day.getDate()}/${day.getMonth() + 1}`, value: n };
    });
  }, [acts]);
  const usage = useMemo(() => {
    const m = new Map<string, number>();
    for (const a of acts) { const k = a.kind.startsWith('lab:') ? a.kind.slice(4).toUpperCase() : a.kind === 'terminal' ? 'TERMINAL' : null; if (k) m.set(k, (m.get(k) ?? 0) + 1); }
    return Array.from(m, ([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value);
  }, [acts]);
  const mix = useMemo(() => {
    const c = (f: (k: string) => boolean) => acts.filter((a) => f(a.kind)).length;
    return [
      { label: 'LABS', value: c((k) => k.startsWith('lab:')), color: 'var(--c)' }, { label: 'CHAT', value: c((k) => k === 'chat'), color: 'var(--g)' },
      { label: 'SENDER', value: c((k) => k === 'sender'), color: 'var(--p)' }, { label: 'OTHER', value: c((k) => !k.startsWith('lab:') && k !== 'chat' && k !== 'sender'), color: 'var(--warn)' },
    ];
  }, [acts]);

  const tiles = [
    { k: 'TOTAL MESSAGES', v: total ?? '…', t: 'cy' }, { k: 'ONLINE USERS', v: online.length, t: 'ok' }, { k: 'ACTIVE SESSIONS', v: sessions, t: 'ok' },
    { k: 'SENDER COUNT', v: priv.length + gs.length, t: 'p', sub: `${priv.length} private · ${gs.length} global` }, { k: 'ACTIVITY COUNT', v: acts.length, t: 'warn' }, { k: 'LAB RUNS', v: usage.reduce((a, b) => a + b.value, 0), t: 'cy' },
  ];
  return (
    <div className="nx-page">
      <PageHeader code="CENTER" title="STATISTICS" desc="Pesan, pengguna online, sesi, sender, dan penggunaan modul." aside={<Chip tone={cloud === 'ready' ? 'ok' : 'warn'} dot>{cloud === 'ready' ? 'LIVE' : 'OFFLINE'}</Chip>} />
      {err ? <ErrorState title="FAILED TO LOAD TOTALS" text="Tidak bisa membaca jumlah pesan dari database." onRetry={load} /> : null}
      <div className="nx-tiles">
        {tiles.map((t, i) => <div key={t.k} className={`nx-tile nx-tile--${t.t}`} style={{ animationDelay: `${i * 60}ms` }}><small>{t.k}</small><b>{t.v}</b>{t.sub ? <em>{t.sub}</em> : null}</div>)}
      </div>
      <Panel title="ACTIVITY · LAST 7 DAYS"><BarChart data={week} /></Panel>
      <div className="nx-grid2">
        <Panel title="ACTIVITY MIX"><div className="nx-row nx-row--gap"><Donut parts={mix} center={String(acts.length)} /><ul className="nx-legend">{mix.map((p) => <li key={p.label}><i style={{ background: p.color }} />{p.label} <b>{p.value}</b></li>)}</ul></div></Panel>
        <Panel title="MODULE USAGE">{usage.length ? <HBars data={usage.slice(0, 8)} /> : <p className="nx-dim">Belum ada modul yang dijalankan.</p>}</Panel>
      </div>
    </div>
  );
}
