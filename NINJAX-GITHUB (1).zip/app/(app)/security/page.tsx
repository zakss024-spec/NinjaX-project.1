'use client';
import { useMemo } from 'react';
import { Button } from '@/components/UI/Button';
import { Chip, PageHeader } from '@/components/UI/Bits';
import { Gauge } from '@/components/UI/Charts';
import { Icon } from '@/components/UI/Icon';
import { Panel } from '@/components/UI/Panel';
import { ActivityList } from '@/components/Dashboard/ActivityList';
import { useSecurity } from '@/hooks/useSecurity';
import { useStore } from '@/hooks/useStore';
import { activityLog } from '@/services/activity';
import { fmtDateTime } from '@/lib/utils';

export default function SecurityPage() {
  const { checks, score, run, running } = useSecurity(true);
  const acts = useStore(activityLog.store);
  const logins = useMemo(() => acts.filter((a) => a.kind === 'login' || a.kind === 'fingerprint').slice(0, 6), [acts]);
  const groups = Array.from(new Set(checks.map((c) => c.group)));
  const label = score >= 90 ? 'SECURE' : score >= 70 ? 'ATTENTION NEEDED' : 'AT RISK';
  return (
    <div className="nx-page">
      <PageHeader code="CENTER" title="SECURITY CENTER" desc="Status keamanan aplikasi pada perangkat ini. Skor bersifat lokal, bukan audit keamanan sungguhan." />
      <Panel tone="holo" className="nx-sec-top">
        <Gauge value={score} size={120} label="security score" />
        <div><Chip tone={score >= 90 ? 'ok' : score >= 70 ? 'warn' : 'bad'} dot>{label}</Chip><p className="nx-note">Jalankan pemeriksaan untuk menguji database, RLS, dan token sesi.</p><Button size="sm" onClick={() => void run()} loading={running}><Icon name="refresh" size={16} /> RUN CHECK</Button></div>
      </Panel>
      <div className="nx-grid2">
        {groups.map((g) => (
          <Panel key={g} title={g}>
            <ul className="nx-checklist">{checks.filter((c) => c.group === g).map((c) => <li key={c.label} className={c.ok ? 'is-ok' : c.warn ? 'is-wait' : 'is-bad'}><Icon name={c.ok ? 'check' : c.warn ? 'info' : 'close'} size={16} /><span>{c.label}</span><b>{c.value}</b></li>)}</ul>
          </Panel>
        ))}
      </div>
      <Panel title="LOGIN ACTIVITY">
        {logins.length === 0 ? <p className="nx-dim">Belum ada aktivitas login tercatat.</p> : <ul className="nx-feed">{logins.map((a) => <li key={a.id}><time>{fmtDateTime(a.created_at)}</time><span>{a.detail}</span></li>)}</ul>}
      </Panel>
      <Panel title="RECENT SECURITY EVENTS"><ActivityList groups={['security', 'login']} title="NO SECURITY EVENTS" /></Panel>
    </div>
  );
}
