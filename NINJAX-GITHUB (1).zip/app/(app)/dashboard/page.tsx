'use client';
import Link from 'next/link';
import { useMemo } from 'react';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useChat } from '@/components/Providers/ChatProvider';
import { useGlobalSenders } from '@/components/Providers/SendersProvider';
import { BlackHole, NinjaSilhouette } from '@/components/Visual/BlackHole';
import { Panel } from '@/components/UI/Panel';
import { Chip, EmptyState } from '@/components/UI/Bits';
import { Gauge, Sparkline } from '@/components/UI/Charts';
import { Icon } from '@/components/UI/Icon';
import { Avatar } from '@/components/UI/Avatar';
import { useSecurity } from '@/hooks/useSecurity';
import { useStore } from '@/hooks/useStore';
import { activityLog } from '@/services/activity';
import { LAB_ITEMS } from '@/lib/nav';
import { fmtAgo, fmtTime } from '@/lib/utils';

export default function DashboardPage() {
  const { profile, cloud } = useAuth();
  const { status, online, messages, unread } = useChat();
  const { list: gsenders } = useGlobalSenders();
  const acts = useStore(activityLog.store);
  const { score } = useSecurity(false);

  const today = useMemo(() => acts.filter((a) => Date.now() - new Date(a.created_at).getTime() < 86400000).length, [acts]);
  const spark = useMemo(() => {
    const b = Array(12).fill(0) as number[];
    const now = Date.now();
    for (const a of acts) { const h = Math.floor((now - new Date(a.created_at).getTime()) / 3600000); if (h >= 0 && h < 12) b[11 - h]++; }
    return b;
  }, [acts]);
  const rt = cloud === 'ready' && status === 'connected';
  const last = messages.filter((m) => !m._state).slice(-3);

  const metrics = [
    { k: 'SYSTEM STATUS', v: 'ONLINE', t: 'ok', icon: 'info', href: '/tools/system' },
    { k: 'SECURITY', v: `${score}%`, t: score >= 85 ? 'ok' : 'warn', icon: 'shield', href: '/security' },
    { k: 'ACTIVITY', v: String(today), t: 'cy', icon: 'activity', href: '/activity', sub: 'last 24h' },
    { k: 'ONLINE USERS', v: String(online.length), t: 'ok', icon: 'group', href: '/chat' },
    { k: 'CHAT STATUS', v: rt ? 'LIVE' : status === 'connecting' ? 'SYNC' : 'OFF', t: rt ? 'ok' : status === 'connecting' ? 'warn' : 'bad', icon: 'chat', href: '/chat', sub: unread ? `${unread} unread` : undefined },
  ];

  return (
    <div className="nx-dash">
      <section className="nx-hero">
        <div className="nx-hero__art"><BlackHole size={150} pulse><NinjaSilhouette size={58} /></BlackHole></div>
        <div className="nx-hero__txt">
          <small>CYBER OPERATIONS CENTER</small>
          <h1 className="nx-glitch" data-text="NINJAX">NINJAX</h1>
          <p>WELCOME, <b>NINJA</b></p>
          <div className="nx-chips">
            <Chip tone="ok" dot>SYSTEM ONLINE</Chip>
            <Chip tone="cy" dot>SECURITY ACTIVE</Chip>
            <Chip tone={rt ? 'ok' : status === 'connecting' ? 'warn' : 'bad'} dot>{rt ? 'REALTIME CONNECTED' : status === 'connecting' ? 'REALTIME CONNECTING' : 'REALTIME DISCONNECTED'}</Chip>
          </div>
        </div>
      </section>

      <div className="nx-metrics">
        {metrics.map((m, i) => (
          <Link key={m.k} href={m.href} className={`nx-metric nx-metric--${m.t}`} style={{ animationDelay: `${i * 70}ms` }}>
            <Icon name={m.icon} size={20} /><small>{m.k}</small><b>{m.v}</b>{m.sub ? <em>{m.sub}</em> : null}
          </Link>
        ))}
      </div>

      <div className="nx-grid2">
        <Panel title="SECURITY METER" aside={<Link href="/security" className="nx-link">OPEN</Link>}>
          <div className="nx-row nx-row--gap"><Gauge value={score} /><ul className="nx-kv"><li><span>Session</span><b className="is-ok">VERIFIED</b></li><li><span>Realtime</span><b className={rt ? 'is-ok' : 'is-bad'}>{rt ? 'LIVE' : 'DOWN'}</b></li><li><span>Global senders</span><b>{gsenders.length}</b></li></ul></div>
        </Panel>
        <Panel title="ACTIVITY · 12H" aside={<Link href="/activity" className="nx-link">VIEW ALL</Link>}>
          <Sparkline values={spark} />
          <ul className="nx-feed">
            {acts.slice(0, 4).map((a) => <li key={a.id}><time>{fmtTime(a.created_at)}</time><span>{a.detail}</span></li>)}
            {acts.length === 0 ? <li className="nx-dim">Belum ada aktivitas.</li> : null}
          </ul>
        </Panel>
      </div>

      <Panel title="GLOBAL CHAT" aside={<Link href="/chat" className="nx-link">OPEN CHAT</Link>}>
        {last.length === 0 ? <EmptyState icon="chat" title="NO MESSAGES YET" text={rt ? 'Kirim pesan pertama di Global Chat.' : 'Chat akan muncul setelah terhubung.'} /> : (
          <ul className="nx-mini-chat">
            {last.map((m) => <li key={m.id}><Avatar name={m.username} size={26} /><div><b>@{m.username}</b><p>{m.content}</p></div><time>{fmtAgo(m.created_at)}</time></li>)}
          </ul>
        )}
        <div className="nx-avs">{online.slice(0, 8).map((u) => <Avatar key={u.user_id} name={u.display_name} src={u.avatar_url} size={28} online />)}{online.length ? <small>{online.length} online</small> : null}</div>
      </Panel>

      <Panel title="LABORATORIES" aside={<Link href="/labs" className="nx-link">ALL LABS</Link>}>
        <div className="nx-qgrid">
          {LAB_ITEMS.map((l) => <Link key={l.href} href={l.href} className="nx-q"><span><Icon name={l.icon} size={20} /></span><b>{l.label}</b></Link>)}
        </div>
        <p className="nx-note">Semua lab adalah simulasi lokal pada data dummy — tidak ada aksi terhadap sistem nyata.</p>
      </Panel>
    </div>
  );
}
