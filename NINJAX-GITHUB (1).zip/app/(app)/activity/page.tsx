'use client';
import Link from 'next/link';
import { ActivityList } from '@/components/Dashboard/ActivityList';
import { PageHeader } from '@/components/UI/Bits';
import { Panel } from '@/components/UI/Panel';

export default function ActivityPage() {
  return (
    <div className="nx-page">
      <PageHeader code="CENTER" title="ACTIVITY CENTER" desc="Login, fingerprint, modul yang dibuka, chat, sender, pengaturan, dan event keamanan." aside={<Link href="/history" className="nx-link">HISTORY →</Link>} />
      <Panel><ActivityList clearable /></Panel>
    </div>
  );
}
