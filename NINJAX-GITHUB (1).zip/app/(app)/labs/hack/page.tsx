'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { hackLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={hackLab} />; }
