'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { banGroupLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={banGroupLab} />; }
