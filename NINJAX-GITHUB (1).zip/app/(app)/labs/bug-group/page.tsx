'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { bugGroupLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={bugGroupLab} />; }
