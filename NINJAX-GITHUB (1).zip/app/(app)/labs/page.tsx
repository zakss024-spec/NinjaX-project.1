'use client';
import Link from 'next/link';
import { PageHeader, SimTag } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { LAB_ITEMS } from '@/lib/nav';

export default function LabsPage() {
  return (
    <div className="nx-page">
      <PageHeader code="LABORATORIES" title="LABS" desc="Delapan laboratorium simulasi bergaya cybersecurity. Semua proses berjalan lokal pada data dummy." aside={<SimTag />} />
      <div className="nx-cardgrid">
        {LAB_ITEMS.map((l, i) => (
          <Link key={l.href} href={l.href} className="nx-hubcard" style={{ animationDelay: `${i * 50}ms` }}>
            <span className="nx-hubcard__ico"><Icon name={l.icon} size={26} /></span>
            <b>{l.label}</b><p>{l.desc}</p><em>OPEN →</em>
          </Link>
        ))}
      </div>
    </div>
  );
}
