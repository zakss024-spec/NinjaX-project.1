'use client';
import { NetworkLab } from '@/components/Labs/NetworkLab';

export default function Page() { return <NetworkLab />; }
