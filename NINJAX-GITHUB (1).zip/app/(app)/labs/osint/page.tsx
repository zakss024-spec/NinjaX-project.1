'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { osintLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={osintLab} />; }
