'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { reportLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={reportLab} />; }
