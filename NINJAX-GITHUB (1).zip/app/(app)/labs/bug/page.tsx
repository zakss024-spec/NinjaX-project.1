'use client';
import { SimLab } from '@/components/Labs/SimLab';
import { bugLab } from '@/components/Labs/configs';

export default function Page() { return <SimLab cfg={bugLab} />; }
