'use client';
import { Button } from '@/components/UI/Button';
import { Chip, EmptyState, PageHeader } from '@/components/UI/Bits';
import { Icon } from '@/components/UI/Icon';
import { Panel } from '@/components/UI/Panel';
import { useUI } from '@/components/Providers/UIProvider';
import { useStore } from '@/hooks/useStore';
import { notifLog } from '@/services/notifications';
import { cx, fmtAgo } from '@/lib/utils';
import type { NotifKind } from '@/lib/types';

const ICON: Record<NotifKind, string> = { chat: 'chat', system: 'info', security: 'shield', sender: 'sender' };
const TONE: Record<NotifKind, 'cy' | 'default' | 'bad' | 'ok'> = { chat: 'cy', system: 'default', security: 'bad', sender: 'ok' };

export default function NotificationsPage() {
  const list = useStore(notifLog.store);
  const { confirm, toast } = useUI();
  const unread = list.filter((n) => !n.read).length;
  const clear = async () => { if (await confirm({ title: 'CLEAR NOTIFICATIONS', text: 'Hapus semua notifikasi?', confirm: 'CLEAR', danger: true })) { notifLog.clear(); toast('Notifikasi dihapus', 'success'); } };
  return (
    <div className="nx-page">
      <PageHeader code="CENTER" title="NOTIFICATIONS" desc="Pesan chat baru, event sistem, keamanan, dan pembaruan sender." aside={<Chip tone={unread ? 'cy' : 'off'}>{unread} UNREAD</Chip>} />
      <div className="nx-row"><Button size="sm" variant="ghost" onClick={() => notifLog.updateAll({ read: true })} disabled={!unread}>MARK ALL READ</Button><Button size="sm" variant="danger" onClick={() => void clear()} disabled={!list.length}>CLEAR ALL</Button></div>
      <Panel>
        {list.length === 0 ? <EmptyState icon="bell" title="NO NOTIFICATIONS" text="Notifikasi akan muncul saat ada pesan baru atau event sistem." /> : (
          <ul className="nx-notifs">
            {list.map((n) => (
              <li key={n.id} className={cx(!n.read && 'is-unread')}>
                <span className="nx-notifs__ico"><Icon name={ICON[n.kind]} size={18} /></span>
                <div><div className="nx-notifs__top"><b>{n.title}</b><Chip tone={TONE[n.kind]}>{n.kind.toUpperCase()}</Chip></div>{n.body ? <p>{n.body}</p> : null}<small>{fmtAgo(n.created_at)}</small></div>
                <div className="nx-notifs__acts">
                  {!n.read ? <button type="button" onClick={() => notifLog.update(n.id, { read: true })} aria-label="Mark as read"><Icon name="check" size={16} /></button> : null}
                  <button type="button" onClick={() => notifLog.remove(n.id)} aria-label="Delete notification"><Icon name="trash" size={16} /></button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
