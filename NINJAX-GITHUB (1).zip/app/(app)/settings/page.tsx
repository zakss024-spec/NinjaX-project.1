'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/components/Providers/AuthProvider';
import { useUI } from '@/components/Providers/UIProvider';
import { Avatar } from '@/components/UI/Avatar';
import { Button } from '@/components/UI/Button';
import { Chip, Field, PageHeader, Seg, Switch } from '@/components/UI/Bits';
import { Modal } from '@/components/UI/Modal';
import { Panel } from '@/components/UI/Panel';
import { useSettings } from '@/hooks/useSettings';
import { AVATARS } from '@/lib/images';
import { DEFAULT_SETTINGS, resetSettings, type Accent, type AnimSpeed, type Quality } from '@/lib/settings';
import { APP_VERSION } from '@/lib/version';
import { cx, errMsg } from '@/lib/utils';
import { updateProfile } from '@/services/profiles';
import { logActivity } from '@/services/activity';

function Row({ title, sub, children }: { title: string; sub?: string; children: React.ReactNode }) {
  return <div className="nx-setrow"><div><b>{title}</b>{sub ? <small>{sub}</small> : null}</div>{children}</div>;
}

function ProfileModal({ onClose }: { onClose: () => void }) {
  const { profile, userId, setProfile } = useAuth();
  const { toast } = useUI();
  const [name, setName] = useState(profile?.display_name ?? '');
  const [av, setAv] = useState(profile?.avatar_url ?? AVATARS[0]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const save = async () => {
    if (!userId) return;
    setBusy(true); setErr(null);
    try { const p = await updateProfile(userId, { display_name: name, avatar_url: av }); setProfile(p); logActivity('settings', 'Profile updated'); toast('Profil diperbarui', 'success'); onClose(); }
    catch (e) { setErr(errMsg(e)); setBusy(false); }
  };
  return (
    <Modal open title="EDIT PROFILE" onClose={onClose}>
      <form className="nx-form" onSubmit={(e) => { e.preventDefault(); void save(); }} noValidate>
        <Field label="DISPLAY NAME" hint="2–24 karakter" error={err}><input className="nx-input" value={name} maxLength={24} onChange={(e) => setName(e.target.value)} autoComplete="off" autoFocus /></Field>
        <div className="nx-field"><span className="nx-field__label">AVATAR</span><div className="nx-avpick">{AVATARS.map((a) => <button key={a} type="button" className={cx(av === a && 'is-on')} onClick={() => setAv(a)} aria-pressed={av === a} aria-label={`Avatar ${a.slice(-6, -4)}`}><Avatar name="x" src={a} size={40} /></button>)}</div></div>
        <div className="nx-modal__actions"><Button variant="ghost" onClick={onClose}>CANCEL</Button><Button type="submit" loading={busy}>SAVE</Button></div>
      </form>
    </Modal>
  );
}

export default function SettingsPage() {
  const [s, update] = useSettings();
  const { gate, cloud, profile, isAnonymous, logout, resetIdentity } = useAuth();
  const { confirm, toast } = useUI();
  const router = useRouter();
  const [edit, setEdit] = useState(false);
  const set = <K extends keyof typeof DEFAULT_SETTINGS>(k: K, v: (typeof DEFAULT_SETTINGS)[K]) => { update({ [k]: v } as Partial<typeof DEFAULT_SETTINGS>); logActivity('settings', `Setting ${k} → ${String(v)}`); };

  const doLogout = async () => { if (await confirm({ title: 'LOGOUT', text: 'Keluar dari sesi ini?', confirm: 'LOGOUT', danger: true })) { await logout(); router.replace('/login'); } };
  const doReset = async () => {
    if (await confirm({ title: 'RESET IDENTITY', text: 'Ini akan keluar dan membuat identitas anonim BARU. Sender private di perangkat ini tetap ada, tetapi profil/chat lama tidak lagi bisa Anda edit.', confirm: 'RESET', danger: true })) { await resetIdentity(); router.replace('/login'); }
  };

  return (
    <div className="nx-page">
      <PageHeader code="SYSTEM" title="SETTINGS" desc="Sesi, tampilan, performa, dan notifikasi. Disimpan lokal di perangkat ini." />

      <Panel title="SESSION" aside={<Chip tone={cloud === 'ready' ? 'ok' : 'warn'} dot>{cloud === 'ready' ? 'CONNECTED' : cloud.toUpperCase()}</Chip>}>
        <div className="nx-me nx-me--lg"><Avatar name={profile?.display_name ?? 'Ninja'} src={profile?.avatar_url} size={52} online /><div><b>{profile?.display_name ?? 'NINJA'}</b><small>@{profile?.username ?? '-'} · {isAnonymous ? 'anonymous session' : 'registered'}</small></div></div>
        <ul className="nx-kv"><li><span>Access gate</span><b className={gate === 'ready' ? 'is-ok' : 'is-warn'}>{gate === 'ready' ? 'VERIFIED' : gate.toUpperCase()}</b></li></ul>
        <div className="nx-row nx-row--wrap"><Button size="sm" variant="ghost" onClick={() => setEdit(true)} disabled={!profile}>EDIT PROFILE</Button><Button size="sm" variant="ghost" onClick={() => router.push('/loading')}>REPLAY INTRO</Button><Button size="sm" variant="ghost" onClick={() => void doReset()}>RESET IDENTITY</Button><Button size="sm" variant="danger" onClick={() => void doLogout()}>LOGOUT</Button></div>
      </Panel>

      <Panel title="APPEARANCE">
        <Row title="Theme accent" sub="Warna utama antarmuka"><Seg<Accent> label="Accent" value={s.accent} onChange={(v) => set('accent', v)} options={[{ id: 'violet', label: 'VIOLET' }, { id: 'cyan', label: 'CYAN' }, { id: 'green', label: 'GREEN' }]} /></Row>
        <Row title="Effects" sub="Scanlines & glitch"><Switch label="Effects" checked={s.effects} onChange={(v) => set('effects', v)} /></Row>
        <Row title="Animations" sub="Matikan untuk hemat baterai"><Switch label="Animations" checked={s.animations} onChange={(v) => set('animations', v)} /></Row>
        <Row title="Animation speed"><Seg<AnimSpeed> label="Speed" value={s.animSpeed} onChange={(v) => set('animSpeed', v)} options={[{ id: 'slow', label: 'SLOW' }, { id: 'normal', label: 'NORMAL' }, { id: 'fast', label: 'FAST' }]} /></Row>
      </Panel>

      <Panel title="PERFORMANCE">
        <Row title="Particles" sub="Partikel neon di latar"><Switch label="Particles" checked={s.particles} onChange={(v) => set('particles', v)} /></Row>
        <Row title="Glow" sub="Efek cahaya neon"><Switch label="Glow" checked={s.glow} onChange={(v) => set('glow', v)} /></Row>
        <Row title="Animation quality"><Seg<Quality> label="Quality" value={s.quality} onChange={(v) => set('quality', v)} options={[{ id: 'low', label: 'LOW' }, { id: 'medium', label: 'MED' }, { id: 'high', label: 'HIGH' }]} /></Row>
      </Panel>

      <Panel title="NOTIFICATIONS">
        <Row title="Chat notifications" sub="Pesan baru saat Anda tidak di halaman chat"><Switch label="Chat notifications" checked={s.notifyChat} onChange={(v) => set('notifyChat', v)} /></Row>
        <Row title="System notifications" sub="Event sistem, keamanan, dan sender"><Switch label="System notifications" checked={s.notifySystem} onChange={(v) => set('notifySystem', v)} /></Row>
        <Button size="sm" variant="ghost" onClick={() => { resetSettings(); toast('Pengaturan dikembalikan ke default', 'success'); }}>RESET SETTINGS</Button>
      </Panel>

      <Panel title="ABOUT">
        <ul className="nx-kv"><li><span>App</span><b>NINJAX</b></li><li><span>Version</span><b>{APP_VERSION}</b></li><li><span>Stack</span><b>Next.js · React · TypeScript · Supabase</b></li><li><span>Cyber modules</span><b className="is-ok">LOCAL SIMULATION</b></li></ul>
      </Panel>

      <Panel title="DEVELOPERS">
        <div className="nx-devs">{['Zakss', 'DAKA', 'NATHAN'].map((d) => <div key={d} className="nx-dev"><Avatar name={d} size={44} /><small>DEVELOPER</small><b>{d}</b></div>)}</div>
      </Panel>
      {edit ? <ProfileModal onClose={() => setEdit(false)} /> : null}
    </div>
  );
}
