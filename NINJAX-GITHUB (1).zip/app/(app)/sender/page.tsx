'use client';
import { SenderManager } from '@/components/Sender/SenderManager';

export default function SenderPage() { return <SenderManager />; }
