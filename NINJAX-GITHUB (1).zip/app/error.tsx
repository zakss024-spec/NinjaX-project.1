'use client';
import { useEffect } from 'react';

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error('[NinjaX] page error', error); }, [error]);
  return (
    <div className="nx-boot" role="alert">
      <b className="nx-404">ERROR</b>
      <small>{error.message || 'Unexpected error'}</small>
      <button type="button" className="nx-btn nx-btn--primary" onClick={reset}><span className="nx-btn__label">RETRY</span></button>
    </div>
  );
}
