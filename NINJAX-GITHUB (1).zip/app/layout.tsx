import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import '@/styles/globals.css';
import '@/styles/components.css';
import '@/styles/pages.css';
import { AuthProvider } from '@/components/Providers/AuthProvider';
import { UIProvider } from '@/components/Providers/UIProvider';

export const metadata: Metadata = {
  title: { default: 'NINJAX', template: '%s · NINJAX' },
  description: 'NinjaX — cyber operations center: realtime global chat, sender manager, and simulation labs.',
  icons: { icon: '/assets/icons/favicon.svg', apple: '/assets/icons/icon-192.png' },
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#05030c',
  interactiveWidget: 'resizes-content',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="id" data-accent="violet" data-fx="on" data-anim="normal" data-glow="on" data-quality="medium" suppressHydrationWarning>
      <head>
        <link rel="preload" as="image" href="/assets/images/blackhole.webp" type="image/webp" />
        <link rel="preload" as="image" href="/assets/images/ninja.webp" type="image/webp" />
      </head>
      <body>
        <noscript><p style={{ padding: 24, textAlign: 'center' }}>JavaScript diperlukan untuk menjalankan NinjaX.</p></noscript>
        <AuthProvider>
          <UIProvider>{children}</UIProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
